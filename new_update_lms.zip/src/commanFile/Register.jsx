import { useState, useEffect } from "react";
import Header from "../web/layout/Header";

const steps = ["Account", "Profile", "Confirm"];

const roles = [
  {
    val: "student",
    icon: "🎓",
    label: "Student",
    desc: "Access courses & track progress",
  },
  {
    val: "teacher",
    icon: "👨‍🏫",
    label: "Instructor",
    desc: "Create & manage your courses",
  },
  { val: "admin", icon: "⚙️", label: "Admin", desc: "Manage platform & users" },
];

function StrengthBar({ password }) {
  const checks = [
    password.length >= 8,
    /[A-Z]/.test(password),
    /[0-9]/.test(password),
    /[^A-Za-z0-9]/.test(password),
  ];
  const score = checks.filter(Boolean).length;
  const colors = ["#f43f5e", "#f97316", "#eab308", "#22c55e"];
  const labels = ["Weak", "Fair", "Good", "Strong"];
  if (!password) return null;
  return (
    <div style={{ marginTop: 8 }}>
      <div style={{ display: "flex", gap: 4, marginBottom: 6 }}>
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            style={{
              flex: 1,
              height: 4,
              borderRadius: 99,
              background: i < score ? colors[score - 1] : "#e2e8f0",
              transition: "background 0.3s",
            }}
          />
        ))}
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div style={{ display: "flex", gap: 12 }}>
          {["8+ chars", "Uppercase", "Number", "Symbol"].map((c, i) => (
            <span
              key={i}
              style={{
                fontSize: 10.5,
                color: checks[i] ? "#6366f1" : "#cbd5e1",
                fontWeight: 600,
                transition: "color 0.2s",
              }}
            >
              {checks[i] ? "✓" : "○"} {c}
            </span>
          ))}
        </div>
        {score > 0 && (
          <span
            style={{ fontSize: 11, fontWeight: 700, color: colors[score - 1] }}
          >
            {labels[score - 1]}
          </span>
        )}
      </div>
    </div>
  );
}

export default function Register() {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    email: "",
    password: "",
    confirm: "",
    name: "",
    role: "student",
    phone: "",
    agree: false,
    newsletter: true,
  });
  const [errors, setErrors] = useState({});
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [focusedField, setFocusedField] = useState(null);
  const [direction, setDirection] = useState(1);

  useEffect(() => {
    setTimeout(() => setMounted(true), 80);
  }, []);

  const set = (field, val) => {
    setForm((f) => ({ ...f, [field]: val }));
    if (errors[field]) setErrors((e) => ({ ...e, [field]: "" }));
  };

  const validateStep = (s) => {
    const e = {};
    if (s === 0) {
      if (!form.email.trim()) e.email = "Email address is required";
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
        e.email = "Enter a valid email address";
      if (!form.password) e.password = "Password is required";
      else if (form.password.length < 8)
        e.password = "Minimum 8 characters required";
      if (!form.confirm) e.confirm = "Please confirm your password";
      else if (form.password !== form.confirm)
        e.confirm = "Passwords do not match";
    }
    if (s === 1) {
      if (!form.name.trim()) e.name = "Full name is required";
      else if (form.name.trim().length < 3)
        e.name = "Name must be at least 3 characters";
      if (form.phone && !/^[+\d\s\-()]{7,15}$/.test(form.phone))
        e.phone = "Enter a valid phone number";
    }
    if (s === 2) {
      if (!form.agree) e.agree = "You must accept the Terms & Conditions";
    }
    return e;
  };

  const nextStep = () => {
    const errs = validateStep(step);
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }
    setErrors({});
    setDirection(1);
    setStep((s) => s + 1);
  };

  const prevStep = () => {
    setErrors({});
    setDirection(-1);
    setStep((s) => s - 1);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validateStep(2);
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 2000));
    setLoading(false);
    setSuccess(true);
  };

  const progressWidth = (step / 2) * 100;

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=DM+Sans:wght@300;400;500;600;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #fff; }
        .fade-up { opacity: 0; transform: translateY(20px); transition: opacity 0.55s cubic-bezier(.22,1,.36,1), transform 0.55s cubic-bezier(.22,1,.36,1); }
        .fade-up.show { opacity: 1; transform: translateY(0); }
        .d1{transition-delay:.05s}.d2{transition-delay:.1s}.d3{transition-delay:.15s}.d4{transition-delay:.2s}.d5{transition-delay:.25s}
        .lms-input {
          width: 100%; padding: 14px 16px 14px 46px;
          border-radius: 12px; border: 1.5px solid #e2e8f0;
          font-family: 'DM Sans', sans-serif; font-size: 14px; font-weight: 500;
          color: #0f172a; background: #f8fafc; outline: none; transition: all 0.2s;
        }
        .lms-input::placeholder { color: #94a3b8; font-weight: 400; }
        .lms-input:focus { border-color: #6366f1; background: #fff; box-shadow: 0 0 0 4px rgba(99,102,241,0.08); }
        .lms-input.err { border-color: #f43f5e; background: #fff5f7; box-shadow: 0 0 0 4px rgba(244,63,94,0.07); }
        .lms-input.no-icon { padding-left: 16px; }
        .lms-input.has-toggle { padding-right: 46px; }
        .input-icon { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #94a3b8; transition: color 0.2s; pointer-events: none; }
        .input-icon.active { color: #6366f1; }
        .input-icon.err { color: #f43f5e; }
        .toggle-btn { position: absolute; right: 14px; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; color: #94a3b8; display: flex; align-items: center; transition: color 0.2s; }
        .toggle-btn:hover { color: #6366f1; }
        .err-msg { font-size: 11.5px; color: #f43f5e; margin-top: 5px; display: flex; align-items: center; gap: 4px; font-family: 'DM Sans', sans-serif; font-weight: 500; min-height: 18px; }
        .submit-btn {
          width: 100%; padding: 15px; border-radius: 12px; border: none;
          background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
          color: white; font-family: 'DM Sans', sans-serif; font-size: 15px; font-weight: 700;
          cursor: pointer; transition: all 0.25s; box-shadow: 0 4px 20px rgba(99,102,241,0.35);
          display: flex; align-items: center; justify-content: center; gap: 8px;
        }
        .submit-btn:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(99,102,241,0.45); }
        .submit-btn:disabled { opacity: 0.7; cursor: not-allowed; }
        .next-btn {
          flex: 1; padding: 14px; border-radius: 12px; border: none;
          background: linear-gradient(135deg, #6366f1, #4f46e5);
          color: white; font-family: 'DM Sans', sans-serif; font-size: 14px; font-weight: 700;
          cursor: pointer; transition: all 0.25s; box-shadow: 0 4px 16px rgba(99,102,241,0.3);
          display: flex; align-items: center; justify-content: center; gap: 8px;
        }
        .next-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(99,102,241,0.4); }
        .back-btn {
          padding: 14px 20px; border-radius: 12px; border: 1.5px solid #e2e8f0;
          background: #fff; color: #64748b; font-family: 'DM Sans', sans-serif;
          font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.2s;
          display: flex; align-items: center; gap: 6px;
        }
        .back-btn:hover { border-color: #6366f1; color: #6366f1; background: #f5f3ff; }
        .role-card {
          padding: 16px; border-radius: 14px; border: 1.5px solid #e2e8f0;
          background: #f8fafc; cursor: pointer; transition: all 0.2s; text-align: left; width: 100%;
        }
        .role-card:hover { border-color: #6366f1; background: #f5f3ff; transform: translateY(-1px); box-shadow: 0 4px 12px rgba(99,102,241,0.1); }
        .role-card.active { border-color: #6366f1; background: linear-gradient(135deg,#f5f3ff,#ede9fe); box-shadow: 0 4px 16px rgba(99,102,241,0.15); }
        .check-box { width: 18px; height: 18px; border-radius: 5px; border: 1.5px solid #cbd5e1; background: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s; flex-shrink: 0; }
        .check-box.checked { background: #6366f1; border-color: #6366f1; }
        .step-dot { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700; transition: all 0.3s; }
        .step-dot.done { background: #6366f1; color: white; }
        .step-dot.current { background: #6366f1; color: white; box-shadow: 0 0 0 4px rgba(99,102,241,0.2); }
        .step-dot.pending { background: #f1f5f9; color: #94a3b8; }
        .left-panel { background: linear-gradient(160deg, #0f172a 0%, #1e293b 55%, #0f2027 100%); position: relative; overflow: hidden; }
        .left-panel::before { content:''; position:absolute; top:-80px; left:-80px; width:400px; height:400px; border-radius:50%; background:radial-gradient(circle,rgba(99,102,241,0.18) 0%,transparent 70%); pointer-events:none; }
        .left-panel::after { content:''; position:absolute; bottom:-60px; right:-60px; width:320px; height:320px; border-radius:50%; background:radial-gradient(circle,rgba(16,185,129,0.12) 0%,transparent 70%); pointer-events:none; }
        .grid-lines { position:absolute; inset:0; background-image:linear-gradient(rgba(255,255,255,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.03) 1px,transparent 1px); background-size:48px 48px; pointer-events:none; }
        @keyframes spin { to { transform: rotate(360deg); } }
        .spinner { animation: spin 0.8s linear infinite; }
        @keyframes checkPop { 0%{transform:scale(0.5);opacity:0} 70%{transform:scale(1.1)} 100%{transform:scale(1);opacity:1} }
        .check-pop { animation: checkPop 0.4s cubic-bezier(.34,1.56,.64,1) forwards; }
        @media (max-width: 900px) {
          .split-layout { flex-direction: column !important; }
          .left-panel { min-height: 240px !important; width: 100% !important; padding: 36px 28px !important; }
          .right-panel { width: 100% !important; padding: 40px 24px !important; }
        }
        @media (max-width: 480px) {
          .right-panel { padding: 28px 16px !important; }
          .role-grid { grid-template-columns: 1fr !important; }
          .btn-row { flex-direction: column !important; }
        }
      `}</style>
      <Header />
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          background: "#fff",
          fontFamily: "'DM Sans', sans-serif",
        }}
      >
        <div
          className="split-layout"
          style={{ display: "flex", width: "100%", minHeight: "100vh" }}
        >
          {/* ── LEFT PANEL ── */}
          <div
            className="left-panel"
            style={{
              width: "38%",
              minHeight: "100vh",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              padding: "52px 44px",
              position: "relative",
              backgroundImage:
                "url('./bg-img-login.jpg')",
              backgroundSize: "cover",
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat",
            }}
          >
            <div className="grid-lines" />

            {/* Logo */}
            <div style={{ position: "relative", zIndex: 2 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div
                  style={{
                    width: 42,
                    height: 42,
                    borderRadius: 12,
                    background: "linear-gradient(135deg,#6366f1,#4f46e5)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    boxShadow: "0 4px 16px rgba(99,102,241,0.4)",
                  }}
                >
                  <svg
                    width="22"
                    height="22"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="white"
                    strokeWidth="2.2"
                  >
                    <path d="M12 2L2 7l10 5 10-5-10-5z" />
                    <path d="M2 17l10 5 10-5" />
                    <path d="M2 12l10 5 10-5" />
                  </svg>
                </div>
                <span
                  style={{
                    fontFamily: "'Instrument Serif', serif",
                    fontSize: 22,
                    color: "#fff",
                    letterSpacing: "-0.02em",
                  }}
                >
                  EduVerse
                </span>
              </div>
            </div>

            {/* Main Content */}
            <div
              style={{
                position: "relative",
                zIndex: 2,
                flex: 1,
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                paddingTop: 48,
                paddingBottom: 48,
              }}
            >
              <div
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 8,
                  background: "rgba(99,102,241,0.18)",
                  border: "1px solid rgba(99,102,241,0.35)",
                  borderRadius: 100,
                  padding: "6px 14px",
                  marginBottom: 24,
                  width: "fit-content",
                }}
              >
                <div
                  style={{
                    width: 6,
                    height: 6,
                    borderRadius: "50%",
                    background: "#a5b4fc",
                  }}
                />
                <span
                  style={{
                    fontSize: 12,
                    color: "#a5b4fc",
                    fontWeight: 600,
                    letterSpacing: "0.04em",
                  }}
                >
                  JOIN 50,000+ LEARNERS
                </span>
              </div>

              <h1
                style={{
                  fontFamily: "'Instrument Serif', serif",
                  fontSize: "clamp(28px,3.5vw,42px)",
                  color: "#fff",
                  lineHeight: 1.22,
                  marginBottom: 18,
                  letterSpacing: "-0.02em",
                }}
              >
                Start Your
                <br />
                <span style={{ fontStyle: "italic", color: "#a5b4fc" }}>
                  Learning Journey
                </span>
                <br />
                Today
              </h1>
              <p
                style={{
                  fontSize: 14,
                  color: "rgba(255,255,255,0.5)",
                  lineHeight: 1.75,
                  marginBottom: 40,
                  maxWidth: 320,
                  fontWeight: 400,
                }}
              >
                Create your free account in minutes and get instant access to
                1,200+ courses taught by industry experts.
              </p>
              

              {/* Progress Steps Preview */}
              <div
                style={{
                  background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 16,
                  padding: "20px 24px",
                }}
              >
                <div
                  style={{
                    fontSize: 11,
                    color: "rgba(255,255,255,0.4)",
                    fontWeight: 600,
                    letterSpacing: "0.08em",
                    marginBottom: 16,
                  }}
                >
                  REGISTRATION STEPS
                </div>
                {steps.map((s, i) => (
                  <div
                    key={i}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 12,
                      marginBottom: i < steps.length - 1 ? 12 : 0,
                    }}
                  >
                    <div
                      style={{
                        width: 28,
                        height: 28,
                        borderRadius: "50%",
                        background:
                          i <= step
                            ? "linear-gradient(135deg,#6366f1,#4f46e5)"
                            : "rgba(255,255,255,0.07)",
                        border:
                          i <= step
                            ? "none"
                            : "1px solid rgba(255,255,255,0.12)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 11,
                        fontWeight: 700,
                        color: i <= step ? "white" : "rgba(255,255,255,0.35)",
                        transition: "all 0.3s",
                        boxShadow:
                          i === step
                            ? "0 0 0 3px rgba(99,102,241,0.25)"
                            : "none",
                      }}
                    >
                      {i < step ? "✓" : i + 1}
                    </div>
                    <span
                      style={{
                        fontSize: 13,
                        color:
                          i <= step
                            ? "rgba(255,255,255,0.85)"
                            : "rgba(255,255,255,0.35)",
                        fontWeight: i === step ? 600 : 400,
                        transition: "color 0.3s",
                      }}
                    >
                      {s}
                    </span>
                    {i === step && (
                      <div
                        style={{
                          marginLeft: "auto",
                          fontSize: 10,
                          color: "#a5b4fc",
                          background: "rgba(99,102,241,0.2)",
                          borderRadius: 100,
                          padding: "2px 8px",
                          fontWeight: 700,
                        }}
                      >
                        CURRENT
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
          </div>

          {/* ── RIGHT PANEL ── */}
          <div
            className="right-panel"
            style={{
              width: "62%",
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "center",
              padding: "60px 72px",
              background: "#fff",
              overflowY: "auto",
            }}
          >
            <div
              style={{
                width: "100%",
                maxWidth: 460,
                paddingTop: 20,
                paddingBottom: 40,
              }}
            >
              {success ? (
                /* SUCCESS */
                <div style={{ textAlign: "center", paddingTop: 60 }}>
                  <div
                    className="check-pop"
                    style={{
                      width: 84,
                      height: 84,
                      borderRadius: "50%",
                      background: "linear-gradient(135deg,#6366f1,#4f46e5)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      margin: "0 auto 28px",
                      boxShadow: "0 12px 32px rgba(99,102,241,0.35)",
                    }}
                  >
                    <svg
                      width="40"
                      height="40"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="white"
                      strokeWidth="2.5"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                  </div>
                  <h2
                    style={{
                      fontFamily: "'Instrument Serif', serif",
                      fontSize: 32,
                      color: "#0f172a",
                      marginBottom: 12,
                    }}
                  >
                    You're all set! 🚀
                  </h2>
                  <p
                    style={{
                      fontSize: 15,
                      color: "#64748b",
                      marginBottom: 10,
                      lineHeight: 1.7,
                    }}
                  >
                    Welcome to EduVerse! A confirmation email has been sent to
                  </p>
                  <p
                    style={{
                      fontSize: 15,
                      fontWeight: 700,
                      color: "#6366f1",
                      marginBottom: 32,
                    }}
                  >
                    {form.email}
                  </p>
                  <a
                    href="/login"
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 8,
                      padding: "14px 32px",
                      borderRadius: 12,
                      background: "linear-gradient(135deg,#6366f1,#4f46e5)",
                      color: "white",
                      fontWeight: 700,
                      fontSize: 15,
                      textDecoration: "none",
                      boxShadow: "0 4px 20px rgba(99,102,241,0.35)",
                      transition: "all 0.2s",
                    }}
                  >
                    Go to Login →
                  </a>
                </div>
              ) : (
                <>
                  {/* Header */}
                  <div
                    className={`fade-up d1 ${mounted ? "show" : ""}`}
                    style={{ marginBottom: 32 }}
                  >
                    <p
                      style={{
                        fontSize: 13,
                        color: "#6366f1",
                        fontWeight: 700,
                        letterSpacing: "0.08em",
                        marginBottom: 8,
                        textTransform: "uppercase",
                      }}
                    >
                      Step {step + 1} of {steps.length}
                    </p>
                    <h2
                      style={{
                        fontFamily: "'Instrument Serif', serif",
                        fontSize: "clamp(24px,3vw,32px)",
                        color: "#0f172a",
                        lineHeight: 1.2,
                        letterSpacing: "-0.02em",
                        marginBottom: 8,
                      }}
                    >
                      {step === 0 && "Create your account"}
                      {step === 1 && "Tell us about yourself"}
                      {step === 2 && "Almost there!"}
                    </h2>
                    <p style={{ fontSize: 14, color: "#94a3b8" }}>
                      Already have an account?{" "}
                      <a
                        href="/login"
                        style={{
                          color: "#6366f1",
                          fontWeight: 600,
                          textDecoration: "none",
                        }}
                        onMouseOver={(e) =>
                          (e.target.style.textDecoration = "underline")
                        }
                        onMouseOut={(e) =>
                          (e.target.style.textDecoration = "none")
                        }
                      >
                        Sign in →
                      </a>
                    </p>
                  </div>

                  {/* Progress Bar */}
                  <div
                    className={`fade-up d1 ${mounted ? "show" : ""}`}
                    style={{ marginBottom: 36 }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        marginBottom: 12,
                      }}
                    >
                      {steps.map((s, i) => (
                        <div
                          key={i}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 8,
                          }}
                        >
                          <div
                            className={`step-dot ${i < step ? "done" : i === step ? "current" : "pending"}`}
                          >
                            {i < step ? (
                              <svg
                                width="14"
                                height="14"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="white"
                                strokeWidth={3}
                              >
                                <path d="M5 13l4 4L19 7" />
                              </svg>
                            ) : (
                              i + 1
                            )}
                          </div>
                          <span
                            style={{
                              fontSize: 12,
                              fontWeight: 600,
                              color: i <= step ? "#6366f1" : "#94a3b8",
                            }}
                          >
                            {s}
                          </span>
                          {i < steps.length - 1 && (
                            <div
                              style={{
                                width: 48,
                                height: 2,
                                background: i < step ? "#6366f1" : "#e2e8f0",
                                marginLeft: 4,
                                borderRadius: 99,
                                transition: "background 0.3s",
                              }}
                            />
                          )}
                        </div>
                      ))}
                    </div>
                    <div
                      style={{
                        height: 3,
                        background: "#f1f5f9",
                        borderRadius: 99,
                        overflow: "hidden",
                      }}
                    >
                      <div
                        style={{
                          height: "100%",
                          width: `${(step / (steps.length - 1)) * 100}%`,
                          background: "linear-gradient(90deg,#6366f1,#818cf8)",
                          borderRadius: 99,
                          transition: "width 0.4s cubic-bezier(.22,1,.36,1)",
                        }}
                      />
                    </div>
                  </div>

                  <form
                    onSubmit={
                      step < 2
                        ? (e) => {
                            e.preventDefault();
                            nextStep();
                          }
                        : handleSubmit
                    }
                    noValidate
                  >
                    {/* STEP 0: Account */}
                    {step === 0 && (
                      <>
                        {/* Email */}
                        <div
                          className={`fade-up d2 ${mounted ? "show" : ""}`}
                          style={{ marginBottom: 8 }}
                        >
                          <label
                            style={{
                              display: "block",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#374151",
                              marginBottom: 7,
                            }}
                          >
                            Email Address
                          </label>
                          <div style={{ position: "relative" }}>
                            <span
                              className={`input-icon ${focusedField === "email" ? "active" : ""} ${errors.email ? "err" : ""}`}
                            >
                              <svg
                                width="16"
                                height="16"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                strokeWidth={2}
                              >
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                                <polyline points="22,6 12,13 2,6" />
                              </svg>
                            </span>
                            <input
                              className={`lms-input ${errors.email ? "err" : ""}`}
                              type="email"
                              placeholder="you@example.com"
                              value={form.email}
                              onChange={(e) => set("email", e.target.value)}
                              onFocus={() => setFocusedField("email")}
                              onBlur={() => setFocusedField(null)}
                            />
                          </div>
                          <div style={{ minHeight: 20 }}>
                            {errors.email && (
                              <p className="err-msg">
                                <svg
                                  width="12"
                                  height="12"
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path
                                    fillRule="evenodd"
                                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                                  />
                                </svg>
                                {errors.email}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Password */}
                        <div
                          className={`fade-up d3 ${mounted ? "show" : ""}`}
                          style={{ marginBottom: 8 }}
                        >
                          <label
                            style={{
                              display: "block",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#374151",
                              marginBottom: 7,
                            }}
                          >
                            Password
                          </label>
                          <div style={{ position: "relative" }}>
                            <span
                              className={`input-icon ${focusedField === "password" ? "active" : ""} ${errors.password ? "err" : ""}`}
                            >
                              <svg
                                width="16"
                                height="16"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                strokeWidth={2}
                              >
                                <rect
                                  x="3"
                                  y="11"
                                  width="18"
                                  height="11"
                                  rx="2"
                                  ry="2"
                                />
                                <path d="M7 11V7a5 5 0 0110 0v4" />
                              </svg>
                            </span>
                            <input
                              className={`lms-input has-toggle ${errors.password ? "err" : ""}`}
                              type={showPass ? "text" : "password"}
                              placeholder="Min. 8 characters"
                              value={form.password}
                              onChange={(e) => set("password", e.target.value)}
                              onFocus={() => setFocusedField("password")}
                              onBlur={() => setFocusedField(null)}
                            />
                            <button
                              type="button"
                              className="toggle-btn"
                              onClick={() => setShowPass((p) => !p)}
                            >
                              {showPass ? (
                                <svg
                                  width="17"
                                  height="17"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  stroke="currentColor"
                                  strokeWidth={2}
                                >
                                  <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94" />
                                  <path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19" />
                                  <line x1="1" y1="1" x2="23" y2="23" />
                                </svg>
                              ) : (
                                <svg
                                  width="17"
                                  height="17"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  stroke="currentColor"
                                  strokeWidth={2}
                                >
                                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                  <circle cx="12" cy="12" r="3" />
                                </svg>
                              )}
                            </button>
                          </div>
                          <StrengthBar password={form.password} />
                          <div style={{ minHeight: 20, marginTop: 4 }}>
                            {errors.password && (
                              <p className="err-msg">
                                <svg
                                  width="12"
                                  height="12"
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path
                                    fillRule="evenodd"
                                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                                  />
                                </svg>
                                {errors.password}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Confirm Password */}
                        <div
                          className={`fade-up d4 ${mounted ? "show" : ""}`}
                          style={{ marginBottom: 8 }}
                        >
                          <label
                            style={{
                              display: "block",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#374151",
                              marginBottom: 7,
                            }}
                          >
                            Confirm Password
                          </label>
                          <div style={{ position: "relative" }}>
                            <span
                              className={`input-icon ${focusedField === "confirm" ? "active" : ""} ${errors.confirm ? "err" : ""}`}
                            >
                              <svg
                                width="16"
                                height="16"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                strokeWidth={2}
                              >
                                <path d="M9 12l2 2 4-4" />
                                <rect
                                  x="3"
                                  y="11"
                                  width="18"
                                  height="11"
                                  rx="2"
                                  ry="2"
                                />
                                <path d="M7 11V7a5 5 0 0110 0v4" />
                              </svg>
                            </span>
                            <input
                              className={`lms-input has-toggle ${errors.confirm ? "err" : ""}`}
                              type={showConfirm ? "text" : "password"}
                              placeholder="Re-enter your password"
                              value={form.confirm}
                              onChange={(e) => set("confirm", e.target.value)}
                              onFocus={() => setFocusedField("confirm")}
                              onBlur={() => setFocusedField(null)}
                            />
                            <button
                              type="button"
                              className="toggle-btn"
                              onClick={() => setShowConfirm((p) => !p)}
                            >
                              {showConfirm ? (
                                <svg
                                  width="17"
                                  height="17"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  stroke="currentColor"
                                  strokeWidth={2}
                                >
                                  <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94" />
                                  <path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19" />
                                  <line x1="1" y1="1" x2="23" y2="23" />
                                </svg>
                              ) : (
                                <svg
                                  width="17"
                                  height="17"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  stroke="currentColor"
                                  strokeWidth={2}
                                >
                                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                  <circle cx="12" cy="12" r="3" />
                                </svg>
                              )}
                            </button>
                          </div>
                          <div style={{ minHeight: 20 }}>
                            {errors.confirm && (
                              <p className="err-msg">
                                <svg
                                  width="12"
                                  height="12"
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path
                                    fillRule="evenodd"
                                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                                  />
                                </svg>
                                {errors.confirm}
                              </p>
                            )}
                          </div>
                        </div>
                      </>
                    )}

                    {/* STEP 1: Profile */}
                    {step === 1 && (
                      <>
                        {/* Name */}
                        <div
                          className={`fade-up d2 ${mounted ? "show" : ""}`}
                          style={{ marginBottom: 8 }}
                        >
                          <label
                            style={{
                              display: "block",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#374151",
                              marginBottom: 7,
                            }}
                          >
                            Full Name
                          </label>
                          <div style={{ position: "relative" }}>
                            <span
                              className={`input-icon ${focusedField === "name" ? "active" : ""} ${errors.name ? "err" : ""}`}
                            >
                              <svg
                                width="16"
                                height="16"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                strokeWidth={2}
                              >
                                <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
                                <circle cx="12" cy="7" r="4" />
                              </svg>
                            </span>
                            <input
                              className={`lms-input ${errors.name ? "err" : ""}`}
                              type="text"
                              placeholder="Your full name"
                              value={form.name}
                              onChange={(e) => set("name", e.target.value)}
                              onFocus={() => setFocusedField("name")}
                              onBlur={() => setFocusedField(null)}
                            />
                          </div>
                          <div style={{ minHeight: 20 }}>
                            {errors.name && (
                              <p className="err-msg">
                                <svg
                                  width="12"
                                  height="12"
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path
                                    fillRule="evenodd"
                                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                                  />
                                </svg>
                                {errors.name}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Phone */}
                        <div
                          className={`fade-up d3 ${mounted ? "show" : ""}`}
                          style={{ marginBottom: 8 }}
                        >
                          <label
                            style={{
                              display: "block",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#374151",
                              marginBottom: 7,
                            }}
                          >
                            Phone Number{" "}
                            <span style={{ color: "#94a3b8", fontWeight: 400 }}>
                              (Optional)
                            </span>
                          </label>
                          <div style={{ position: "relative" }}>
                            <span
                              className={`input-icon ${focusedField === "phone" ? "active" : ""} ${errors.phone ? "err" : ""}`}
                            >
                              <svg
                                width="16"
                                height="16"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                strokeWidth={2}
                              >
                                <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 11 19.79 19.79 0 01.01 2.39 2 2 0 012 .21h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z" />
                              </svg>
                            </span>
                            <input
                              className={`lms-input ${errors.phone ? "err" : ""}`}
                              type="tel"
                              placeholder="+91 98765 43210"
                              value={form.phone}
                              onChange={(e) => set("phone", e.target.value)}
                              onFocus={() => setFocusedField("phone")}
                              onBlur={() => setFocusedField(null)}
                            />
                          </div>
                          <div style={{ minHeight: 20 }}>
                            {errors.phone && (
                              <p className="err-msg">
                                <svg
                                  width="12"
                                  height="12"
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path
                                    fillRule="evenodd"
                                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                                  />
                                </svg>
                                {errors.phone}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Role */}
                        <div
                          className={`fade-up d4 ${mounted ? "show" : ""}`}
                          style={{ marginBottom: 8 }}
                        >
                          <label
                            style={{
                              display: "block",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#374151",
                              marginBottom: 10,
                            }}
                          >
                            I am joining as
                          </label>
                          <div
                            className="role-grid"
                            style={{
                              display: "grid",
                              gridTemplateColumns: "repeat(3,1fr)",
                              gap: 10,
                            }}
                          >
                            {roles.map((r) => (
                              <button
                                key={r.val}
                                type="button"
                                className={`role-card ${form.role === r.val ? "active" : ""}`}
                                onClick={() => set("role", r.val)}
                              >
                                <div style={{ fontSize: 22, marginBottom: 6 }}>
                                  {r.icon}
                                </div>
                                <div
                                  style={{
                                    fontSize: 13,
                                    fontWeight: 700,
                                    color:
                                      form.role === r.val
                                        ? "#6366f1"
                                        : "#374151",
                                    marginBottom: 3,
                                  }}
                                >
                                  {r.label}
                                </div>
                                <div
                                  style={{
                                    fontSize: 10.5,
                                    color: "#94a3b8",
                                    lineHeight: 1.4,
                                  }}
                                >
                                  {r.desc}
                                </div>
                              </button>
                            ))}
                          </div>
                        </div>
                      </>
                    )}

                    {/* STEP 2: Confirm */}
                    {step === 2 && (
                      <>
                        {/* Summary Card */}
                        <div
                          className={`fade-up d2 ${mounted ? "show" : ""}`}
                          style={{
                            background: "#f8fafc",
                            border: "1.5px solid #e2e8f0",
                            borderRadius: 16,
                            padding: "24px",
                            marginBottom: 28,
                          }}
                        >
                          <div
                            style={{
                              fontSize: 13,
                              fontWeight: 700,
                              color: "#374151",
                              marginBottom: 16,
                              letterSpacing: "0.04em",
                              textTransform: "uppercase",
                            }}
                          >
                            Account Summary
                          </div>
                          {[
                            { label: "Email", value: form.email, icon: "✉️" },
                            { label: "Name", value: form.name, icon: "👤" },
                            {
                              label: "Role",
                              value: roles.find((r) => r.val === form.role)
                                ?.label,
                              icon: "🎭",
                            },
                            ...(form.phone
                              ? [
                                  {
                                    label: "Phone",
                                    value: form.phone,
                                    icon: "📱",
                                  },
                                ]
                              : []),
                          ].map((item, i) => (
                            <div
                              key={i}
                              style={{
                                display: "flex",
                                alignItems: "center",
                                gap: 12,
                                paddingBottom: 12,
                                marginBottom: 12,
                                borderBottom:
                                  i < 2 || form.phone
                                    ? "1px solid #f1f5f9"
                                    : "none",
                              }}
                            >
                              <span style={{ fontSize: 16 }}>{item.icon}</span>
                              <div>
                                <div
                                  style={{
                                    fontSize: 11,
                                    color: "#94a3b8",
                                    fontWeight: 600,
                                  }}
                                >
                                  {item.label}
                                </div>
                                <div
                                  style={{
                                    fontSize: 13,
                                    color: "#0f172a",
                                    fontWeight: 600,
                                  }}
                                >
                                  {item.value}
                                </div>
                              </div>
                              <button
                                type="button"
                                onClick={() => setStep(i < 2 ? 0 : 1)}
                                style={{
                                  marginLeft: "auto",
                                  fontSize: 11,
                                  color: "#6366f1",
                                  fontWeight: 600,
                                  background: "none",
                                  border: "none",
                                  cursor: "pointer",
                                }}
                              >
                                Edit
                              </button>
                            </div>
                          ))}
                        </div>

                        {/* Terms */}
                        <div
                          className={`fade-up d3 ${mounted ? "show" : ""}`}
                          style={{ marginBottom: 8 }}
                        >
                          <label
                            style={{
                              display: "flex",
                              alignItems: "flex-start",
                              gap: 10,
                              cursor: "pointer",
                            }}
                          >
                            <div
                              className={`check-box ${form.agree ? "checked" : ""}`}
                              style={{ marginTop: 2 }}
                              onClick={() => set("agree", !form.agree)}
                            >
                              {form.agree && (
                                <svg
                                  width="11"
                                  height="11"
                                  fill="none"
                                  viewBox="0 0 12 12"
                                  stroke="white"
                                  strokeWidth={2.5}
                                >
                                  <path d="M2 6l3 3 5-5" />
                                </svg>
                              )}
                            </div>
                            <span
                              style={{
                                fontSize: 13,
                                color: "#64748b",
                                lineHeight: 1.6,
                              }}
                            >
                              I agree to EduVerse's{" "}
                              <a
                                href="#"
                                style={{
                                  color: "#6366f1",
                                  fontWeight: 600,
                                  textDecoration: "none",
                                }}
                              >
                                Terms of Service
                              </a>{" "}
                              and{" "}
                              <a
                                href="#"
                                style={{
                                  color: "#6366f1",
                                  fontWeight: 600,
                                  textDecoration: "none",
                                }}
                              >
                                Privacy Policy
                              </a>
                            </span>
                          </label>
                          <div style={{ minHeight: 20, marginTop: 4 }}>
                            {errors.agree && (
                              <p className="err-msg" style={{ marginLeft: 28 }}>
                                <svg
                                  width="12"
                                  height="12"
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path
                                    fillRule="evenodd"
                                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                                  />
                                </svg>
                                {errors.agree}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Newsletter */}
                        <div
                          className={`fade-up d4 ${mounted ? "show" : ""}`}
                          style={{ marginBottom: 28 }}
                        >
                          <label
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: 10,
                              cursor: "pointer",
                            }}
                          >
                            <div
                              className={`check-box ${form.newsletter ? "checked" : ""}`}
                              onClick={() =>
                                set("newsletter", !form.newsletter)
                              }
                            >
                              {form.newsletter && (
                                <svg
                                  width="11"
                                  height="11"
                                  fill="none"
                                  viewBox="0 0 12 12"
                                  stroke="white"
                                  strokeWidth={2.5}
                                >
                                  <path d="M2 6l3 3 5-5" />
                                </svg>
                              )}
                            </div>
                            <span style={{ fontSize: 13, color: "#64748b" }}>
                              Send me course recommendations & learning tips
                            </span>
                          </label>
                        </div>
                      </>
                    )}

                    {/* Navigation Buttons */}
                    <div
                      className={`fade-up d5 ${mounted ? "show" : ""} btn-row`}
                      style={{ display: "flex", gap: 12, marginTop: 8 }}
                    >
                      {step > 0 && (
                        <button
                          type="button"
                          className="back-btn"
                          onClick={prevStep}
                        >
                          <svg
                            width="15"
                            height="15"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth={2.5}
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M7 16l-4-4m0 0l4-4m-4 4h18"
                            />
                          </svg>
                          Back
                        </button>
                      )}
                      {step < 2 ? (
                        <button type="submit" className="next-btn">
                          Continue
                          <svg
                            width="15"
                            height="15"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth={2.5}
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M17 8l4 4m0 0l-4 4m4-4H3"
                            />
                          </svg>
                        </button>
                      ) : (
                        <button
                          type="submit"
                          className="submit-btn"
                          disabled={loading}
                          style={{ flex: 1 }}
                        >
                          {loading ? (
                            <>
                              <svg
                                className="spinner"
                                width="18"
                                height="18"
                                fill="none"
                                viewBox="0 0 24 24"
                              >
                                <circle
                                  cx="12"
                                  cy="12"
                                  r="10"
                                  stroke="rgba(255,255,255,0.3)"
                                  strokeWidth="3"
                                />
                                <path
                                  d="M12 2a10 10 0 0110 10"
                                  stroke="white"
                                  strokeWidth="3"
                                  strokeLinecap="round"
                                />
                              </svg>
                              Creating Account...
                            </>
                          ) : (
                            <>
                              Create My Account
                              <svg
                                width="17"
                                height="17"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                strokeWidth={2.5}
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  d="M17 8l4 4m0 0l-4 4m4-4H3"
                                />
                              </svg>
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </form>

                  <div
                    className={`fade-up d5 ${mounted ? "show" : ""}`}
                    style={{
                      marginTop: 32,
                      paddingTop: 24,
                      borderTop: "1px solid #f1f5f9",
                      textAlign: "center",
                    }}
                  >
                    <p className="text-gray-500" style={{ fontSize: 12 }}>
                      © 2025 EduVerse ·{" "}
                      <a href="#" style={{ textDecoration: "none" }}>
                        Privacy Policy
                      </a>{" "}
                      ·{" "}
                      <a href="#" style={{ textDecoration: "none" }}>
                        Terms
                      </a>
                    </p>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
