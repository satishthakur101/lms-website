import { useState, useEffect } from "react";
import Header from "../web/layout/Header";

const stats = [
  { number: "50K+", label: "Active Learners" },
  { number: "1,200+", label: "Courses" },
  { number: "98%", label: "Success Rate" },
];

const features = [
  { icon: "🎯", text: "Personalized Learning Paths" },
  { icon: "🏆", text: "Certified Achievements" },
  { icon: "🤝", text: "Live Mentorship Sessions" },
];

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [remember, setRemember] = useState(false);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [focusedField, setFocusedField] = useState(null);

  useEffect(() => {
    setTimeout(() => setMounted(true), 80);
  }, []);

  const validate = () => {
    const e = {};
    if (!email.trim()) e.email = "Email address is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      e.email = "Enter a valid email address";
    if (!password) e.password = "Password is required";
    else if (password.length < 6) e.password = "Minimum 6 characters required";
    return e;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1800));
    setLoading(false);
    setSuccess(true);
  };

  const clearError = (field) => {
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=DM+Sans:wght@300;400;500;600;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #fff; }
        .fade-up {
          opacity: 0;
          transform: translateY(24px);
          transition: opacity 0.65s cubic-bezier(.22,1,.36,1), transform 0.65s cubic-bezier(.22,1,.36,1);
        }
        .fade-up.show { opacity: 1; transform: translateY(0); }
        .fade-up.d1 { transition-delay: 0.05s; }
        .fade-up.d2 { transition-delay: 0.12s; }
        .fade-up.d3 { transition-delay: 0.19s; }
        .fade-up.d4 { transition-delay: 0.26s; }
        .fade-up.d5 { transition-delay: 0.33s; }
        .fade-up.d6 { transition-delay: 0.40s; }
        .left-panel {
          background: linear-gradient(160deg, #0f172a 0%, #1e293b 60%, #0f2027 100%);
          position: relative;
          overflow: hidden;
        }
        .left-panel::before {
          content: '';
          position: absolute;
          top: -80px; left: -80px;
          width: 400px; height: 400px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(99,102,241,0.18) 0%, transparent 70%);
          pointer-events: none;
        }
        .left-panel::after {
          content: '';
          position: absolute;
          bottom: -60px; right: -60px;
          width: 320px; height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(16,185,129,0.12) 0%, transparent 70%);
          pointer-events: none;
        }
        .grid-lines {
          position: absolute;
          inset: 0;
          background-image: 
            linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px);
          background-size: 48px 48px;
          pointer-events: none;
        }
        .float-card {
        //   background: rgba(255,255,255,0.05);
        
          border: 1px solid rgba(255,255,255,0.1);
        //   backdrop-filter: blur(12px);
          border-radius: 16px;
          padding: 20px 24px;
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .float-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 12px 32px rgba(0,0,0,0.3);
        }
        .input-wrap {
          position: relative;
          margin-bottom: 4px;
        }
        .lms-input {
          width: 100%;
          padding: 14px 16px 14px 46px;
          border-radius: 12px;
          border: 1.5px solid #e2e8f0;
          font-family: 'DM Sans', sans-serif;
          font-size: 14px;
          font-weight: 500;
          color: #0f172a;
          background: #f8fafc;
          outline: none;
          transition: all 0.2s ease;
        }
        .lms-input::placeholder { color: #94a3b8; font-weight: 400; }
        .lms-input:focus {
          border-color: #6366f1;
          background: #fff;
          box-shadow: 0 0 0 4px rgba(99,102,241,0.08);
        }
        .lms-input.error-state {
          border-color: #f43f5e;
          background: #fff5f7;
          box-shadow: 0 0 0 4px rgba(244,63,94,0.07);
        }
        .input-icon {
          position: absolute;
          left: 14px;
          top: 50%;
          transform: translateY(-50%);
          color: #94a3b8;
          transition: color 0.2s;
          pointer-events: none;
        }
        .input-icon.active { color: #6366f1; }
        .input-icon.error { color: #f43f5e; }
        .toggle-btn {
          position: absolute;
          right: 14px;
          top: 50%;
          transform: translateY(-50%);
          background: none;
          border: none;
          cursor: pointer;
          color: #94a3b8;
          display: flex;
          align-items: center;
          transition: color 0.2s;
        }
        .toggle-btn:hover { color: #6366f1; }
        .err-msg {
          font-size: 11.5px;
          color: #f43f5e;
          margin-top: 5px;
          display: flex;
          align-items: center;
          gap: 4px;
          font-family: 'DM Sans', sans-serif;
          font-weight: 500;
          min-height: 18px;
        }
        .submit-btn {
          width: 100%;
          padding: 15px;
          border-radius: 12px;
          border: none;
          background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
          color: white;
          font-family: 'DM Sans', sans-serif;
          font-size: 15px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.25s ease;
          box-shadow: 0 4px 20px rgba(99,102,241,0.35);
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          letter-spacing: 0.01em;
        }
        .submit-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 8px 28px rgba(99,102,241,0.45);
          background: linear-gradient(135deg, #818cf8 0%, #6366f1 100%);
        }
        .submit-btn:active:not(:disabled) { transform: translateY(0); }
        .submit-btn:disabled { opacity: 0.7; cursor: not-allowed; }
        .social-btn {
          flex: 1;
          padding: 12px;
          border-radius: 10px;
          border: 1.5px solid #e2e8f0;
          background: #fff;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          font-family: 'DM Sans', sans-serif;
          font-size: 13px;
          font-weight: 600;
          color: #374151;
          transition: all 0.2s ease;
        }
        .social-btn:hover {
          border-color: #6366f1;
          background: #f5f3ff;
          color: #6366f1;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(99,102,241,0.1);
        }
        .stat-pill {
          background: rgba(255,255,255,0.08);
          border: 1px solid rgba(255,255,255,0.12);
          border-radius: 12px;
          padding: 16px 20px;
          text-align: center;
        }
        .check-box {
          width: 18px;
          height: 18px;
          border-radius: 5px;
          border: 1.5px solid #cbd5e1;
          background: #fff;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
          flex-shrink: 0;
        }
        .check-box.checked {
          background: #6366f1;
          border-color: #6366f1;
        }
        .divider-line {
          display: flex;
          align-items: center;
          gap: 12px;
          margin: 20px 0;
        }
        .divider-line::before, .divider-line::after {
          content: '';
          flex: 1;
          height: 1px;
          background: #e2e8f0;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        .spinner { animation: spin 0.8s linear infinite; }
        @keyframes checkPop {
          0% { transform: scale(0.5); opacity: 0; }
          70% { transform: scale(1.1); }
          100% { transform: scale(1); opacity: 1; }
        }
        .check-pop { animation: checkPop 0.4s cubic-bezier(.34,1.56,.64,1) forwards; }
        @media (max-width: 900px) {
          .split-layout { flex-direction: column !important; }
          .left-panel { min-height: 260px !important; width: 100% !important; }
          .right-panel { width: 100% !important; padding: 40px 24px !important; }
        }
        @media (max-width: 480px) {
          .right-panel { padding: 32px 20px !important; }
          .social-row { flex-direction: column !important; }
        }
      `}</style>
      <Header />
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "stretch",
          fontFamily: "'DM Sans', sans-serif",
          background: "#fff",
        }}
      >
        <div
          className="split-layout"
          style={{ display: "flex", width: "100%", minHeight: "100vh" }}
        >
          {/* ── LEFT PANEL ── */}
          <div
            className="left-panel"
            style={{
              width: "42%",
              minHeight: "100vh",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              padding: "52px 48px",
              position: "relative",
               backgroundImage:
                "url('./bg-img-login.jpg')",
              backgroundSize: "cover",
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat",
            }}
          >
            <div className="grid-lines" />

            {/* Logo */}
            <div style={{ position: "relative", zIndex: 2 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div
                  style={{
                    width: 42,
                    height: 42,
                    borderRadius: 12,
                    background: "linear-gradient(135deg,#6366f1,#4f46e5)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    boxShadow: "0 4px 16px rgba(99,102,241,0.4)",
                  }}
                >
                  <svg
                    width="22"
                    height="22"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="white"
                    strokeWidth="2.2"
                  >
                    <path d="M12 2L2 7l10 5 10-5-10-5z" />
                    <path d="M2 17l10 5 10-5" />
                    <path d="M2 12l10 5 10-5" />
                  </svg>
                </div>
                <span
                  style={{
                    fontFamily: "'Instrument Serif', serif",
                    fontSize: 22,
                    color: "#fff",
                    letterSpacing: "-0.02em",
                  }}
                >
                  EduVerse
                </span>
              </div>
            </div>

            {/* Center Content */}
            <div
              style={{
                position: "relative",
                zIndex: 2,
                flex: 1,
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                paddingTop: 48,
                paddingBottom: 48,
              }}
            >
              <div
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 8,
                  background: "rgba(99,102,241,0.2)",
                  border: "1px solid rgba(99,102,241,0.35)",
                  borderRadius: 100,
                  padding: "6px 14px",
                  marginBottom: 24,
                  width: "fit-content",
                }}
              >
                <div
                  style={{
                    width: 6,
                    height: 6,
                    borderRadius: "50%",
                    background: "#a5b4fc",
                  }}
                />
                <span
                  style={{
                    fontSize: 12,
                    color: "#a5b4fc",
                    fontWeight: 600,
                    letterSpacing: "0.04em",
                  }}
                >
                  TRUSTED BY 50,000+ LEARNERS
                </span>
              </div>

              <h1
                style={{
                  fontFamily: "'Instrument Serif', serif",
                  fontSize: "clamp(32px, 4vw, 46px)",
                  color: "#fff",
                  lineHeight: 1.2,
                  marginBottom: 18,
                  letterSpacing: "-0.02em",
                }}
              >
                Unlock Your Full
                <br />
                <span style={{ fontStyle: "italic", color: "#a5b4fc" }}>
                  Learning Potential
                </span>
              </h1>
              <p
                style={{
                  fontSize: 15,
                  color: "rgba(255,255,255,0.55)",
                  lineHeight: 1.7,
                  marginBottom: 36,
                  maxWidth: 340,
                  fontWeight: 400,
                }}
              >
                Access world-class courses, live mentors, and a thriving
                community — all in one powerful platform.
              </p>

              {/* Features */}
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: 14,
                  marginBottom: 44,
                }}
              >
                {features.map((f, i) => (
                  <div
                    key={i}
                    style={{ display: "flex", alignItems: "center", gap: 12 }}
                  >
                    <div
                      style={{
                        width: 36,
                        height: 36,
                        borderRadius: 10,
                        background: "rgba(255,255,255,0.07)",
                        border: "1px solid rgba(255,255,255,0.1)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 16,
                        flexShrink: 0,
                      }}
                    >
                      {f.icon}
                    </div>
                    <span
                      style={{
                        fontSize: 14,
                        color: "rgba(255,255,255,0.75)",
                        fontWeight: 500,
                      }}
                    >
                      {f.text}
                    </span>
                  </div>
                ))}
              </div>

              {/* Stats */}
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(3,1fr)",
                  gap: 12,
                }}
              >
                {stats.map((s, i) => (
                  <div key={i} className="stat-pill">
                    <div
                      style={{
                        fontFamily: "'Instrument Serif', serif",
                        fontSize: 26,
                        color: "#fff",
                        lineHeight: 1,
                      }}
                    >
                      {s.number}
                    </div>
                    <div
                      style={{
                        fontSize: 11,
                        color: "rgba(255,255,255,0.45)",
                        marginTop: 4,
                        fontWeight: 500,
                      }}
                    >
                      {s.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom quote */}
            <div
              className="float-card bg-[#15141480]"
              style={{ position: "relative", zIndex: 2 }}
            >
              <p
                style={{
                  fontSize: 13,
                  color: "rgba(255,255,255,0.65)",
                  lineHeight: 1.6,
                  fontStyle: "italic",
                  marginBottom: 12,
                }}
              >
                "EduVerse completely transformed how I approach learning. The
                structured paths are incredible."
              </p>
            
            </div>
          </div>

          {/* ── RIGHT PANEL ── */}
          <div
            className="right-panel"
            style={{
              width: "58%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: "60px 72px",
              background: "#fff",
              overflowY: "auto",
            }}
          >
            <div style={{ width: "100%", maxWidth: 420 }}>
              {success ? (
                /* SUCCESS */
                <div style={{ textAlign: "center", padding: "40px 0" }}>
                  <div
                    className="check-pop"
                    style={{
                      width: 80,
                      height: 80,
                      borderRadius: "50%",
                      background: "linear-gradient(135deg,#6366f1,#4f46e5)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      margin: "0 auto 28px",
                    }}
                  >
                    <svg
                      width="38"
                      height="38"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="white"
                      strokeWidth="2.5"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                  </div>
                  <h2
                    style={{
                      fontFamily: "'Instrument Serif', serif",
                      fontSize: 30,
                      color: "#0f172a",
                      marginBottom: 12,
                    }}
                  >
                    Welcome Back! 🎉
                  </h2>
                  <p
                    style={{ fontSize: 15, color: "#64748b", marginBottom: 32 }}
                  >
                    You've successfully signed in. Redirecting to your
                    dashboard...
                  </p>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: 8,
                    }}
                  >
                    <svg
                      className="spinner"
                      width="18"
                      height="18"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="#e2e8f0"
                        strokeWidth="3"
                      />
                      <path
                        d="M12 2a10 10 0 0110 10"
                        stroke="#6366f1"
                        strokeWidth="3"
                        strokeLinecap="round"
                      />
                    </svg>
                    <span style={{ fontSize: 13, color: "#94a3b8" }}>
                      Loading your dashboard...
                    </span>
                  </div>
                </div>
              ) : (
                <>
                  {/* Header */}
                  <div
                    className={`fade-up d1 ${mounted ? "show" : ""}`}
                    style={{ marginBottom: 36 }}
                  >
                    <p
                      style={{
                        fontSize: 13,
                        color: "#6366f1",
                        fontWeight: 700,
                        letterSpacing: "0.08em",
                        marginBottom: 8,
                        textTransform: "uppercase",
                      }}
                    >
                      Welcome back
                    </p>
                    <h2
                      style={{
                        fontFamily: "'Instrument Serif', serif",
                        fontSize: "clamp(26px,3vw,34px)",
                        color: "#0f172a",
                        lineHeight: 1.2,
                        letterSpacing: "-0.02em",
                        marginBottom: 8,
                      }}
                    >
                      Sign in to your account
                    </h2>
                    <p
                      style={{
                        fontSize: 14,
                        color: "#94a3b8",
                        fontWeight: 400,
                      }}
                    >
                      Don't have an account?{" "}
                      <a
                        href="/register"
                        style={{
                          color: "#6366f1",
                          fontWeight: 600,
                          textDecoration: "none",
                        }}
                        onMouseOver={(e) =>
                          (e.target.style.textDecoration = "underline")
                        }
                        onMouseOut={(e) =>
                          (e.target.style.textDecoration = "none")
                        }
                      >
                        Create one free →
                      </a>
                    </p>
                  </div>

                  <form onSubmit={handleSubmit} noValidate>
                    {/* Email */}
                    <div
                      className={`fade-up d2 ${mounted ? "show" : ""}`}
                      style={{ marginBottom: 8 }}
                    >
                      <label
                        style={{
                          display: "block",
                          fontSize: 13,
                          fontWeight: 600,
                          color: "#374151",
                          marginBottom: 7,
                        }}
                      >
                        Email Address
                      </label>
                      <div className="input-wrap">
                        <span
                          className={`input-icon ${focusedField === "email" ? "active" : ""} ${errors.email ? "error" : ""}`}
                        >
                          <svg
                            width="16"
                            height="16"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth={2}
                          >
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                            <polyline points="22,6 12,13 2,6" />
                          </svg>
                        </span>
                        <input
                          className={`lms-input ${errors.email ? "error-state" : ""}`}
                          type="email"
                          placeholder="you@example.com"
                          value={email}
                          onChange={(e) => {
                            setEmail(e.target.value);
                            clearError("email");
                          }}
                          onFocus={() => setFocusedField("email")}
                          onBlur={() => setFocusedField(null)}
                        />
                      </div>
                      <div style={{ minHeight: 20 }}>
                        {errors.email && (
                          <p className="err-msg">
                            <svg
                              width="12"
                              height="12"
                              fill="currentColor"
                              viewBox="0 0 20 20"
                            >
                              <path
                                fillRule="evenodd"
                                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                              />
                            </svg>
                            {errors.email}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Password */}
                    <div
                      className={`fade-up d3 ${mounted ? "show" : ""}`}
                      style={{ marginBottom: 8 }}
                    >
                      <label
                        style={{
                          display: "block",
                          fontSize: 13,
                          fontWeight: 600,
                          color: "#374151",
                          marginBottom: 7,
                        }}
                      >
                        Password
                      </label>
                      <div className="input-wrap">
                        <span
                          className={`input-icon ${focusedField === "password" ? "active" : ""} ${errors.password ? "error" : ""}`}
                        >
                          <svg
                            width="16"
                            height="16"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth={2}
                          >
                            <rect
                              x="3"
                              y="11"
                              width="18"
                              height="11"
                              rx="2"
                              ry="2"
                            />
                            <path d="M7 11V7a5 5 0 0110 0v4" />
                          </svg>
                        </span>
                        <input
                          className={`lms-input ${errors.password ? "error-state" : ""}`}
                          style={{ paddingRight: 46 }}
                          type={showPass ? "text" : "password"}
                          placeholder="Enter your password"
                          value={password}
                          onChange={(e) => {
                            setPassword(e.target.value);
                            clearError("password");
                          }}
                          onFocus={() => setFocusedField("password")}
                          onBlur={() => setFocusedField(null)}
                        />
                        <button
                          type="button"
                          className="toggle-btn"
                          onClick={() => setShowPass((p) => !p)}
                        >
                          {showPass ? (
                            <svg
                              width="17"
                              height="17"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                              strokeWidth={2}
                            >
                              <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94" />
                              <path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19" />
                              <line x1="1" y1="1" x2="23" y2="23" />
                            </svg>
                          ) : (
                            <svg
                              width="17"
                              height="17"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                              strokeWidth={2}
                            >
                              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                              <circle cx="12" cy="12" r="3" />
                            </svg>
                          )}
                        </button>
                      </div>
                      <div style={{ minHeight: 20 }}>
                        {errors.password && (
                          <p className="err-msg">
                            <svg
                              width="12"
                              height="12"
                              fill="currentColor"
                              viewBox="0 0 20 20"
                            >
                              <path
                                fillRule="evenodd"
                                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                              />
                            </svg>
                            {errors.password}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Remember + Forgot */}
                    <div
                      className={`fade-up d3 ${mounted ? "show" : ""}`}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        marginBottom: 28,
                        marginTop: 4,
                      }}
                    >
                      <label
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 9,
                          cursor: "pointer",
                        }}
                      >
                        <div
                          className={`check-box ${remember ? "checked" : ""}`}
                          onClick={() => setRemember((p) => !p)}
                        >
                          {remember && (
                            <svg
                              width="11"
                              height="11"
                              fill="none"
                              viewBox="0 0 12 12"
                              stroke="white"
                              strokeWidth={2.5}
                            >
                              <path d="M2 6l3 3 5-5" />
                            </svg>
                          )}
                        </div>
                        <span
                          style={{
                            fontSize: 13,
                            color: "#64748b",
                            fontWeight: 500,
                          }}
                        >
                          Remember me
                        </span>
                      </label>
                      <a
                        href="/forgot-password"
                        style={{
                          fontSize: 13,
                          color: "#6366f1",
                          fontWeight: 600,
                          textDecoration: "none",
                        }}
                        onMouseOver={(e) =>
                          (e.target.style.textDecoration = "underline")
                        }
                        onMouseOut={(e) =>
                          (e.target.style.textDecoration = "none")
                        }
                      >
                        Forgot password?
                      </a>
                    </div>

                    {/* Submit */}
                    <div className={`fade-up d4 ${mounted ? "show" : ""}`}>
                      <button
                        type="submit"
                        className="submit-btn"
                        disabled={loading}
                      >
                        {loading ? (
                          <>
                            <svg
                              className="spinner"
                              width="18"
                              height="18"
                              fill="none"
                              viewBox="0 0 24 24"
                            >
                              <circle
                                cx="12"
                                cy="12"
                                r="10"
                                stroke="rgba(255,255,255,0.3)"
                                strokeWidth="3"
                              />
                              <path
                                d="M12 2a10 10 0 0110 10"
                                stroke="white"
                                strokeWidth="3"
                                strokeLinecap="round"
                              />
                            </svg>
                            Signing in...
                          </>
                        ) : (
                          <>
                            Sign In
                            <svg
                              width="17"
                              height="17"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                              strokeWidth={2.5}
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M17 8l4 4m0 0l-4 4m4-4H3"
                              />
                            </svg>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Divider */}
                    <div
                      className={`fade-up d5 ${mounted ? "show" : ""} divider-line`}
                    >
                      <span
                        className="text-gray-500"
                        style={{
                          fontSize: 12,
                          fontWeight: 500,
                          whiteSpace: "nowrap",
                        }}
                      >
                        or continue with
                      </span>
                    </div>

                    {/* Social */}
                    <div
                      className={`fade-up d5 ${mounted ? "show" : ""} social-row`}
                      style={{ display: "flex", gap: 12 }}
                    >
                      {[
                        {
                          name: "Google",
                          icon: (
                            <svg width="17" height="17" viewBox="0 0 24 24">
                              <path
                                fill="#EA4335"
                                d="M5.27 9.77A7.01 7.01 0 0112 5c1.78 0 3.38.67 4.6 1.77L19.9 3.5A11.77 11.77 0 0012 .5C7.27.5 3.2 3.51 1.27 7.78l4 3z"
                              />
                              <path
                                fill="#34A853"
                                d="M16.04 18.01A7 7 0 0112 19c-3.07 0-5.67-1.97-6.63-4.72l-4 3.07C3.19 21.49 7.3 23.5 12 23.5c3.13 0 6.1-1.14 8.32-3.15l-4.28-3.34z"
                              />
                              <path
                                fill="#4A90D9"
                                d="M20.32 20.35c2.32-2.18 3.68-5.4 3.68-9.35 0-.93-.1-1.65-.27-2.37H12v4.95h6.64c-.33 1.7-1.27 3.07-2.6 4.01l4.28 3.76z"
                              />
                              <path
                                fill="#FBBC05"
                                d="M5.37 14.28a7.1 7.1 0 01-.37-2.28c0-.8.14-1.57.37-2.28l-4-3.07A11.8 11.8 0 00.5 12c0 1.87.44 3.63 1.22 5.2l3.65-2.92z"
                              />
                            </svg>
                          ),
                        },
                        {
                          name: "Microsoft",
                          icon: (
                            <svg width="17" height="17" viewBox="0 0 21 21">
                              <rect
                                x="1"
                                y="1"
                                width="9"
                                height="9"
                                fill="#f25022"
                              />
                              <rect
                                x="11"
                                y="1"
                                width="9"
                                height="9"
                                fill="#7fba00"
                              />
                              <rect
                                x="1"
                                y="11"
                                width="9"
                                height="9"
                                fill="#00a4ef"
                              />
                              <rect
                                x="11"
                                y="11"
                                width="9"
                                height="9"
                                fill="#ffb900"
                              />
                            </svg>
                          ),
                        },
                      ].map((s) => (
                        <button
                          key={s.name}
                          type="button"
                          className="social-btn"
                        >
                          {s.icon}
                          {s.name}
                        </button>
                      ))}
                    </div>
                  </form>

                  {/* Footer */}
                  <div
                    className={`fade-up d6 ${mounted ? "show" : ""}`}
                    style={{
                      marginTop: 36,
                      paddingTop: 24,
                      borderTop: "1px solid #f1f5f9",
                      textAlign: "center",
                    }}
                  >
                    <p className="text-gray-400" style={{ fontSize: 12 }}>
                      © 2025 EduVerse ·{" "}
                      <a href="#" style={{ textDecoration: "none" }}>
                        Privacy Policy
                      </a>{" "}
                      ·{" "}
                      <a href="#" style={{ textDecoration: "none" }}>
                        Terms of Service
                      </a>
                    </p>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
