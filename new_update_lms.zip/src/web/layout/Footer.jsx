import { FaMapMarkerAlt, FaPhone, FaClock, FaLinkedinIn, FaTwitter, FaGooglePlusG } from "react-icons/fa";

// Simple world map SVG with dots (matches screenshot)
const WorldMap = () => (
  <a
    href="https://www.google.com/maps?q=kurukshetra"
    target="_blank"
    rel="noopener noreferrer"
  >
    <img
      src="./footer-map.png"
      alt="map"
      className="w-full h-auto cursor-pointer hover:scale-105 transition duration-300"
    />
  </a>
);

const supportLinks = [
   { name: "About", id: "about" },
  { name: "Blog", id: "blog" },
  { name: "Courses", id: "courses" },
  { name: "Our Mentors", id: "teachers" },
  { name: "Contact", id: "contact" },
];

export default function Footer() {

  // Smooth scroll function
  const handleScroll = (id) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <footer className="bg-[#1c1c1c] text-white font-sans">
      {/* Main Footer */}
      <div className="max-w-6xl mx-auto px-8 py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">

          {/* About Column */}
          <div>
            <h3 className="text-white font-bold text-lg mb-4">About</h3>
            <p className="text-gray-400 text-sm mb-6 leading-relaxed">
              Academist is dedicated to constant learning & knowledge sharing.
            </p>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-gray-400 text-sm">
                <FaMapMarkerAlt className="mt-1 shrink-0 text-gray-400" />
                <span>457 Mott Street, NY 10013</span>
              </li>
              <li className="flex items-center gap-3 text-gray-400 text-sm">
                <FaPhone className="shrink-0 text-gray-400" />
                <span>+44 300 303 0266</span>
              </li>
              <li className="flex items-center gap-3 text-gray-400 text-sm">
                <FaClock className="shrink-0 text-gray-400" />
                <span>Mon – Sat 8.00 – 18.00</span>
              </li>
            </ul>
          </div>

          {/* Popular Courses Column */}
          <div>
            <h3 className="text-white font-bold text-lg mb-4">Popular courses</h3>
            <ul className="space-y-5">
              <li>
                <a href="#" className="text-white font-bold text-sm hover:text-gray-300 transition-colors">
                  Leadership Skills
                </a>
                <p className="text-gray-400 text-sm mt-1">Mark Hook</p>
              </li>
              <li>
                <a href="#" className="text-white font-bold text-sm hover:text-gray-300 transition-colors">
                  Typography Design
                </a>
                <p className="text-gray-400 text-sm mt-1">Una Anston</p>
              </li>
              <li>
                <a href="#" className="text-white font-bold text-sm hover:text-gray-300 transition-colors">
                  Learn German
                </a>
                <p className="text-gray-400 text-sm mt-1">Scott Brown</p>
              </li>
            </ul>
          </div>

          {/* Support Column */}
          <div>
            <h3 className="text-white font-bold text-lg mb-4">Support</h3>
            <ul className="space-y-3">
              {supportLinks.map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => handleScroll(link.id)}
                    className="text-gray-400 text-sm hover:text-white transition-colors"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Flexible Learning Column */}
          <div>
            <h3 className="text-white font-bold text-lg mb-4">Flexible learning</h3>
            <WorldMap />
          </div>

        </div>
      </div>

      {/* Bottom Bar */}
      <div className="bg-[#161616] border-t border-[#2a2a2a]">
        <div className="max-w-6xl mx-auto px-8 py-4 flex items-center justify-between">
          <p className="text-gray-500 text-sm">
            © 2018 Qode Interactive, All Rights Reserved
          </p>
          <div className="flex items-center gap-6">
            <span className="text-gray-400 text-sm">Call +44 300 303 026</span>
            <div className="flex items-center gap-3">
              <span className="text-gray-400 text-sm">Follow us</span>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <FaLinkedinIn size={14} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <FaTwitter size={14} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <FaGooglePlusG size={16} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

// import React, { useState, useEffect } from "react";
// import {
//   FaFacebookF,
//   FaTwitter,
//   FaGooglePlusG,
//   FaPinterestP,
//   FaChevronDown,
//   FaGraduationCap,
// } from "react-icons/fa";
// import { motion } from "framer-motion";

// // ── Animation Variants ───────────────────────────────
// const container = {
//   hidden: {},
//   show: {
//     transition: {
//       staggerChildren: 0.2, // delay between children
//     },
//   },
// };

// const item = {
//   hidden: { opacity: 0, y: 10 },
//   show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
// };

// // ── Top Bar ─────────────────────────────────────────
// const TopBar = () => {
//   const [email, setEmail] = useState("");
//   const [category, setCategory] = useState("");
//   const [animateKey, setAnimateKey] = useState(0); // key to reset animation

//   useEffect(() => {
//     setAnimateKey((prev) => prev + 1); // trigger animation on mount
//   }, []);

//   const onlineUsers = [
//     { img: "/st1.jpg", online: true },
//     { img: "/st2.jpg", online: false },
//     { img: "/st3.jpg", online: true },
//     { img: "/st1.jpg", online: false },
//   ];

//   return (
//     <div
//       style={{
//         backgroundImage: "url('./foter-bg.png')",
//         backgroundSize: "cover",
//         backgroundPosition: "center",
//         backgroundRepeat: "no-repeat",
//       }}
//     >
//       <motion.div
//         key={animateKey} // 🔑 triggers animation on each mount
//         variants={container}
//         initial="hidden"
//         animate="show"
//         style={{
//           maxWidth: "1100px",
//           margin: "0 auto",
//           padding: "18px 24px",
//           display: "grid",
//           gridTemplateColumns: "1fr 1fr 1fr 1fr",
//           gap: "24px",
//           alignItems: "start",
//         }}
//       >
//         {/* Online Users */}
//         <motion.div variants={container}>
//           <motion.h4 style={topHeading} variants={item}>
//             Online
//           </motion.h4>
//           <motion.div
//             style={{ display: "flex", gap: "6px", marginTop: "10px" }}
//             variants={container}
//           >
//             {onlineUsers.map((u, i) => (
//               <motion.div key={i} style={{ position: "relative" }} variants={item}>
//                 <img
//                   src={u.img}
//                   alt="user"
//                   style={{ width: "46px", height: "46px", objectFit: "cover" }}
//                 />
//                 <span
//                   style={{
//                     position: "absolute",
//                     bottom: "2px",
//                     right: "2px",
//                     width: "9px",
//                     height: "9px",
//                     borderRadius: "50%",
//                     backgroundColor: u.online ? "#4caf50" : "transparent",
//                     border: u.online ? "1.5px solid #222" : "none",
//                   }}
//                 />
//               </motion.div>
//             ))}
//           </motion.div>
//         </motion.div>

//         {/* Newsletter */}
//         <motion.div variants={container}>
//           <motion.h4 style={topHeading} variants={item}>
//             Newsletter
//           </motion.h4>
//           <motion.div style={{ display: "flex", marginTop: "10px" }} variants={item}>
//             <input
//               type="email"
//               placeholder="Enter email"
//               value={email}
//               onChange={(e) => setEmail(e.target.value)}
//               style={{
//                 flex: 1,
//                 padding: "10px 12px",
//                 background: "#1a1a1a",
//                 border: "1px solid #444",
//                 borderRight: "none",
//                 color: "#aaa",
//                 fontSize: "0.78rem",
//                 outline: "none",
//               }}
//             />
//             <button
//               style={{
//                 backgroundColor: "#f5a623",
//                 color: "#fff",
//                 border: "none",
//                 padding: "10px 16px",
//                 fontWeight: 700,
//                 fontSize: "0.78rem",
//                 cursor: "pointer",
//               }}
//             >
//               SUBSCRIBE
//             </button>
//           </motion.div>
//         </motion.div>

//         {/* Discussion Form */}
//         <motion.div variants={container}>
//           <motion.h4 style={topHeading} variants={item}>
//             Discussion Form
//           </motion.h4>
//           <motion.div style={{ position: "relative", marginTop: "10px" }} variants={item}>
//             <select
//               value={category}
//               onChange={(e) => setCategory(e.target.value)}
//               style={{
//                 width: "100%",
//                 padding: "10px 36px 10px 12px",
//                 background: "#1a1a1a",
//                 border: "1px solid #444",
//                 color: "#aaa",
//                 fontSize: "0.78rem",
//                 outline: "none",
//                 appearance: "none",
//                 cursor: "pointer",
//               }}
//             >
//               <option value="">Select Category</option>
//               <option value="english">English</option>
//               <option value="german">German</option>
//               <option value="spanish">Spanish</option>
//             </select>
//             <FaChevronDown
//               size={11}
//               style={{
//                 position: "absolute",
//                 right: "5px",
//                 top: "50%",
//                 transform: "translateY(-50%)",
//                 color: "#fff",
//                 background: "#f5a623",
//                 padding: "10px",
//                 boxSizing: "content-box",
//                 pointerEvents: "none",
//               }}
//             />
//           </motion.div>
//         </motion.div>

//         {/* Happening Now */}
//         <motion.div variants={container}>
//           <motion.h4 style={topHeading} variants={item}>
//             Happening Now
//           </motion.h4>
//           <motion.div
//             style={{
//               display: "flex",
//               alignItems: "center",
//               gap: "10px",
//               marginTop: "10px",
//             }}
//             variants={item}
//           >
//             <img
//               src="/st1.jpg"
//               alt="sunny"
//               style={{ width: "46px", height: "46px", objectFit: "cover", flexShrink: 0 }}
//             />
//             <p style={{ color: "#ccc", fontSize: "0.75rem", lineHeight: "1.5", margin: 0 }}>
//               <span style={{ color: "#f5a623", fontWeight: 700 }}>Sunny Valim</span> Has Unlocked the New badge
//             </p>
//           </motion.div>
//         </motion.div>
//       </motion.div>
//     </div>
//   );
// };

// // ── Bottom Footer ─────────────────────────────────────
// const BottomFooter = () => {
//   const [animateKey, setAnimateKey] = useState(0);
//   useEffect(() => {
//     setAnimateKey((prev) => prev + 1);
//   }, []);

//   const categories = [
//     "Lorem ipsum dolor sit amet.",
//     "Integer vitae tristique",
//     "Donec velit diam, fringilla",
//     "Lorem ipsum .",
//     "Korem ipsum dolor",
//   ];

//   const courses = [
//     {
//       img: "/course1.jpg",
//       title: "Donec velit diam",
//       desc: "Integer triagna. Praesent bibendum quam....",
//     },
//     {
//       img: "/course2.jpg",
//       title: "Donec velit diam",
//       desc: "Integer triagna. Praesent bibendum quam....",
//     },
//   ];

//   return (
//     <div style={{ backgroundColor: "#1e1e1e" }}>
//       <motion.div
//         key={animateKey}
//         variants={container}
//         initial="hidden"
//         animate="show"
//         style={{
//           maxWidth: "1100px",
//           margin: "0 auto",
//           padding: "40px 24px",
//           display: "grid",
//           gridTemplateColumns: "1.1fr 1.2fr 1fr 1fr",
//           gap: "32px",
//         }}
//       >
//         {/* Col 1 */}
//         <motion.div variants={container}>
//           <motion.div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "16px" }} variants={item}>
//             <FaGraduationCap size={22} style={{ color: "#fff" }} />
//             <span style={{ color: "#fff", fontWeight: 700, fontSize: "1.1rem" }}>
//               Learning <span style={{ color: "#f5a623", fontWeight: 400, fontStyle: "italic" }}>system</span>
//             </span>
//           </motion.div>

//           <motion.p style={{ color: "#888", fontSize: "0.76rem", lineHeight: "1.8", marginBottom: "22px" }} variants={item}>
//             Integer vitae triagna. Praesent bibendum quam tellus, quis rhoncus orci cursus vel. Aenean suscipilacerat elit sit amet lacinia.
//           </motion.p>

//           <motion.div style={{ display: "flex", gap: "8px" }} variants={item}>
//             {[FaFacebookF, FaTwitter, FaGooglePlusG, FaPinterestP].map((Icon, i) => (
//               <a
//                 key={i}
//                 href="#"
//                 style={{
//                   width: "32px",
//                   height: "32px",
//                   border: "1px solid #555",
//                   display: "flex",
//                   alignItems: "center",
//                   justifyContent: "center",
//                   color: "#aaa",
//                   textDecoration: "none",
//                   transition: "all 0.2s",
//                 }}
//                 onMouseEnter={(e) => {
//                   e.currentTarget.style.backgroundColor = "#f5a623";
//                   e.currentTarget.style.borderColor = "#f5a623";
//                   e.currentTarget.style.color = "#fff";
//                 }}
//                 onMouseLeave={(e) => {
//                   e.currentTarget.style.backgroundColor = "transparent";
//                   e.currentTarget.style.borderColor = "#555";
//                   e.currentTarget.style.color = "#aaa";
//                 }}
//               >
//                 <Icon size={13} />
//               </a>
//             ))}
//           </motion.div>
//         </motion.div>

//         {/* Col 2: Courses */}
//         <motion.div variants={container}>
//           <motion.h4 style={bottomHeading} variants={item}>Popular Course</motion.h4>
//           <motion.div style={{ display: "flex", flexDirection: "column", gap: "16px", marginTop: "16px" }} variants={container}>
//             {courses.map((c, i) => (
//               <motion.div key={i} style={{ display: "flex", gap: "12px", border: "1px solid #333", padding: "8px" }} variants={item}>
//                 <img src={c.img} alt={c.title} style={{ width: "68px", height: "60px", objectFit: "cover" }} />
//                 <div>
//                   <motion.p style={{ color: "#f5a623", fontWeight: 700, fontSize: "0.75rem", margin: "0 0 5px" }} variants={item}>
//                     {c.title}
//                   </motion.p>
//                   <motion.p style={{ color: "#888", fontSize: "0.72rem", lineHeight: "1.5", margin: 0 }} variants={item}>
//                     {c.desc}
//                   </motion.p>
//                 </div>
//               </motion.div>
//             ))}
//           </motion.div>
//         </motion.div>

//         {/* Col 3: Categories */}
//         <motion.div variants={container}>
//           <motion.h4 style={bottomHeading} variants={item}>Course Categories</motion.h4>
//           <motion.ul style={{ listStyle: "none", margin: "16px 0 0", padding: 0 }} variants={container}>
//             {categories.map((cat, i) => (
//               <motion.li key={i} style={{ borderBottom: "1px solid #333', padding: '9px 0" }} variants={item}>
//                 <a href="#" style={{ color: "#888", fontSize: "0.75rem", textDecoration: "none" }}
//                    onMouseEnter={(e) => (e.target.style.color = "#f5a623")}
//                    onMouseLeave={(e) => (e.target.style.color = "#888")}>
//                   {cat}
//                 </a>
//               </motion.li>
//             ))}
//           </motion.ul>
//         </motion.div>

//         {/* Col 4: Contacts */}
//         <motion.div variants={container}>
//           <motion.h4 style={bottomHeading} variants={item}>Contacts</motion.h4>
//           <motion.p style={{ color: "#888", fontSize: "0.75rem", lineHeight: "1.7", margin: "16px 0 16px" }} variants={item}>
//             Lorem ipit amet, consectetur adipiscing elit. Etiam at ma erat laoreet accumsan. Vivamus id dui nulla.
//           </motion.p>
//           <motion.div style={{ display: "flex", flexDirection: "column", gap: "8px" }} variants={container}>
//             {[
//               { label: "Address", val: "13/2 Elizabeth Street Melbourne VIC 3000, Australia" },
//               { label: "Phone no", val: "+61 3 8376 6284" },
//               { label: "Fax no", val: "+00 1234 56789" },
//               { label: "Email id", val: "lurning@system.com" },
//             ].map((row, i) => (
//               <motion.p key={i} style={{ color: "#888", fontSize: "0.73rem", lineHeight: "1.6", margin: 0 }} variants={item}>
//                 <span style={{ color: "#f5a623", fontWeight: 700 }}>{row.label}</span> : {row.val}
//               </motion.p>
//             ))}
//           </motion.div>
//         </motion.div>
//       </motion.div>
//     </div>
//   );
// };

// // ── Shared Styles ───────────────────────────────────
// const topHeading = {
//   color: "#f5a623",
//   fontSize: "0.9rem",
//   fontWeight: 700,
//   margin: 0,
//   letterSpacing: "0.02em",
// };

// const bottomHeading = {
//   color: "#ddd",
//   fontSize: "0.95rem",
//   fontWeight: 700,
//   margin: 0,
//   paddingBottom: "10px",
//   borderBottom: "1px solid #333",
//   letterSpacing: "0.02em",
// };

// // ── Main Export ─────────────────────────────────────
// export default function LearningFooter() {
//   return (
//     <footer>
//       <TopBar />
//       <BottomFooter />
//     </footer>
//   );
// }