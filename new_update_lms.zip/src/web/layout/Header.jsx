


// import { useEffect, useState, useRef } from "react";
// import { Link, useLocation } from "react-router-dom";
// import { FaFacebookF, FaInstagram, FaTwitter, FaLinkedinIn } from "react-icons/fa";
// import { Phone, Mail, Users, UserPlus, Menu, X, ChevronDown } from "lucide-react";

// export default function Header() {
//   const [scrolled, setScrolled] = useState(false);
//   const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
//   const [dropdownOpen, setDropdownOpen] = useState(false);

//   const dropdownRef = useRef();
//   const location = useLocation();

//   /* 🔥 NAV LINKS */
//   const navLinks = [
//     { name: "Home", path: "/" },
//     { name: "About", id: "about" },
//     {
//       name: "Explore",
//       dropdown: [
//         { name: "Our Mentors", id: "teachers" },
//         { name: "Student Success", id: "students" },
//         { name: "Platform Insights", id: "stats" },
//       ],
//     },
//     { name: "Blog", id: "blog" },
//     { name: "Courses", id: "courses" },
//     { name: "Contact", id: "contact" },
//   ];

//   /* 🔥 SCROLL EFFECT */
//   useEffect(() => {
//     const handleScrollEffect = () => {
//       setScrolled(window.scrollY > 20);
//     };
//     window.addEventListener("scroll", handleScrollEffect);
//     return () => window.removeEventListener("scroll", handleScrollEffect);
//   }, []);

//   /* 🔥 OUTSIDE CLICK CLOSE */
//   useEffect(() => {
//     const handleClickOutside = (e) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
//         setDropdownOpen(false);
//       }
//     };
//     document.addEventListener("mousedown", handleClickOutside);
//     return () => document.removeEventListener("mousedown", handleClickOutside);
//   }, []);

//   /* 🔥 SMOOTH SCROLL */
//   const handleScroll = (id) => {
//     if (location.pathname !== "/") {
//       window.location.href = "/#" + id;
//       return;
//     }

//     const section = document.getElementById(id);
//     if (section) {
//       const yOffset = -80;
//       const y =
//         section.getBoundingClientRect().top + window.pageYOffset + yOffset;

//       window.scrollTo({
//         top: y,
//         behavior: "smooth",
//       });
//     }
//   };

//   /* 🔥 HASH SCROLL */
//   useEffect(() => {
//     if (location.hash) {
//       const id = location.hash.replace("#", "");
//       setTimeout(() => {
//         handleScroll(id);
//       }, 100);
//     }
//   }, [location]);

//   return (
//     <>
//       <div className="fixed top-0 left-0 w-full z-50">
//         {/* 🔲 TOP BAR */}
//         <div className="bg-black">
//           <div className="text-white max-w-7xl mx-auto text-sm py-5 flex justify-between items-center px-4">
//             <div className="flex items-center gap-4">
//               <div className="flex items-center gap-2">
//                 <Phone className="w-4 h-4" />
//                 <span>+91-1234567890</span>
//               </div>
//               <div className="hidden sm:flex items-center gap-2">
//                 <Mail className="w-4 h-4" />
//                 <span>support@example.com</span>
//               </div>
//             </div>

//             <div className="hidden sm:flex gap-3">
//               <FaFacebookF className="w-4 h-4" />
//               <FaInstagram className="w-4 h-4" />
//               <FaTwitter className="w-4 h-4" />
//               <FaLinkedinIn className="w-4 h-4" />
//             </div>
//           </div>
//         </div>

//         {/* 🔷 HEADER */}
//         <header
//           className={`transition-all duration-300 ${
//             scrolled ? "bg-white/70 backdrop-blur-md shadow-md" : "bg-white"
//           }`}
//         >
//           <div className="max-w-7xl mx-auto flex items-center justify-between py-4 px-4">
//             {/* LOGO */}
//             <Link to="/" className="text-xl font-bold text-blue-800">
//               MyLogo
//             </Link>

//             {/* MOBILE BTN */}
//             <div className="md:hidden">
//               <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
//                 {mobileMenuOpen ? <X /> : <Menu />}
//               </button>
//             </div>

//             {/* DESKTOP NAV */}
//             <nav className="hidden md:flex gap-6 items-center text-gray-800">
//               {navLinks.map((link) =>
//                 link.path ? (
//                   <Link
//                     key={link.name}
//                     to={link.path}
//                     onClick={() => setDropdownOpen(false)}
//                     className="hover:text-blue-600"
//                   >
//                     {link.name}
//                   </Link>
//                 ) : link.dropdown ? (
//                   <div key={link.name} className="relative" ref={dropdownRef}>
//                     <button
//                       onClick={() => setDropdownOpen(!dropdownOpen)}
//                       className="hover:text-blue-600 flex items-center gap-1"
//                     >
//                       {link.name}

//                       <ChevronDown
//                         className={`w-4 h-4 transition-transform duration-300 ${
//                           dropdownOpen ? "rotate-180" : ""
//                         }`}
//                       />
//                     </button>

//                     {dropdownOpen && (
//                       <div className="absolute top-full mt-3 w-52 bg-white shadow-lg rounded-lg border border-gray-300 p-2 z-50">
//                         {link.dropdown.map((item) => (
//                           <button
//                             key={item.name}
//                             onClick={() => {
//                               handleScroll(item.id);
//                               setDropdownOpen(false);
//                             }}
//                             className="block w-full text-left px-3 py-2 text-sm rounded hover:bg-[#f16126] hover:text-white transition"
//                           >
//                             {item.name}
//                           </button>
//                         ))}
//                       </div>
//                     )}
//                   </div>
//                 ) : (
//                   <button
//                     key={link.name}
//                     onClick={() => {
//                       handleScroll(link.id);
//                       setDropdownOpen(false);
//                     }}
//                     className="hover:text-blue-600"
//                   >
//                     {link.name}
//                   </button>
//                 ),
//               )}
//             </nav>

//             {/* AUTH */}
//             <div className="hidden md:flex gap-2">
//               <Link
//                 to="/login"
//                 className="flex items-center gap-2 text-sm px-4 py-2 border border-[#f16126] text-[#f16126]"
//               >
//                 <UserPlus className="w-4 h-4" />
//                 Login
//               </Link>

//               <Link
//                 to="/signup"
//                 className="flex items-center gap-2 text-sm px-4 py-2 bg-[#f16126] text-white"
//               >
//                 <Users className="w-4 h-4" />
//                 Sign Up
//               </Link>
//             </div>
//           </div>

//           {/* 📱 MOBILE MENU */}
//           {mobileMenuOpen && (
//             <div className="md:hidden bg-white border-t px-4 py-2 space-y-2">
//               {navLinks.map((link) =>
//                 link.path ? (
//                   <Link
//                     key={link.name}
//                     to={link.path}
//                     onClick={() => setMobileMenuOpen(false)}
//                     className="block px-3 py-2"
//                   >
//                     {link.name}
//                   </Link>
//                 ) : link.dropdown ? (
//                   <div key={link.name}>
//                     <p className="px-3 py-2 font-semibold text-gray-600">
//                       {link.name}
//                     </p>

//                     {link.dropdown.map((item) => (
//                       <button
//                         key={item.name}
//                         onClick={() => {
//                           handleScroll(item.id);
//                           setMobileMenuOpen(false);
//                         }}
//                         className="block w-full text-left px-5 py-2 text-sm hover:bg-[#f16126] hover:text-white rounded"
//                       >
//                         {item.name}
//                       </button>
//                     ))}
//                   </div>
//                 ) : (
//                   <button
//                     key={link.name}
//                     onClick={() => {
//                       handleScroll(link.id);
//                       setMobileMenuOpen(false);
//                     }}
//                     className="block w-full text-left px-3 py-2"
//                   >
//                     {link.name}
//                   </button>
//                 ),
//               )}
//             </div>
//           )}
//         </header>
//       </div>

//       {/* HEADER SPACE */}
//       <div className="h-28 md:h-32"></div>
//     </>
//   );
// }


// import { useEffect, useState, useRef } from "react";
// import { Link, useLocation } from "react-router-dom";
// import { FaFacebookF, FaInstagram, FaTwitter, FaLinkedinIn } from "react-icons/fa";
// import { Phone, Mail, Users, UserPlus, Menu, X, ChevronDown } from "lucide-react";

// export default function Header() {
//   const [scrolled, setScrolled] = useState(false);
//   const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
//   const [dropdownOpen, setDropdownOpen] = useState(false);

//   const dropdownRef = useRef();
//   const location = useLocation();

//   /* 🔥 NAV LINKS */
//   const navLinks = [
//     { name: "Home", path: "/" },
//     { name: "About", id: "about" },
//     {
//       name: "Explore",
//       dropdown: [
//         { name: "Our Mentors", id: "teachers" },
//         { name: "Student Success", id: "students" },
//         { name: "Platform Insights", id: "stats" },
//       ],
//     },
//     { name: "Blog", id: "blog" },
//     { name: "Courses", id: "courses" },
//     { name: "Contact", id: "contact" },
//   ];

//   /* 🔥 SCROLL EFFECT */
//   useEffect(() => {
//     const handleScrollEffect = () => {
//       setScrolled(window.scrollY > 20);
//     };
//     window.addEventListener("scroll", handleScrollEffect);
//     return () => window.removeEventListener("scroll", handleScrollEffect);
//   }, []);

//   /* 🔥 OUTSIDE CLICK CLOSE */
//   useEffect(() => {
//     const handleClickOutside = (e) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
//         setDropdownOpen(false);
//       }
//     };
//     document.addEventListener("mousedown", handleClickOutside);
//     return () => document.removeEventListener("mousedown", handleClickOutside);
//   }, []);

//   /* 🔥 SMOOTH SCROLL */
//   const handleScroll = (id) => {
//     if (location.pathname !== "/") {
//       window.location.href = "/#" + id;
//       return;
//     }

//     const section = document.getElementById(id);
//     if (section) {
//       const yOffset = -80;
//       const y =
//         section.getBoundingClientRect().top + window.pageYOffset + yOffset;

//       window.scrollTo({
//         top: y,
//         behavior: "smooth",
//       });
//     }
//   };

//   /* 🔥 HASH SCROLL */
//   useEffect(() => {
//     if (location.hash) {
//       const id = location.hash.replace("#", "");
//       setTimeout(() => {
//         handleScroll(id);
//       }, 100);
//     }
//   }, [location]);

//   return (
//     <>
//       <div className="fixed top-0 left-0 w-full z-50">

//         {/* 🔲 TOP BAR — scroll par hide ho jata hai */}
//         <div
//           className={`bg-black overflow-hidden transition-all duration-500 ease-in-out ${
//             scrolled ? "max-h-0 opacity-0" : "max-h-20 opacity-100"
//           }`}
//         >
//           <div className="text-white max-w-7xl mx-auto text-sm py-5 flex justify-between items-center px-4">
//             <div className="flex items-center gap-4">
//               <div className="flex items-center gap-2">
//                 <Phone className="w-4 h-4" />
//                 <span>+91-1234567890</span>
//               </div>
//               <div className="hidden sm:flex items-center gap-2">
//                 <Mail className="w-4 h-4" />
//                 <span>support@example.com</span>
//               </div>
//             </div>

//             <div className="hidden sm:flex gap-3">
//               <FaFacebookF className="w-4 h-4" />
//               <FaInstagram className="w-4 h-4" />
//               <FaTwitter className="w-4 h-4" />
//               <FaLinkedinIn className="w-4 h-4" />
//             </div>
//           </div>
//         </div>

//         {/* 🔷 HEADER */}
//         <header
//           className={`transition-all duration-300 ${
//             scrolled ? "bg-white/70 backdrop-blur-md shadow-md" : "bg-white"
//           }`}
//         >
//           <div className="max-w-7xl mx-auto flex items-center justify-between py-4 px-4">
//             {/* LOGO */}
//             <Link to="/" className="text-xl font-bold text-blue-800">
//               MyLogo
//             </Link>

//             {/* MOBILE BTN */}
//             <div className="md:hidden">
//               <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
//                 {mobileMenuOpen ? <X /> : <Menu />}
//               </button>
//             </div>

//             {/* DESKTOP NAV */}
//             <nav className="hidden md:flex gap-6 items-center text-gray-800">
//               {navLinks.map((link) =>
//                 link.path ? (
//                   <Link
//                     key={link.name}
//                     to={link.path}
//                     onClick={() => setDropdownOpen(false)}
//                     className="hover:text-blue-600"
//                   >
//                     {link.name}
//                   </Link>
//                 ) : link.dropdown ? (
//                   <div key={link.name} className="relative" ref={dropdownRef}>
//                     <button
//                       onClick={() => setDropdownOpen(!dropdownOpen)}
//                       className="hover:text-blue-600 flex items-center gap-1"
//                     >
//                       {link.name}
//                       <ChevronDown
//                         className={`w-4 h-4 transition-transform duration-300 ${
//                           dropdownOpen ? "rotate-180" : ""
//                         }`}
//                       />
//                     </button>

//                     {dropdownOpen && (
//                       <div className="absolute top-full mt-3 w-52 bg-white shadow-lg rounded-lg border border-gray-300 p-2 z-50">
//                         {link.dropdown.map((item) => (
//                           <button
//                             key={item.name}
//                             onClick={() => {
//                               handleScroll(item.id);
//                               setDropdownOpen(false);
//                             }}
//                             className="block w-full text-left px-3 py-2 text-sm rounded hover:bg-[#f16126] hover:text-white transition"
//                           >
//                             {item.name}
//                           </button>
//                         ))}
//                       </div>
//                     )}
//                   </div>
//                 ) : (
//                   <button
//                     key={link.name}
//                     onClick={() => {
//                       handleScroll(link.id);
//                       setDropdownOpen(false);
//                     }}
//                     className="hover:text-blue-600"
//                   >
//                     {link.name}
//                   </button>
//                 ),
//               )}
//             </nav>

//             {/* AUTH */}
//             <div className="hidden md:flex gap-2">
//               <Link
//                 to="/login"
//                 className="flex items-center gap-2 text-sm px-4 py-2 border border-[#f16126] text-[#f16126]"
//               >
//                 <UserPlus className="w-4 h-4" />
//                 Login
//               </Link>

//               <Link
//                 to="/signup"
//                 className="flex items-center gap-2 text-sm px-4 py-2 bg-[#f16126] text-white"
//               >
//                 <Users className="w-4 h-4" />
//                 Sign Up
//               </Link>
//             </div>
//           </div>

//           {/* 📱 MOBILE MENU */}
//           {mobileMenuOpen && (
//             <div className="md:hidden bg-white border-t px-4 py-2 space-y-2">
//               {navLinks.map((link) =>
//                 link.path ? (
//                   <Link
//                     key={link.name}
//                     to={link.path}
//                     onClick={() => setMobileMenuOpen(false)}
//                     className="block px-3 py-2"
//                   >
//                     {link.name}
//                   </Link>
//                 ) : link.dropdown ? (
//                   <div key={link.name}>
//                     <p className="px-3 py-2 font-semibold text-gray-600">
//                       {link.name}
//                     </p>
//                     {link.dropdown.map((item) => (
//                       <button
//                         key={item.name}
//                         onClick={() => {
//                           handleScroll(item.id);
//                           setMobileMenuOpen(false);
//                         }}
//                         className="block w-full text-left px-5 py-2 text-sm hover:bg-[#f16126] hover:text-white rounded"
//                       >
//                         {item.name}
//                       </button>
//                     ))}
//                   </div>
//                 ) : (
//                   <button
//                     key={link.name}
//                     onClick={() => {
//                       handleScroll(link.id);
//                       setMobileMenuOpen(false);
//                     }}
//                     className="block w-full text-left px-3 py-2"
//                   >
//                     {link.name}
//                   </button>
//                 ),
//               )}
//             </div>
//           )}
//         </header>
//       </div>

//       {/* HEADER SPACE */}
//       <div className="h-28 md:h-32"></div>
//     </>
//   );
// }



// import { useEffect, useState, useRef } from "react";
// import { Link, useLocation } from "react-router-dom";
// import { FaFacebookF, FaInstagram, FaTwitter, FaLinkedinIn } from "react-icons/fa";
// import { Phone, Mail, Users, UserPlus, Menu, X, ChevronDown } from "lucide-react";

// export default function Header() {
//   const [scrolled, setScrolled] = useState(false);
//   const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
//   const [dropdownOpen, setDropdownOpen] = useState(false);
//   const [activeLink, setActiveLink] = useState("Home");

//   const dropdownRef = useRef();
//   const location = useLocation();

//   const navLinks = [
//     { name: "Home", path: "/" },
//     { name: "About", id: "about" },
//     {
//       name: "Explore",
//       dropdown: [
//         { name: "Our Mentors", id: "teachers" },
//         { name: "Student Success", id: "students" },
//         { name: "Platform Insights", id: "stats" },
//       ],
//     },
//     { name: "Blog", id: "blog" },
//     { name: "Courses", id: "courses" },
//     { name: "Contact", id: "contact" },
//   ];

//   useEffect(() => {
//     const handleScrollEffect = () => setScrolled(window.scrollY > 20);
//     window.addEventListener("scroll", handleScrollEffect);
//     return () => window.removeEventListener("scroll", handleScrollEffect);
//   }, []);

//   useEffect(() => {
//     const handleClickOutside = (e) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
//         setDropdownOpen(false);
//       }
//     };
//     document.addEventListener("mousedown", handleClickOutside);
//     return () => document.removeEventListener("mousedown", handleClickOutside);
//   }, []);

//   const handleScroll = (id) => {
//     if (location.pathname !== "/") {
//       window.location.href = "/#" + id;
//       return;
//     }
//     const section = document.getElementById(id);
//     if (section) {
//       const y = section.getBoundingClientRect().top + window.pageYOffset - 80;
//       window.scrollTo({ top: y, behavior: "smooth" });
//     }
//   };

//   useEffect(() => {
//     if (location.hash) {
//       const id = location.hash.replace("#", "");
//       setTimeout(() => handleScroll(id), 100);
//     }
//   }, [location]);

//   return (
//     <>
//       <style>{`
//         @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap');

//         .hdr * { font-family: 'Outfit', sans-serif; }

//         .top-bar-link {
//           display: flex; align-items: center; gap: 6px;
//           color: #cbd5e1; font-size: 13px; text-decoration: none;
//           transition: color 0.2s;
//         }
//         .top-bar-link:hover { color: #f97316; }

//         .social-icon {
//           width: 28px; height: 28px; border-radius: 50%;
//           display: flex; align-items: center; justify-content: center;
//           border: 1px solid rgba(255,255,255,0.15); color: #94a3b8;
//           transition: all 0.25s; cursor: pointer;
//         }
//         .social-icon:hover {
//           background: #f97316; border-color: #f97316;
//           color: white; transform: translateY(-2px);
//         }

//         .nav-btn {
//           position: relative; font-size: 14.5px; font-weight: 500;
//           color: #334155; background: none; border: none; cursor: pointer;
//           padding: 6px 2px; transition: color 0.2s;
//           display: flex; align-items: center; gap: 4px;
//           font-family: 'Outfit', sans-serif;
//         }
//         .nav-btn::after {
//           content: ''; position: absolute; bottom: 0; left: 0;
//           width: 0%; height: 2px; background: #f97316;
//           border-radius: 99px; transition: width 0.3s ease;
//         }
//         .nav-btn:hover { color: #f97316; }
//         .nav-btn:hover::after { width: 100%; }
//         .nav-btn.active { color: #f97316; }
//         .nav-btn.active::after { width: 100%; }

//         .dropdown-menu {
//           position: absolute; top: calc(100% + 12px); left: 50%;
//           transform: translateX(-50%); width: 200px;
//           background: white; border-radius: 12px;
//           border: 1px solid #f1f5f9;
//           box-shadow: 0 10px 40px rgba(0,0,0,0.10);
//           padding: 6px; z-index: 100;
//           animation: dropIn 0.2s ease;
//         }
//         @keyframes dropIn {
//           from { opacity: 0; transform: translateX(-50%) translateY(-6px); }
//           to   { opacity: 1; transform: translateX(-50%) translateY(0); }
//         }
//         .dropdown-item {
//           display: block; width: 100%; text-align: left;
//           padding: 9px 14px; font-size: 13.5px; font-weight: 500;
//           color: #475569; background: none; border: none;
//           border-radius: 8px; cursor: pointer; transition: all 0.18s;
//           font-family: 'Outfit', sans-serif;
//         }
//         .dropdown-item:hover { background: #fff4ee; color: #f97316; padding-left: 18px; }

//         .btn-login {
//           display: flex; align-items: center; gap: 7px;
//           font-size: 13.5px; font-weight: 600;
//           padding: 9px 20px; border-radius: 8px;
//           border: 1.5px solid #f97316; color: #f97316;
//           background: transparent; cursor: pointer;
//           transition: all 0.25s; text-decoration: none;
//           font-family: 'Outfit', sans-serif;
//         }
//         .btn-login:hover { background: #fff4ee; }

//         .btn-signup {
//           display: flex; align-items: center; gap: 7px;
//           font-size: 13.5px; font-weight: 600;
//           padding: 9px 20px; border-radius: 8px;
//           border: 1.5px solid #f97316; color: white;
//           background: #f97316; cursor: pointer;
//           transition: all 0.25s; text-decoration: none;
//           font-family: 'Outfit', sans-serif;
//         }
//         .btn-signup:hover { background: #ea580c; border-color: #ea580c; transform: translateY(-1px); box-shadow: 0 4px 14px rgba(249,115,22,0.35); }

//         .mob-item {
//           display: block; width: 100%; text-align: left;
//           padding: 11px 16px; font-size: 14px; font-weight: 500;
//           color: #334155; background: none; border: none;
//           border-radius: 8px; cursor: pointer;
//           transition: all 0.18s; text-decoration: none;
//           font-family: 'Outfit', sans-serif;
//         }
//         .mob-item:hover { background: #fff4ee; color: #f97316; }
//         .mob-sub {
//           display: block; width: 100%; text-align: left;
//           padding: 9px 16px 9px 28px; font-size: 13px; color: #64748b;
//           background: none; border: none; border-radius: 8px; cursor: pointer;
//           transition: all 0.18s; font-family: 'Outfit', sans-serif;
//         }
//         .mob-sub:hover { background: #fff4ee; color: #f97316; }

//         .logo-mark {
//           font-size: 22px; font-weight: 700; letter-spacing: -0.5px;
//           background: linear-gradient(135deg, #1e3a8a, #2563eb);
//           -webkit-background-clip: text; -webkit-text-fill-color: transparent;
//           background-clip: text;
//         }
//         .logo-dot {
//           display: inline-block; width: 6px; height: 6px;
//           background: #f97316; border-radius: 50%;
//           margin-left: 2px; vertical-align: super;
//         }

//         @media (max-width: 768px) {
//           .desktop-nav, .desktop-auth { display: none !important; }
//           .mob-toggle { display: flex !important; }
//         }
//       `}</style>

//       <div className="hdr" style={{ position: "fixed", top: 0, left: 0, width: "100%", zIndex: 50 }}>

//         {/* ── TOP BAR ── */}
//         <div style={{
//           background: "linear-gradient(90deg, #0f172a, #1e293b)",
//           overflow: "hidden",
//           transition: "max-height 0.5s ease, opacity 0.4s ease",
//           maxHeight: scrolled ? "0" : "60px",
//           opacity: scrolled ? 0 : 1,
//         }}>
//           <div style={{
//             maxWidth: 1280, margin: "0 auto",
//             padding: "10px 24px",
//             display: "flex", justifyContent: "space-between", alignItems: "center",
//           }}>
//             <div style={{ display: "flex", gap: 20 }}>
//               <a href="tel:+911234567890" className="top-bar-link">
//                 <Phone size={13} />&nbsp;+91-1234567890
//               </a>
//               <a href="mailto:support@example.com" className="top-bar-link">
//                 <Mail size={13} />&nbsp;support@example.com
//               </a>
//             </div>
//             <div style={{ display: "flex", gap: 8 }}>
//               {[FaFacebookF, FaInstagram, FaTwitter, FaLinkedinIn].map((Icon, i) => (
//                 <div key={i} className="social-icon"><Icon size={11} /></div>
//               ))}
//             </div>
//           </div>
//         </div>

//         {/* ── MAIN HEADER ── */}
//         <header style={{
//           background: scrolled ? "rgba(255,255,255,0.9)" : "white",
//           backdropFilter: scrolled ? "blur(14px)" : "none",
//           borderBottom: "1px solid #f1f5f9",
//           boxShadow: scrolled ? "0 4px 24px rgba(0,0,0,0.07)" : "none",
//           transition: "all 0.3s ease",
//         }}>
//           <div style={{
//             maxWidth: 1280, margin: "0 auto",
//             padding: "13px 24px",
//             display: "flex", alignItems: "center", justifyContent: "space-between", gap: 20,
//           }}>

//             {/* LOGO */}
//             <Link to="/" style={{ textDecoration: "none", flexShrink: 0 }}>
//               {/* <span className="logo-mark">MyLogo<span className="logo-dot" /></span> */}
//               <span className="logo-mark">
//   <img src="/edu.png" alt="edu logo" />
//   <span className="logo-dot" />
// </span>
//             </Link>

//             {/* MOBILE TOGGLE */}
//             <button
//               className="mob-toggle"
//               onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
//               style={{
//                 display: "none", background: "none",
//                 border: "1.5px solid #e2e8f0", borderRadius: 8,
//                 padding: "6px 8px", cursor: "pointer", color: "#334155",
//                 alignItems: "center",
//               }}
//             >
//               {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
//             </button>

//             {/* DESKTOP NAV */}
//             <nav className="desktop-nav" style={{ display: "flex", gap: 28, alignItems: "center", flex: 1, justifyContent: "center" }}>
//               {navLinks.map((link) =>
//                 link.path ? (
//                   <Link
//                     key={link.name}
//                     to={link.path}
//                     className={`nav-btn ${activeLink === link.name ? "active" : ""}`}
//                     style={{ textDecoration: "none" }}
//                     onClick={() => { setActiveLink(link.name); setDropdownOpen(false); }}
//                   >
//                     {link.name}
//                   </Link>
//                 ) : link.dropdown ? (
//                   <div key={link.name} style={{ position: "relative" }} ref={dropdownRef}>
//                     <button
//                       className={`nav-btn ${activeLink === link.name ? "active" : ""}`}
//                       onClick={() => { setDropdownOpen(!dropdownOpen); setActiveLink(link.name); }}
//                     >
//                       {link.name}
//                       <ChevronDown size={14} style={{ transition: "transform 0.3s", transform: dropdownOpen ? "rotate(180deg)" : "rotate(0)" }} />
//                     </button>
//                     {dropdownOpen && (
//                       <div className="dropdown-menu">
//                         {link.dropdown.map((item) => (
//                           <button key={item.name} className="dropdown-item"
//                             onClick={() => { handleScroll(item.id); setDropdownOpen(false); }}>
//                             {item.name}
//                           </button>
//                         ))}
//                       </div>
//                     )}
//                   </div>
//                 ) : (
//                   <button key={link.name}
//                     className={`nav-btn ${activeLink === link.name ? "active" : ""}`}
//                     onClick={() => { handleScroll(link.id); setActiveLink(link.name); setDropdownOpen(false); }}>
//                     {link.name}
//                   </button>
//                 )
//               )}
//             </nav>

//             {/* AUTH BUTTONS */}
//             <div className="desktop-auth" style={{ display: "flex", gap: 10, alignItems: "center", flexShrink: 0 }}>
//               <Link to="/login" className="btn-login">
//                 <UserPlus size={15} /> Login
//               </Link>
//               <Link to="/signup" className="btn-signup">
//                 <Users size={15} /> Sign Up
//               </Link>
//             </div>
//           </div>

//           {/* ── MOBILE MENU ── */}
//           {mobileMenuOpen && (
//             <div style={{ borderTop: "1px solid #f1f5f9", padding: "10px 14px 14px", background: "white" }}>
//               {navLinks.map((link) =>
//                 link.path ? (
//                   <Link key={link.name} to={link.path} className="mob-item"
//                     onClick={() => setMobileMenuOpen(false)}>
//                     {link.name}
//                   </Link>
//                 ) : link.dropdown ? (
//                   <div key={link.name}>
//                     <p style={{ padding: "10px 16px 4px", fontSize: 11, fontWeight: 600, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.07em", margin: 0 }}>
//                       {link.name}
//                     </p>
//                     {link.dropdown.map((item) => (
//                       <button key={item.name} className="mob-sub"
//                         onClick={() => { handleScroll(item.id); setMobileMenuOpen(false); }}>
//                         {item.name}
//                       </button>
//                     ))}
//                   </div>
//                 ) : (
//                   <button key={link.name} className="mob-item"
//                     onClick={() => { handleScroll(link.id); setMobileMenuOpen(false); }}>
//                     {link.name}
//                   </button>
//                 )
//               )}
//               <div style={{ display: "flex", gap: 10, padding: "12px 16px 4px" }}>
//                 <Link to="/login" className="btn-login" style={{ flex: 1, justifyContent: "center" }}>
//                   <UserPlus size={14} /> Login
//                 </Link>
//                 <Link to="/signup" className="btn-signup" style={{ flex: 1, justifyContent: "center" }}>
//                   <Users size={14} /> Sign Up
//                 </Link>
//               </div>
//             </div>
//           )}
//         </header>
//       </div>

//       {/* SPACER */}
//       <div style={{ height: scrolled ? 68 : 112, transition: "height 0.3s" }} />
//     </>
//   );
// }


import { useEffect, useState, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import { FaFacebookF, FaInstagram, FaTwitter, FaLinkedinIn } from "react-icons/fa";
import { Phone, Mail, Users, UserPlus, Menu, X, ChevronDown } from "lucide-react";

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [activeLink, setActiveLink] = useState("Home");

  const dropdownRef = useRef();
  const location = useLocation();

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "About", id: "about" },
    {
      name: "Explore",
      dropdown: [
        { name: "Our Mentors", id: "teachers" },
        { name: "Student Success", id: "students" },
        { name: "Platform Insights", id: "stats" },
      ],
    },
    { name: "Blog", id: "blog" },
    { name: "Courses", id: "courses" },
    { name: "Contact", id: "contact" },
  ];

  useEffect(() => {
    const handleScrollEffect = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScrollEffect);
    return () => window.removeEventListener("scroll", handleScrollEffect);
  }, []);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleScroll = (id) => {
    if (location.pathname !== "/") {
      window.location.href = "/#" + id;
      return;
    }
    const section = document.getElementById(id);
    if (section) {
      const y = section.getBoundingClientRect().top + window.pageYOffset - 80;
      window.scrollTo({ top: y, behavior: "smooth" });
    }
  };

  useEffect(() => {
    if (location.hash) {
      const id = location.hash.replace("#", "");
      setTimeout(() => handleScroll(id), 100);
    }
  }, [location]);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap');

        .hdr * { font-family: 'Outfit', sans-serif; }

        .top-bar-link {
          display: flex; align-items: center; gap: 6px;
          color: #cbd5e1; font-size: 13px; text-decoration: none;
          transition: color 0.2s;
        }
        .top-bar-link:hover { color: #f97316; }

        .social-icon {
          width: 28px; height: 28px; border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          border: 1px solid rgba(255,255,255,0.15); color: #94a3b8;
          transition: all 0.25s; cursor: pointer;
        }
        .social-icon:hover {
          background: #f97316; border-color: #f97316;
          color: white; transform: translateY(-2px);
        }

        .nav-btn {
          position: relative; font-size: 14.5px; font-weight: 500;
          color: #334155; background: none; border: none; cursor: pointer;
          padding: 6px 2px; transition: color 0.2s;
          display: flex; align-items: center; gap: 4px;
          font-family: 'Outfit', sans-serif;
        }
        .nav-btn::after {
          content: ''; position: absolute; bottom: 0; left: 0;
          width: 0%; height: 2px; background: #f97316;
          border-radius: 99px; transition: width 0.3s ease;
        }
        .nav-btn:hover { color: #f97316; }
        .nav-btn:hover::after { width: 100%; }
        .nav-btn.active { color: #f97316; }
        .nav-btn.active::after { width: 100%; }

        .dropdown-menu {
          position: absolute; top: calc(100% + 12px); left: 50%;
          transform: translateX(-50%); width: 200px;
          background: white; border-radius: 12px;
          border: 1px solid #f1f5f9;
          box-shadow: 0 10px 40px rgba(0,0,0,0.10);
          padding: 6px; z-index: 100;
          animation: dropIn 0.2s ease;
        }
        @keyframes dropIn {
          from { opacity: 0; transform: translateX(-50%) translateY(-6px); }
          to   { opacity: 1; transform: translateX(-50%) translateY(0); }
        }
        .dropdown-item {
          display: block; width: 100%; text-align: left;
          padding: 9px 14px; font-size: 13.5px; font-weight: 500;
          color: #475569; background: none; border: none;
          border-radius: 8px; cursor: pointer; transition: all 0.18s;
          font-family: 'Outfit', sans-serif;
        }
        .dropdown-item:hover { background: #fff4ee; color: #f97316; padding-left: 18px; }

        .btn-login {
          display: flex; align-items: center; gap: 7px;
          font-size: 13.5px; font-weight: 600;
          padding: 9px 20px; border-radius: 8px;
          border: 1.5px solid #f97316; color: #f97316;
          background: transparent; cursor: pointer;
          transition: all 0.25s; text-decoration: none;
          font-family: 'Outfit', sans-serif;
        }
        .btn-login:hover { background: #fff4ee; }

        .btn-signup {
          display: flex; align-items: center; gap: 7px;
          font-size: 13.5px; font-weight: 600;
          padding: 9px 20px; border-radius: 8px;
          border: 1.5px solid #f97316; color: white;
          background: #f97316; cursor: pointer;
          transition: all 0.25s; text-decoration: none;
          font-family: 'Outfit', sans-serif;
        }
        .btn-signup:hover { background: #ea580c; border-color: #ea580c; transform: translateY(-1px); box-shadow: 0 4px 14px rgba(249,115,22,0.35); }

        .mob-item {
          display: block; width: 100%; text-align: left;
          padding: 11px 16px; font-size: 14px; font-weight: 500;
          color: #334155; background: none; border: none;
          border-radius: 8px; cursor: pointer;
          transition: all 0.18s; text-decoration: none;
          font-family: 'Outfit', sans-serif;
        }
        .mob-item:hover { background: #fff4ee; color: #f97316; }
        .mob-sub {
          display: block; width: 100%; text-align: left;
          padding: 9px 16px 9px 28px; font-size: 13px; color: #64748b;
          background: none; border: none; border-radius: 8px; cursor: pointer;
          transition: all 0.18s; font-family: 'Outfit', sans-serif;
        }
        .mob-sub:hover { background: #fff4ee; color: #f97316; }

        /* ✅ FIXED LOGO STYLES */
        .logo-mark {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          text-decoration: none;
        }
        .logo-img {
          width: 38px;
          height: 38px;
          object-fit: contain;
          border-radius: 8px;
          display: block;
          flex-shrink: 0;
        }
        .logo-text {
          font-size: 22px;
          font-weight: 700;
          letter-spacing: -0.5px;
          background: linear-gradient(135deg, #1e3a8a, #2563eb);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        .logo-dot {
          display: inline-block;
          width: 7px;
          height: 7px;
          background: #f97316;
          border-radius: 50%;
          margin-left: 2px;
          vertical-align: super;
          /* ✅ -webkit-text-fill-color override for dot */
          -webkit-text-fill-color: initial;
        }

        @media (max-width: 768px) {
          .desktop-nav, .desktop-auth { display: none !important; }
          .mob-toggle { display: flex !important; }
        }
      `}</style>

      <div className="hdr" style={{ position: "fixed", top: 0, left: 0, width: "100%", zIndex: 50 }}>

        {/* ── TOP BAR ── */}
        <div style={{
          background: "linear-gradient(90deg, #0f172a, #1e293b)",
          overflow: "hidden",
          transition: "max-height 0.5s ease, opacity 0.4s ease",
          maxHeight: scrolled ? "0" : "60px",
          opacity: scrolled ? 0 : 1,
        }}>
          <div style={{
            maxWidth: 1280, margin: "0 auto",
            padding: "10px 24px",
            display: "flex", justifyContent: "space-between", alignItems: "center",
          }}>
            <div style={{ display: "flex", gap: 20 }}>
              <a href="tel:+911234567890" className="top-bar-link">
                <Phone size={13} />&nbsp;+91-1234567890
              </a>
              <a href="mailto:support@example.com" className="top-bar-link">
                <Mail size={13} />&nbsp;support@example.com
              </a>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              {[FaFacebookF, FaInstagram, FaTwitter, FaLinkedinIn].map((Icon, i) => (
                <div key={i} className="social-icon"><Icon size={11} /></div>
              ))}
            </div>
          </div>
        </div>

        {/* ── MAIN HEADER ── */}
        <header style={{
          background: scrolled ? "rgba(255,255,255,0.9)" : "white",
          backdropFilter: scrolled ? "blur(14px)" : "none",
          borderBottom: "1px solid #f1f5f9",
          boxShadow: scrolled ? "0 4px 24px rgba(0,0,0,0.07)" : "none",
          transition: "all 0.3s ease",
        }}>
          <div style={{
            maxWidth: 1280, margin: "0 auto",
            padding: "13px 24px",
            display: "flex", alignItems: "center", justifyContent: "space-between", gap: 20,
          }}>

            {/* ✅ FIXED LOGO */}
            {/* <Link to="/" className="logo-mark">
              <img
                src="/edu.png"
                alt="Edu Logo"
                className="logo-img"
                onError={(e) => { e.target.style.display = "none"; }}
              />
              <span className="logo-text">
                EduLearn<span className="logo-dot" />
              </span>
            </Link> */}
            {/* ✅ SIRF IMAGE LOGO */}
<Link to="/" style={{ textDecoration: "none", flexShrink: 0, display: "flex", alignItems: "center" }}>
  <img
    src="/edu.png"
    alt="Edu Logo"
    style={{
      height: "50px",
      width: "auto",
      display: "block",
      objectFit: "contain",
    }}
    onError={(e) => { e.target.style.display = "none"; }}
  />
</Link>

            {/* MOBILE TOGGLE */}
            <button
              className="mob-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              style={{
                display: "none", background: "none",
                border: "1.5px solid #e2e8f0", borderRadius: 8,
                padding: "6px 8px", cursor: "pointer", color: "#334155",
                alignItems: "center",
              }}
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>

            {/* DESKTOP NAV */}
            <nav className="desktop-nav" style={{ display: "flex", gap: 28, alignItems: "center", flex: 1, justifyContent: "center" }}>
              {navLinks.map((link) =>
                link.path ? (
                  <Link
                    key={link.name}
                    to={link.path}
                    className={`nav-btn ${activeLink === link.name ? "active" : ""}`}
                    style={{ textDecoration: "none" }}
                    onClick={() => { setActiveLink(link.name); setDropdownOpen(false); }}
                  >
                    {link.name}
                  </Link>
                ) : link.dropdown ? (
                  <div key={link.name} style={{ position: "relative" }} ref={dropdownRef}>
                    <button
                      className={`nav-btn ${activeLink === link.name ? "active" : ""}`}
                      onClick={() => { setDropdownOpen(!dropdownOpen); setActiveLink(link.name); }}
                    >
                      {link.name}
                      <ChevronDown size={14} style={{ transition: "transform 0.3s", transform: dropdownOpen ? "rotate(180deg)" : "rotate(0)" }} />
                    </button>
                    {dropdownOpen && (
                      <div className="dropdown-menu">
                        {link.dropdown.map((item) => (
                          <button key={item.name} className="dropdown-item"
                            onClick={() => { handleScroll(item.id); setDropdownOpen(false); }}>
                            {item.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <button key={link.name}
                    className={`nav-btn ${activeLink === link.name ? "active" : ""}`}
                    onClick={() => { handleScroll(link.id); setActiveLink(link.name); setDropdownOpen(false); }}>
                    {link.name}
                  </button>
                )
              )}
            </nav>

            {/* AUTH BUTTONS */}
            <div className="desktop-auth" style={{ display: "flex", gap: 10, alignItems: "center", flexShrink: 0 }}>
              <Link to="/login" className="btn-login">
                <UserPlus size={15} /> Login
              </Link>
              <Link to="/signup" className="btn-signup">
                <Users size={15} /> Sign Up
              </Link>
            </div>
          </div>

          {/* ── MOBILE MENU ── */}
          {mobileMenuOpen && (
            <div style={{ borderTop: "1px solid #f1f5f9", padding: "10px 14px 14px", background: "white" }}>
              {navLinks.map((link) =>
                link.path ? (
                  <Link key={link.name} to={link.path} className="mob-item"
                    onClick={() => setMobileMenuOpen(false)}>
                    {link.name}
                  </Link>
                ) : link.dropdown ? (
                  <div key={link.name}>
                    <p style={{ padding: "10px 16px 4px", fontSize: 11, fontWeight: 600, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.07em", margin: 0 }}>
                      {link.name}
                    </p>
                    {link.dropdown.map((item) => (
                      <button key={item.name} className="mob-sub"
                        onClick={() => { handleScroll(item.id); setMobileMenuOpen(false); }}>
                        {item.name}
                      </button>
                    ))}
                  </div>
                ) : (
                  <button key={link.name} className="mob-item"
                    onClick={() => { handleScroll(link.id); setMobileMenuOpen(false); }}>
                    {link.name}
                  </button>
                )
              )}
              <div style={{ display: "flex", gap: 10, padding: "12px 16px 4px" }}>
                <Link to="/login" className="btn-login" style={{ flex: 1, justifyContent: "center" }}>
                  <UserPlus size={14} /> Login
                </Link>
                <Link to="/signup" className="btn-signup" style={{ flex: 1, justifyContent: "center" }}>
                  <Users size={14} /> Sign Up
                </Link>
              </div>
            </div>
          )}
        </header>
      </div>

      {/* SPACER */}
      <div style={{ height: scrolled ? 68 : 112, transition: "height 0.3s" }} />
    </>
  );
}