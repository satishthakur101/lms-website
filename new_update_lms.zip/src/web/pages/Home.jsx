import React from "react";
import Header from "../layout/Header";
import Footer from "../layout/Footer";
import HeroSection from "../components/HeroSection";
import Features from "../components/Features";
import { AdmissionForm } from "../components/AdmissionForm";
import { BlogSection } from "../components/BlogSection";
import { Achivers } from "../components/Achivers";
import Categories from "../components/Categories";
import About from "../components/About";
import { CourseSection } from "../components/CourseSection";
import HappyStudents  from "../components/HappyStudents";
import InstructorsSection from "../components/InstructorsSection";
import CampusLife from "../components/CampusLife";
import PaymentSection from "../components/PaymentSection";
import Comprehensive from "../components/Comprehensive";


const Home = () => {
  return (
    <>
      <Header />
      <HeroSection />
      <Categories />
      <About />
      <Comprehensive/>
      <Features />
      <CourseSection />
      <CampusLife/>
      <BlogSection />
      <Achivers />
      <HappyStudents />
      <InstructorsSection/>
      <AdmissionForm />
      <PaymentSection/> 
  <Footer /> 
    </>
  );
};
export default Home;
