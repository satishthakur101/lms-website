import { useState } from "react";
import  Header  from '../layout/Header'
import  Footer  from '../layout/Footer'
import { Link } from "react-router-dom";
import { Home } from "lucide-react";
import { FileText, BookOpen, ShieldCheck, Briefcase, Scale, Clock, MessageSquare, AlertCircle, CheckCircle, ChevronDown } from 'lucide-react';
const pages = [{ name: "Home", href: "/", current: false }];
 const Terms = ({ pageTitle = "Terms & Conditions" }) => {
    const [activeSection, setActiveSection] = useState('introduction');
    const [openAccordion, setOpenAccordion] = useState('');
  
    const toggleAccordion = (id) => {
      setOpenAccordion(openAccordion === id ? '' : id);
    };
  
    const sections = [
      { 
        id: 'introduction', 
        title: 'Introduction',
        icon: <BookOpen className="w-5 h-5" />,
        content: 'Welcome to our platform. These Terms and Conditions govern your use of our website, services, and products. By accessing or using our services, you agree to be bound by these Terms and all applicable laws and regulations.'
      },
      { 
        id: 'userAgreement', 
        title: 'User Agreement',
        icon: <FileText className="w-5 h-5" />,
        content: 'By using our services, you acknowledge that you have read, understood, and agree to be bound by these Terms. If you do not agree with any part of these Terms, you must not use our services. We reserve the right to modify these Terms at any time, and your continued use constitutes acceptance of those changes.'
      },
      { 
        id: 'userResponsibilities', 
        title: 'User Responsibilities',
        icon: <ShieldCheck className="w-5 h-5" />,
        content: 'You are responsible for maintaining the confidentiality of your account information and for all activities that occur under your account. You agree to notify us immediately of any unauthorized use of your account. You must not use our service for any illegal or unauthorized purpose.'
      },
      { 
        id: 'intellectualProperty', 
        title: 'Intellectual Property',
        icon: <Briefcase className="w-5 h-5" />,
        content: 'All content, features, and functionality of our services, including but not limited to text, graphics, logos, icons, images, audio clips, and software, are the exclusive property of our company and are protected by copyright, trademark, and other intellectual property laws.'
      },
      { 
        id: 'disputeResolution', 
        title: 'Dispute Resolution',
        icon: <Scale className="w-5 h-5" />,
        content: 'Any disputes arising out of or relating to these Terms shall be resolved through arbitration in accordance with the rules of the arbitration association in your jurisdiction. The arbitration shall take place in [Location] and the language of arbitration shall be English.'
      },
      { 
        id: 'termination', 
        title: 'Termination',
        icon: <Clock className="w-5 h-5" />,
        content: 'We reserve the right to terminate or suspend your account and access to our services immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach these Terms. Upon termination, your right to use our services will immediately cease.'
      },
    ];
  
    const faqs = [
      {
        id: 'faq1',
        question: 'Can I cancel my subscription at any time?',
        answer: 'Yes, you can cancel your subscription at any time. Once canceled, you will still have access to the service until the end of your current billing period.'
      },
      {
        id: 'faq2',
        question: 'How do I update my account information?',
        answer: 'You can update your account information by logging into your account and navigating to the "Account Settings" section. There, you can modify your personal details, payment information, and notification preferences.'
      },
      {
        id: 'faq3',
        question: 'What happens if I violate the Terms and Conditions?',
        answer: 'Violations of our Terms and Conditions may result in warnings, temporary suspension, or permanent termination of your account, depending on the severity and frequency of the violations.'
      },
      {
        id: 'faq4',
        question: 'How do you handle my personal data?',
        answer: 'We handle your personal data in accordance with our Privacy Policy. We implement appropriate security measures to protect your data and only collect information necessary for providing our services.'
      }
    ];
  return (
    <>
      <Header />

      <div
        className="w-full h-[500px] bg-cover bg-center relative"
        style={{
          backgroundImage:
            "url('https://img.freepik.com/free-photo/business-people-blue-background_53876-101889.jpg?uid=R176823449&ga=GA1.1.1433286368.1718702777&semt=ais_hybrid&w=740')",
        }}
      >
        <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center px-4">
          <h1 className="text-white text-4xl md:text-6xl font-bold mb-6 drop-shadow-lg text-center">
            {pageTitle}
          </h1>

          {/* Tabs */}
          <div className=" px-4 py-2 ">
            <nav aria-label="Breadcrumb" className="flex">
              <ol
                role="list"
                className="flex space-x-4 rounded-md bg-black border border-white/50 px-6 shadow"
              >
                <li className="flex">
                  <div className="flex items-center">
                    <Link to="/" className="text-gray-300 hover:text-gray-400">
                      <Home
                        aria-hidden="true"
                        className="size-5 shrink-0"
                      />
                      <span className="sr-only">Home</span>
                    </Link>
                  </div>
                </li>
                {pages.map((page) => (
                  <li key={page.name} className="flex">
                    <div className="flex items-center">
                      <svg
                        fill="currentColor"
                        viewBox="0 0 24 44"
                        preserveAspectRatio="none"
                        aria-hidden="true"
                        className="h-full w-6 shrink-0 text-gray-100"
                      >
                        <path d="M.293 0l22 22-22 22h1.414l22-22-22-22H.293z" />
                      </svg>
                      <Link
                        to={page.href}
                        aria-current={page.current ? "page" : undefined}
                        className="ml-4 text-sm font-medium text-gray-300 hover:text-gray-400"
                      >
                        {page.name}
                      </Link>
                    </div>
                  </li>
                ))}
              </ol>
            </nav>
          </div>
        </div>
      </div>


    <div className="min-h-screen bg-gradient-to-tr from-indigo-50 to-purple-50 dark:from-gray-900 dark:to-indigo-950 text-gray-800 dark:text-gray-200">
      <div className=" max-w-7xl mx-auto px-4 py-12">

        <div className="flex flex-col lg:flex-row gap-4 ">
          {/* Left sidebar navigation */}
          <nav className="lg:w-1/4 w-full">
            <div className="sticky top-8 bg-white border border-gray-300 rounded-sm shadow-sm p-4">
              <h2 className="font-semibold text-lg mb-4 px-2">Contents</h2>
              <ul className="space-y-1">
                {sections.map(section => (
                  <li key={section.id}>
                    <button
                      onClick={() => setActiveSection(section.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                        activeSection === section.id 
                          ? 'bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 font-medium' 
                          : 'hover:bg-gray-100 dark:hover:bg-gray-700/50'
                      }`}
                    >
                      {section.icon}
                      <span>{section.title}</span>
                    </button>
                  </li>
                ))}
              </ul>
              
              <div className="mt-8 p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg border-l-4 border-amber-500">
                <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 mb-2">
                  <AlertCircle className="w-5 h-5" />
                  <h3 className="font-medium">Important Notice</h3>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  These terms were last updated on May 1, 2025. Please review them regularly for any changes.
                </p>
              </div>
            </div>
          </nav>

          {/* Main content */}
          <main className="lg:w-3/4 w-full">
            <div className="bg-white border border-gray-300 rounded-sm shadow-sm p-6 lg:p-8 mb-5">
              {sections.map(section => (
                <div 
                  key={section.id}
                  className={`transition-opacity duration-300 ${
                    activeSection === section.id ? 'block' : 'hidden'
                  }`}
                >
                  <div className="flex items-center gap-3 mb-6 pb-4 border-b border-gray-200 dark:border-gray-700">
                    <div className="p-2 rounded-lg bg-indigo-100 dark:bg-indigo-900/30">
                      {section.icon}
                    </div>
                    <h2 className="text-2xl font-bold">{section.title}</h2>
                  </div>
                  
                  <div className="prose prose-lg dark:prose-invert max-w-none">
                    <p className="mb-6 text-lg">{section.content}</p>
                    
                    {/* Detailed content */}
                    <h3 className="font-semibold text-xl mt-8 mb-4">Key Information</h3>
                    <p className="mb-6">
                      Our terms are designed to create a clear understanding between you and our company. 
                      By using our services, you acknowledge that you have read, understood, and agree to these terms.
                    </p>
                    
                    <div className="bg-gray-50 dark:bg-gray-700/30 rounded-xl p-6 my-6">
                      <h4 className="font-medium text-lg mb-3">Important Highlights:</h4>
                      <ul className="space-y-3">
                        <li className="flex items-start gap-2">
                          <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                          <span>You must be at least 18 years old or have parental consent to use our services</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                          <span>You are responsible for maintaining the security of your account credentials</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                          <span>Unauthorized use of our intellectual property is strictly prohibited</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                          <span>We reserve the right to modify these terms at any time with reasonable notice</span>
                        </li>
                      </ul>
                    </div>
                    
                    <h3 className="font-semibold text-xl mt-8 mb-4">Legal Framework</h3>
                    <p className="mb-6">
                      These Terms constitute the entire agreement between you and our company regarding the use of our services.
                      If any provision of these Terms is held to be invalid or unenforceable, such provision shall be struck and the
                      remaining provisions shall be enforced.
                    </p>

                    <div className="mt-10 flex justify-between items-center pt-6 border-t border-gray-200 dark:border-gray-700">
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Effective Date: May 1, 2025
                      </p>
                      
                      <div className="flex gap-3">
                        <button className="text-indigo-600 dark:text-indigo-400 hover:underline text-sm flex items-center gap-1">
                          Print Terms
                        </button>
                        <button className="text-indigo-600 dark:text-indigo-400 hover:underline text-sm flex items-center gap-1">
                          Download PDF
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* FAQ Section */}
            <div className="bg-white border border-gray-300 rounded-sm shadow-sm p-6 lg:p-8">
              <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
              
              <div className="space-y-4">
                {faqs.map(faq => (
                  <div key={faq.id} className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
                    <button 
                      onClick={() => toggleAccordion(faq.id)}
                      className="w-full flex items-center justify-between p-4 text-left hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
                    >
                      <span className="font-medium">{faq.question}</span>
                      <ChevronDown className={`w-5 h-5 transition-transform ${openAccordion === faq.id ? 'transform rotate-180' : ''}`} />
                    </button>
                    {openAccordion === faq.id && (
                      <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/30">
                        <p>{faq.answer}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  
      <Footer />
    </>
  );
};
export default Terms;