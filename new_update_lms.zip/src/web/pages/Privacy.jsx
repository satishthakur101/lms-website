import { useState } from "react";
import  Header  from '../layout/Header'
import  Footer  from '../layout/Footer'
import { Link } from "react-router-dom";
import { Home } from "lucide-react";
import {
  Shield,
  Eye,
  Lock,
  Bell,
  Server,
  UserCheck,
  HelpCircle,
} from "lucide-react";
const pages = [{ name: "Home", href: "/", current: false }];
 const Privacy = ({ pageTitle = "Privacy Policy" }) => {
  const [activeSection, setActiveSection] = useState("dataCollection");
  const sections = [
    {
      id: "dataCollection",
      title: "Data Collection",
      icon: <Eye className="w-5 h-5" />,
      content:
        "We collect personal information that you voluntarily provide to us when you register on our website, express interest in obtaining information about us or our products and services, or otherwise contact us. The personal information we collect may include names, email addresses, phone numbers, and other similar information.",
    },
    {
      id: "dataSecurity",
      title: "Data Security",
      icon: <Lock className="w-5 h-5" />,
      content:
        "We have implemented appropriate technical and organizational security measures designed to protect the security of any personal information we process. However, despite our safeguards and efforts to secure your information, no electronic transmission over the Internet or information storage technology can be guaranteed to be 100% secure.",
    },
    {
      id: "dataUsage",
      title: "How We Use Your Data",
      icon: <Server className="w-5 h-5" />,
      content:
        "We use personal information collected via our website for various business purposes described below. We process your personal information for these purposes in reliance on our legitimate business interests, in order to enter into or perform a contract with you, with your consent, and/or for compliance with our legal obligations.",
    },
    {
      id: "thirdParties",
      title: "Third-Party Sharing",
      icon: <UserCheck className="w-5 h-5" />,
      content:
        "We may share your data with our trusted third-party service providers, who help us operate our website, conduct our business, or service you, so long as those parties agree to keep this information confidential. We may also disclose your information where we are legally required to do so.",
    },
    {
      id: "cookies",
      title: "Cookies Policy",
      icon: <Bell className="w-5 h-5" />,
      content:
        "We use cookies and similar tracking technologies to track activity on our website and store certain information. Cookies are files with a small amount of data which may include an anonymous unique identifier. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.",
    },
    {
      id: "rightsChoices",
      title: "Your Rights & Choices",
      icon: <Shield className="w-5 h-5" />,
      content:
        "You have the right to access, update or delete the information we have on you. Whenever made possible, you can update your personal information directly within your account settings section. If you are unable to perform these actions yourself, please contact us for assistance.",
    },
  ];

  return (
    <>
      <Header />
      <div
        className="w-full h-[500px] bg-cover bg-center relative"
        style={{
          backgroundImage:
            "url('https://img.freepik.com/free-photo/business-people-blue-background_53876-101889.jpg?uid=R176823449&ga=GA1.1.1433286368.1718702777&semt=ais_hybrid&w=740')",
        }}
      >
        <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center px-4">
          <h1 className="text-white text-4xl md:text-6xl font-bold mb-6 drop-shadow-lg text-center">
            {pageTitle}
          </h1>

          {/* Tabs */}
          <div className=" px-4 py-2 ">
            <nav aria-label="Breadcrumb" className="flex">
              <ol
                role="list"
                className="flex space-x-4 rounded-md bg-black border border-white/50 px-6 shadow"
              >
                <li className="flex">
                  <div className="flex items-center">
                    <Link to="/" className="text-gray-300 hover:text-gray-400">
                      <Home
                        aria-hidden="true"
                        className="size-5 shrink-0"
                      />
                      <span className="sr-only">Home</span>
                    </Link>
                  </div>
                </li>
                {pages.map((page) => (
                  <li key={page.name} className="flex">
                    <div className="flex items-center">
                      <svg
                        fill="currentColor"
                        viewBox="0 0 24 44"
                        preserveAspectRatio="none"
                        aria-hidden="true"
                        className="h-full w-6 shrink-0 text-gray-100"
                      >
                        <path d="M.293 0l22 22-22 22h1.414l22-22-22-22H.293z" />
                      </svg>
                      <Link
                        to={page.href}
                        aria-current={page.current ? "page" : undefined}
                        className="ml-4 text-sm font-medium text-gray-300 hover:text-gray-400"
                      >
                        {page.name}
                      </Link>
                    </div>
                  </li>
                ))}
              </ol>
            </nav>
          </div>
        </div>
      </div>
      <div className="min-h-screen bg-gradient-to-br from-[#f3f4f6] to-gray-100 text-gray-800 ">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="flex flex-col lg:flex-row gap-4 ">
            <nav className="lg:w-1/4 w-full">
              <div className="sticky top-8 bg-white border border-gray-300  rounded-sm shadow-sm p-4">
                <h2 className="font-semibold text-lg mb-4 px-2 text-[#4b5563] ">
                  Contents
                </h2>
                <ul>
                  {sections.map((section) => (
                    <li key={section.id}>
                      <button
                        onClick={() => setActiveSection(section.id)}
                        className={`w-full flex items-center gap-3 px-3 py-2 rounded-sm text-left transition-colors ${
                          activeSection === section.id
                            ? "bg-[#e52f3cc4]  text-[#fff] font-medium"
                            : "hover:bg-[#e0f7f6] "
                        }`}
                      >
                        {section.icon}
                        <span>{section.title}</span>
                      </button>
                    </li>
                  ))}
                </ul>
                <div className="mt-8 p-4 bg-[#e0f7f6] rounded-lg">
                  <div className="flex items-center gap-2 text-[#21b4ab]  mb-2">
                    <HelpCircle className="w-5 h-5" />
                    <h3 className="font-medium">Need Help?</h3>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    If you have any questions about our privacy practices,
                    please contact our support team.
                  </p>
                  <button className="mt-3 w-full bg-[#21b4ab] hover:bg-[#1aa19b] text-white py-2 px-4 rounded-lg text-sm transition-colors">
                    Contact Support
                  </button>
                </div>
              </div>
            </nav>
            <main className="lg:w-3/4 bg-white  rounded-sm w-full border border-gray-300 shadow-sm p-6 lg:p-8">
              {sections.map((section) => (
                <div
                  key={section.id}
                  className={`mb-8 transition-opacity duration-300 ${
                    activeSection === section.id ? "opacity-100" : "hidden"
                  }`}
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-lg bg-[#a3d8f4] ">
                      {section.icon}
                    </div>
                    <h2 className="text-2xl font-bold text-[#409fd7] dark:text-[#a3d8f4]">
                      {section.title}
                    </h2>
                  </div>

                  <div className="prose prose-lg dark:prose-invert max-w-none">
                    <p className="mb-4">{section.content}</p>

                    <h3 className="font-semibold text-xl mt-6 mb-3 text-[#409fd7]">
                      What This Means For You
                    </h3>
                    <p className="mb-4">
                      We believe in transparent communication about how we
                      handle your data...
                    </p>

                    <h3 className="font-semibold text-xl mt-6 mb-3 text-[#409fd7]">
                      Our Commitment
                    </h3>
                    <p className="mb-4">
                      We are committed to protecting your privacy...
                    </p>

                    <div className="bg-[#f3f4f6] dark:bg-gray-700/30 rounded-xl p-6 mt-6">
                      <h4 className="font-medium text-lg mb-2 text-[#4b5563] dark:text-gray-300">
                        Key Points:
                      </h4>
                      <ul className="list-disc pl-5 space-y-2">
                        <li>We collect only what is necessary</li>
                        <li>Your data is encrypted and securely stored</li>
                        <li>You maintain control over your information</li>
                        <li>We are transparent about our practices</li>
                      </ul>
                    </div>

                    <div className="mt-8 flex justify-between items-center">
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Last updated: May 1, 2025
                      </p>
                      <button className="text-[#409fd7] dark:text-[#a3d8f4] hover:underline text-sm flex items-center gap-1">
                        Download PDF
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </main>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};
export default Privacy;
