// import React from 'react';
// import { Monitor, Save, BarChart3, Database, BookOpen, Settings } from 'lucide-react';

// const Categories = () => {
//   const categories = [
//     {
//       id: 1,
//       title: 'Computer Science',
//       courses: '24 Course',
//       img: "https://edukon.aminurislam.com/assets/images/category/icon/01.jpg",
//       bgColor: 'bg-green-100',
//       iconColor: 'text-[#75b71e]'
//     },
//     {
//       id: 2,
//       title: 'Civil Engineering',
//       courses: '04 Course',
//       img: "https://edukon.aminurislam.com/assets/images/category/icon/02.jpg",
//       bgColor: 'bg-blue-100',
//       iconColor: 'text-[#62abbb]'
//     },
//     {
//       id: 3,
//       title: 'Business Analysis',
//       courses: '27 Course',
//       img: "https://edukon.aminurislam.com/assets/images/category/icon/04.jpg",
//       bgColor: 'bg-yellow-100',
//       iconColor: 'text-[#9e5497]'
//     },
//     {
//       id: 4,
//       title: 'Data Science Analytics',
//       courses: '28 Course',
//       img: "https://edukon.aminurislam.com/assets/images/category/icon/05.jpg",
//       bgColor: 'bg-purple-100',
//       iconColor: 'text-[#b56959]'
//     },
//     {
//       id: 5,
//       title: 'Learning Management',
//       courses: '78 Course',
//       img: "https://edukon.aminurislam.com/assets/images/category/icon/06.jpg",
//       bgColor: 'bg-red-100',
//       iconColor: 'text-[#d1822c]'
//     },
//     {
//       id: 6,
//       title: 'Computer Engineering',
//       courses: '38 Course',
//       img: "https://edukon.aminurislam.com/assets/images/category/icon/03.jpg",
//       bgColor: 'bg-orange-100',
//       iconColor: 'text-[#bd9615]'
//     }
//   ];

//   return (
//     <div className="bg-gray-50 py-16 px-4">
//       <div className="max-w-7xl mx-auto">
//         {/* Header */}
//         <div className="text-center mb-8">
//           <span className="text-orange-500 bg-orange-50 px-4 py-2 rounded-full border border-orange-500 text-sm font-medium tracking-wider uppercase ">
//             POPULAR CATEGORY
//           </span>
//           <h2 className="text-3xl font-semibold text-gray-900 mt-4">
//             Popular Category For Learn
//           </h2>
//         </div>

//         <div className="grid grid-cols-1  sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-12">
//           {categories.map((category) => {
//             return (
//               <div
//                 key={category.id}
//                 className="bg-white rounded-md border border-gray-200 p-4 text-center shadow-sm hover:shadow-md transition-shadow duration-300 cursor-pointer group"
//               >
//                 {/* Icon */}
//                 <div className={`w-16 h-16 ${category.bgColor} rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300`}>
//                   <img src={category.img}/>
//                 </div>
                
//                 {/* Title */}
//                 <h3 className="text-sm font-medium text-gray-900 mb-2">
//                   {category.title}
//                 </h3>
                
//                 {/* Course Count */}
//                 <p className={` text-xs font-medium ${category.iconColor} `}>
//                   {category.courses}
//                 </p>
//               </div>
//             );
//           })}
//         </div>

//         {/* Browse All Categories Button */}
//         <div className="text-center">
//           <button className="bg-orange-500 hover:bg-orange-600 text-white font-semibold px-8 py-3 rounded-md transition-colors duration-300">
//             Browse All Categories
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Categories;

import React from 'react';
import { motion } from 'framer-motion';

const Categories = () => {
  const categories = [
    {
      id: 1,
      title: 'Computer Science',
      courses: '24 Course',
      img: "https://edukon.aminurislam.com/assets/images/category/icon/01.jpg",
      bgColor: 'bg-green-100',
      iconColor: 'text-[#75b71e]'
    },
    {
      id: 2,
      title: 'Civil Engineering',
      courses: '04 Course',
      img: "https://edukon.aminurislam.com/assets/images/category/icon/02.jpg",
      bgColor: 'bg-blue-100',
      iconColor: 'text-[#62abbb]'
    },
    {
      id: 3,
      title: 'Business Analysis',
      courses: '27 Course',
      img: "https://edukon.aminurislam.com/assets/images/category/icon/04.jpg",
      bgColor: 'bg-yellow-100',
      iconColor: 'text-[#9e5497]'
    },
    {
      id: 4,
      title: 'Data Science Analytics',
      courses: '28 Course',
      img: "https://edukon.aminurislam.com/assets/images/category/icon/05.jpg",
      bgColor: 'bg-purple-100',
      iconColor: 'text-[#b56959]'
    },
    {
      id: 5,
      title: 'Learning Management',
      courses: '78 Course',
      img: "https://edukon.aminurislam.com/assets/images/category/icon/06.jpg",
      bgColor: 'bg-red-100',
      iconColor: 'text-[#d1822c]'
    },
    {
      id: 6,
      title: 'Computer Engineering',
      courses: '38 Course',
      img: "https://edukon.aminurislam.com/assets/images/category/icon/03.jpg",
      bgColor: 'bg-orange-100',
      iconColor: 'text-[#bd9615]'
    }
  ];

  // Motion Variants
  const container = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const card = {
    hidden: { opacity: 0, y: 30 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
  };

  return (
    <div className="bg-gray-50 py-16 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <span className="text-orange-500 bg-orange-50 px-4 py-2 rounded-full border border-orange-500 text-sm font-medium tracking-wider uppercase ">
            POPULAR CATEGORY
          </span>
          <h2 className="text-3xl font-semibold text-gray-900 mt-4">
            Popular Category For Learn
          </h2>
        </div>

        {/* Grid with Motion */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-12"
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: false, amount: 0.3 }} // repeatable animation
        >
          {categories.map((category) => (
            <motion.div
              key={category.id}
              className="bg-white rounded-md border border-gray-200 p-4 text-center shadow-sm hover:shadow-md cursor-pointer group"
              variants={card}
              whileHover={{ scale: 1.05 }}
            >
              {/* Icon */}
              <motion.div 
                className={`w-16 h-16 ${category.bgColor} rounded-full flex items-center justify-center mx-auto mb-6`}
                whileHover={{ rotate: 15, scale: 1.1 }} // icon hover effect
                transition={{ type: "spring", stiffness: 300 }}
              >
                <img src={category.img} alt={category.title} />
              </motion.div>

              {/* Title */}
              <h3 className="text-sm font-medium text-gray-900 mb-2">
                {category.title}
              </h3>

              {/* Course Count */}
              <p className={`text-xs font-medium ${category.iconColor}`}>
                {category.courses}
              </p>
            </motion.div>
          ))}
        </motion.div>

        {/* Browse All Categories Button */}
        <div className="text-center">
          <button className="bg-orange-500 hover:bg-orange-600 text-white font-semibold px-8 py-3 rounded-md transition-colors duration-300">
            Browse All Categories
          </button>
        </div>
      </div>
    </div>
  );
};

export default Categories;