// import React from "react";
// import { RiCalendar2Line, RiMessage3Line } from "react-icons/ri";

// export const BlogSection = () => {
//   const blogs = [
//     {
//       id: 1,
//       title: "The Importance of Programming in Our Everyday Lives",
//       description:
//         "In today’s world, programming has become a cornerstone of modern society.",
//       date: "05 Dec 2024",
//       comments: 2,
//       image: "https://edulab.hivetheme.com/storage/lms/blogs/lms-tpDeHhz3.webp",
//     },
//     {
//       id: 2,
//       title: "The Importance of Programming in Our Everyday Lives",
//       description:
//         "In today’s world, programming has become a cornerstone of modern society.",
//       date: "05 Dec 2024",
//       comments: 2,
//       image: "https://edulab.hivetheme.com/storage/lms/blogs/lms-z5qgOccq.webp",
//     },
//     {
//       id: 3,
//       title: "The Importance of Programming in Our Everyday Lives",
//       description:
//         "In today’s world, programming has become a cornerstone of modern society.",
//       date: "05 Dec 2024",
//       comments: 2,
//       image: "https://edulab.hivetheme.com/storage/lms/blogs/lms-67igPh1X.webp",
//     },
//     {
//       id: 4,
//       title: "The Importance of Programming in Our Everyday Lives",
//       description:
//         "In today’s world, programming has become a cornerstone of modern society.",
//       date: "05 Dec 2024",
//       comments: 2,
//       image: "https://edulab.hivetheme.com/storage/lms/blogs/lms-1qnG9zWH.webp",
//     },
//     // Add more blog objects here
//   ];

//   return (
//     <>
//       <div className="relative py-16">
//         <div className="max-w-7xl mx-auto">
//           {/* HEADER */}
//           <div className="grid grid-cols-12 gap-4 items-center mb-10">
//             <div className="col-span-full text-center max-w-3xl mx-auto">
//               <h2 className="text-3xl md:text-4xl font-semibold text-gray-900">
//                 Explore Our Latest{" "}
//                 <span className="text-blue-600"> News &amp; Articles</span>
//               </h2>
//               <p className="mt-2 text-base text-gray-600">
//                 Stay informed with the newest updates, expert insights, and
//                 helpful tips from our blog. We cover everything from industry
//                 trends to practical how-tos, designed to keep you ahead of the
//                 curve.
//               </p>
//             </div>
//           </div>
//           <div className="grid lg:grid-cols-2 grid-cols-1 gap-4">
//             {blogs.map((blog) => (
//               <div key={blog.id}>
//                 <div className="flex flex-col sm:flex-row items-center bg-white rounded-md overflow-hidden h-full transition-all duration-300 group">
//                   {/* Blog Thumbnail */}
//                   <div className="relative aspect-video sm:aspect-square w-full sm:max-w-52 md:max-w-60 xl:max-w-64 overflow-hidden shrink-0">
//                     <img
//                       alt="Blog Thumbnail"
//                       src={blog.image}
//                       className="w-full h-full object-cover transition-transform duration-500 ease-in-out group-hover:scale-110"
//                     />
//                   </div>

//                   {/* Blog Content */}
//                   <div className="flex flex-col justify-center py-4 px-6 xl:px-8 border border-heading/15 border-t-0 sm:border-l-0 rtl:sm:border-l rtl:sm:border-r-0 sm:border-t rounded-b-2xl sm:rounded-r-2xl rtl:sm:rounded-r-0 rtl:sm:rounded-l-2xl sm:rounded-l-none rtl:sm:rounded-r-none h-full grow">
//                     <h6 className=" font-semibold text-base transition-colors duration-300 group-hover:text-blue-600">
//                       <a href="#" className="line-clamp-2">
//                         {blog.title}
//                       </a>
//                     </h6>
//                     <div className="mt-2 text-justify text-[14px]">
//                       <p>{blog.description}</p>
//                     </div>
//                     <div className="flex items-center flex-wrap gap-4 mt-6 text-gray-600">
//                       {/* Date */}
//                       <div className="rounded-full h-7 shrink-0 flex items-center gap-1">
//                         <RiCalendar2Line className="text-lg" />
//                         <span className="text-sm font-semibold">
//                           {blog.date}
//                         </span>
//                       </div>

//                       {/* Comments */}
//                       <div className="flex items-center gap-1 text-sm leading-none shrink-0">
//                         <RiMessage3Line className="text-lg" />
//                         <span>{blog.comments} Comments</span>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };


import { FaHeart } from "react-icons/fa";
import { motion } from "framer-motion";

const news = [
  { id: 1, image: "/news1.jpg", imageOnly: true, tall: true },
  {
    id: 2,
    title: "THREE REASONS WHY ENGLISH SPELLING IS CONFUSING",
    excerpt: "Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus...",
    author: "Steven Master",
    category: "News",
    likes: 70,
    tall: true,
  },
  { id: 3, image: "/news2.jpg", imageOnly: true, tall: true },
  {
    id: 4,
    title: "ONLINE OR FACE-TO-FACE? LEARNING ENGLISH TODAY",
    excerpt: "Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil...",
    author: "Steven Master",
    category: "News, Professional English",
    likes: 47,
    tall: true,
  },
  { id: 5, title: "EFFECTIVE LECTURING SKILLS IN ENGLISH", excerpt: "Temporibus autem quibusdam et aut officiis debitis aut rerum...", author: "Steven Master", category: "Advices, News", likes: 55 },
  { id: 6, image: "/news3.jpg", imageOnly: true },
  { id: 7, title: "WHY ARE YOU THINKING ABOUT LEARNING BETTER ENGLISH?", excerpt: "Nam libero tempore, cum soluta nobis est eligendi optio...", author: "Steven Master", category: "Advices, News", likes: 60 },
  { id: 8, image: "/news4.jpg", imageOnly: true },
];

const NewsCard = ({ item }) => {
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  if (item.imageOnly) {
    return (
      <motion.div
        className="overflow-hidden h-full"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: false, amount: 0.3 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        variants={cardVariants}
      >
        <img
          src={item.image}
          alt="news"
          className="w-full h-full object-cover hover:scale-110 transition duration-500"
        />
      </motion.div>
    );
  }

  return (
    <motion.div
      id="blog"
      className="bg-white flex flex-col justify-between p-5 h-full border border-gray-100"
      initial="hidden"
      whileInView="visible"
      viewport={{ once: false, amount: 0.3 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      variants={cardVariants}
    >
      <div>
        <h3 className="text-[10px] sm:text-xs md:text-sm font-bold text-gray-900 mb-2 hover:text-red-500 cursor-pointer">
          {item.title}
        </h3>
        <p className="text-gray-500 text-[10px] sm:text-xs mb-3">{item.excerpt}</p>
      </div>

      <div>
        <div className="flex justify-between items-center text-[10px] sm:text-xs">
          <div>
            <span className="text-gray-400">by </span>
            <span className="text-red-500 font-medium">{item.author}</span>
          </div>
          <div className="flex items-center gap-1 text-gray-400">
            <span>{item.likes}</span>
            <FaHeart size={10} />
          </div>
        </div>

        <div className="mt-1 text-[10px] sm:text-xs">
          <span className="text-gray-400">in </span>
          <span className="text-red-500">{item.category}</span>
        </div>
      </div>
    </motion.div>
  );
};

export const BlogSection = () => {
  return (
    <section className="bg-gray-50 py-12 px-4 sm:px-6">
      <div className="text-center mb-12">
        <div className="flex items-center justify-center gap-2 mb-3">
          <span className="text-red-500 text-xs">♦</span>
          <span className="text-xs font-semibold tracking-widest uppercase text-gray-500">
            latest Blogs
          </span>
        </div>
        <h2 className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-gray-900 leading-tight">
          Stay updated with the latest
          <br />
          <span className="text-red-500 italic">news & insights</span>
        </h2>
      </div>

      <div className="max-w-7xl mx-auto">
        
        {/* Row 1 */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 h-auto lg:h-[260px] gap-5">
          {news.slice(0, 4).map((item) => (
            <NewsCard key={item.id} item={item} />
          ))}
        </div>

        {/* Row 2 */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 h-auto lg:h-[220px] gap-5 mt-5">
          {news.slice(4, 8).map((item) => (
            <NewsCard key={item.id} item={item} />
          ))}
        </div>

      </div>
    </section>
  );
};