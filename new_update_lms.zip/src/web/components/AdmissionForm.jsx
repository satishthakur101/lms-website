import React from "react";
import { motion } from "framer-motion";

export const AdmissionForm = () => {
  // Motion variants
  const fadeUp = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <div id="admission" className="relative py-10 my-5 overflow-hidden">
      <div className="container mx-auto relative z-[1]">
        <div className="grid grid-cols-12 rounded-2xl overflow-hidden">
          
          {/* Left Section - Form */}
          <motion.div
            className="col-span-full lg:col-span-7"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: false, amount: 0.3 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            variants={fadeUp}
          >
            <div className="bg-gradient-to-b from-[#FEFBF0] to-[#E6F3EB] px-5 py-8 xl:p-20 h-full">
              
              {/* Heading */}
              <motion.h2
                className="text-3xl font-bold"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: false, amount: 0.3 }}
                transition={{ duration: 0.5 }}
              >
                Apply For <span className="text-green-600">Admission</span>
              </motion.h2>
              
              {/* Description */}
              <motion.p
                className="mt-3 text-gray-700 line-clamp-2"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: false, amount: 0.3 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                Our streamlined admission process makes it easy to enroll in
                courses that fit your career aspirations.
              </motion.p>

              {/* Form */}
              <motion.form
                className="mt-6"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: false, amount: 0.3 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <div className="grid grid-cols-2 gap-x-3 gap-y-4">
                  {[
                    { id: "first_name", label: "First Name" },
                    { id: "last_name", label: "Last Name" },
                    { id: "email", label: "Email", type: "email" },
                    { id: "phone", label: "Phone" },
                    { id: "password", label: "Password", type: "password" },
                    { id: "password_confirmation", label: "Confirm Password", type: "password" },
                  ].map(({ id, label, type = "text" }) => (
                    <div key={id} className="col-span-full lg:col-auto">
                      <input
                        type={type}
                        id={id}
                        name={id}
                        className="form-input bg-white text-sm rounded-full w-full px-4 py-[10px] peer"
                        placeholder={label}
                      />
                    </div>
                  ))}

                  <div className="col-span-full">
                    <input
                      type="text"
                      id="designation"
                      name="designation"
                      className="form-input bg-white rounded-full text-sm w-full px-4 py-[10px] peer"
                      placeholder="Designation"
                    />
                  </div>

                  <div className="col-span-full">
                    <textarea
                      id="about"
                      name="about"
                      rows={8}
                      className="form-input bg-white rounded-2xl w-full px-4 py-2 text-sm resize-none"
                      placeholder="About"
                    />
                  </div>

                  <div className="col-span-full flex justify-end">
                    <button
                      type="submit"
                      className="bg-green-600 px-6 hover:bg-green-700 text-white rounded-md py-2 text-sm font-semibold"
                    >
                      Submit Now
                    </button>
                  </div>
                </div>
              </motion.form>
            </div>
          </motion.div>

          {/* Right Section - Image */}
          <motion.div
            className="col-span-full lg:col-span-5 hidden lg:block"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: false, amount: 0.3 }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <div className="aspect-[1/1.38] h-full overflow-hidden">
              <img
                src="https://img.freepik.com/free-photo/friends-library_23-2147678815.jpg?uid=R176823449&ga=GA1.1.1433286368.1718702777&semt=ais_hybrid&w=740"
                alt="Admission banner"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>

        </div>
      </div>

      {/* Positional Background Elements */}
      <ul>
        <li className="block size-[29vw] rounded-full bg-[#D2EB1A]/15 blur-[200px] absolute top-0 xl:-top-20 right-0 xl:-right-20 z-0"></li>
        <li className="block size-[29vw] rounded-full bg-[#B326F4]/15 blur-[200px] absolute top-0 xl:-top-20 left-0 xl:-left-20 z-0"></li>
      </ul>
    </div>
  );
};