// import React from "react";

// export const Achivers = () => {
//   const cards = [
//     {
//       title: "Start Teaching Today",
//       description:
//         "Seamlessly engage technically sound collaborative reintermed goal oriented content rather than ethica",
//       buttonText: "Become A Instructor",
//       buttonBg: "bg-yellow-400 hover:bg-yellow-500 text-gray-900",
//       image: "https://edukon.aminurislam.com/assets/images/achive/01.png",
//     },
//     {
//       title: "If You Join Our Course",
//       description:
//         "Seamlessly engage technically sound collaborative reintermed goal oriented content rather than ethica",
//       buttonText: "Register For Free",
//       buttonBg: "bg-green-500 hover:bg-green-600 text-white",
//       image: "https://edukon.aminurislam.com/assets/images/achive/02.png",
//     },
//   ];
//   const stats = [
//     {
//       value: "30+",
//       color: "text-green-600",
//       label: "Years of Language Education\nExperience",
//     },
//     {
//       value: "3084+",
//       color: "text-blue-600",
//       label: "Learners Enrolled in Edukon\nCourses",
//     },
//     {
//       value: "330+",
//       color: "text-orange-600",
//       label: "Qualified Teachers And\nLanguage Experts",
//     },
//     {
//       value: "2300+",
//       color: "text-purple-600",
//       label: "Innovative Foreign Language\nCourses",
//     },
//   ];

//   return (
//     <>
//       <div
//         className=" relative py-10 px-4"
//         style={{
//           backgroundImage:
//             "url(https://edukon.aminurislam.com/static/media/02.ba699cd616f691881513.png)",
//           backgroundSize: "cover",
//           backgroundPosition: "center",
//           backgroundRepeat: "no-repeat",
//         }}
//       >
//         <div className="absolute inset-0 bg-white/10"></div>
//         <div className="relative z-10 max-w-7xl mx-auto">
//           <div className="text-center">
//             <span className="text-orange-500 border border-orange-600 text-sm bg-orange-50 px-4 py-2 rounded-full font-medium tracking-widest uppercase ">
//               START TO SUCCESS
//             </span>
//             <h1 className="text-3xl font-semibold text-gray-900 mb-10 mt-4">
//               Achieve Your Goals With Edukon
//             </h1>
//             <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-20">
//               {stats.map((item, index) => (
//                 <div key={index} className="text-center">
//                   <div className={`text-2xl  font-semibold ${item.color} mb-1`}>
//                     {item.value}
//                   </div>
//                   <p className="text-gray-700 text-sm font-medium whitespace-pre-line">
//                     {item.label}
//                   </p>
//                 </div>
//               ))}
//             </div>
//           </div>

//           {/* CTA Cards Section */}
//           <div className="grid md:grid-cols-2 gap-4 max-w-6xl mx-auto">
//             {cards.map((card, index) => (
//               <div
//                 key={index}
//                 className="relative bg-white flex rounded-md shadow-sm overflow-hidden"
//               >
//                 {/* Background Image as top-right element */}

//                 {/* Card Content */}
//                 <div className="relative p-4 flex items-center ">
//                   <div className="flex-1 pr-4">
//                     <h3 className="text-base font-semibold text-gray-900 mb-1">
//                       {card.title}
//                     </h3>
//                     <p className="text-gray-600 mb-3 text-sm leading-relaxed">
//                       {card.description}
//                     </p>
//                     <button
//                       className={`${card.buttonBg} font-mdeium px-6 py-3 rounded-md transition-colors duration-200 text-sm`}
//                     >
//                       {card.buttonText}
//                     </button>
//                   </div>
//                 </div>
//                 <div
//                   className=" w-full h-full relative -bottom-[57px] bg-no-repeat bg-contain"
//                   style={{ backgroundImage: `url(${card.image})` }}
//                 ></div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

import { useEffect, useReducer, useRef, useState } from "react";
import { FaUserGraduate, FaFolder, FaBriefcase, FaCalculator, FaGraduationCap } from "react-icons/fa";

const stats = [
  { icon: <FaUserGraduate size={28} />, count: 258, label: "STUDENTS" },
  { icon: <FaFolder size={28} />, count: 35, label: "LEARNING PROGRAMMES" },
  { icon: <FaBriefcase size={28} />, count: 12, label: "LANGUAGE TRAININGS" },
  { icon: <FaCalculator size={28} />, count: 9, label: "BRANCHES" },
  { icon: <FaGraduationCap size={28} />, count: 16, label: "TEACHERS" },
];

function useCountUp(target, duration = 2000, start = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime = null;
    const step = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [start, target, duration]);
  return count;
}

const StatCard = ({ icon, count, label, started }) => {
  const animated = useCountUp(count, 2000, started);
  return (
    <div
      className="flex flex-col items-center justify-center py-6 sm:py-8 px-3 sm:px-4 flex-1 min-w-[120px]"
      style={{
        border: "1px solid rgba(255,255,255,0.15)",
        background: "rgba(255,255,255,0.04)",
      }}
    >
      <div className="mb-3 sm:mb-4" style={{ color: "rgba(255,255,255,0.55)" }}>
        {icon}
      </div>
      <div
        className="font-bold text-white mb-1 sm:mb-2 text-2xl sm:text-[2.4rem]"
        style={{ lineHeight: 1, fontFamily: "'Montserrat', sans-serif" }}
      >
        {animated}
      </div>
      <div
        className="text-center tracking-widest text-[10px] sm:text-[0.58rem]"
        style={{ color: "rgba(255,255,255,0.45)", letterSpacing: "0.12em" }}
      >
        {label}
      </div>
    </div>
  );
};

export const Achivers = ()=> {
  const [started, setStarted] = useState(false);
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const sectionRef = useRef(null);

useEffect(() => {
  const observer = new IntersectionObserver(
    ([entry]) => {
      if (entry.isIntersecting) {
        setStarted(false);
        setTimeout(() => {
          setStarted(true);
        }, 50);
      }
    },
    { threshold: 0.3 }
  );

  if (sectionRef.current) observer.observe(sectionRef.current);

  return () => observer.disconnect();
}, []);

  const handleSubscribe = (e) => {
    e.preventDefault();
    if (!email) return;
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
    setEmail("");
  };

  return (
    <>
      <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300,400,700&display=swap" rel="stylesheet" />

      {/* Stats Section */}
      <section id="stats"
        ref={sectionRef}
        style={{
          backgroundImage: "url('/stats-bg.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundAttachment: "fixed",
          position: "relative",
        }}
      >
        {/* Dark overlay */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: "rgba(28, 28, 28, 0.78)",
            zIndex: 0,
          }}
        />

        <div
          className="relative max-w-7xl mx-auto py-10 sm:py-14 px-4"
          style={{ zIndex: 1 }}
        >
          {/* Title */}
          <p
            className="text-center mb-6 sm:mb-8 text-sm sm:text-base"
            style={{
              fontFamily: "'Montserrat', sans-serif",
              color: "rgba(255,255,255,0.75)",
              fontWeight: 300,
              letterSpacing: "0.04em",
            }}
          >
            Language School{" "}
            <em style={{ fontStyle: "italic", fontWeight: 300 }}>In Number</em>
          </p>

          {/* Stats Cards */}
          <div
            className="flex flex-wrap sm:flex-nowrap"
            style={{ border: "1px solid rgba(255,255,255,0.15)" }}
          >
            {stats.map((stat, i) => (
              <StatCard
                key={i}
                icon={stat.icon}
                count={stat.count}
                label={stat.label}
                started={started}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section
        style={{ backgroundColor: "#f5a623" }}
        className="py-6 sm:py-8 px-4 sm:px-6"
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 sm:gap-6">
          <h3
            className="text-base sm:text-lg text-center md:text-left"
            style={{
              fontFamily: "'Montserrat', sans-serif",
              color: "#fff",
              fontWeight: 400,
              whiteSpace: "nowrap",
            }}
          >
            Subscribe to our Newsletter
          </h3>

          <form
            onSubmit={handleSubscribe}
            className="flex flex-col sm:flex-row flex-1 max-w-lg w-full"
            style={{ gap: 0 }}
          >
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email *"
              required
              className="w-full"
              style={{
                flex: 1,
                padding: "12px 18px",
                border: "none",
                outline: "none",
                fontSize: "0.82rem",
                color: "#555",
                background: "#fff",
                fontFamily: "'Montserrat', sans-serif",
              }}
            />
            <button
              type="submit"
              className="w-full sm:w-auto mt-2 sm:mt-0"
              style={{
                backgroundColor: "#2c2c2c",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                fontSize: "0.68rem",
                fontWeight: 700,
                letterSpacing: "0.1em",
                cursor: "pointer",
                fontFamily: "'Montserrat', sans-serif",
                transition: "background 0.2s",
                whiteSpace: "nowrap",
              }}
              onMouseEnter={(e) => (e.target.style.background = "#444")}
              onMouseLeave={(e) => (e.target.style.background = "#2c2c2c")}
            >
              {submitted ? "✓ SUBSCRIBED!" : "SUBSCRIBE"}
            </button>
          </form>
        </div>
      </section>
    </>
  );
}
