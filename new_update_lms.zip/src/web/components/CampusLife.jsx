import { useState } from "react";

const images = [
  {
    id: 1,
    src: "./campus1.jpg",
    alt: "Students hanging out",
    category: "Social Life",
  },
  {
    id: 2,
     src: "./campus2.jpg",
    alt: "Arts & Culture event",
    category: "Arts & Culture",
    featured: true,
  },
  {
    id: 3,
     src: "./campus3.jpg",
    alt: "Art class",
    category: "Creative Arts",
  },
  {
    id: 4,
     src: "./campus4.jpg",
    alt: "Campus friends",
    category: "Community",
  },
  {
    id: 5,
     src: "./campus5.jpg",
    alt: "Study group",
    category: "Academics",
  },
];

export default function CampusLife() {
  const [hoveredId, setHoveredId] = useState(null);

  return (
    <div className=" bg-white py-16 px-4 font-sans">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center gap-2 mb-3">
          <span className="text-red-500 text-xs">♦</span>
          <span className="text-xs font-semibold tracking-widest uppercase text-gray-500">
            Campus Life
          </span>
        </div>
        <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 leading-tight">
          Experience learning beyond
          <br />
          the{" "}
          <span className="text-red-500 italic">classroom</span>
        </h2>
      </div>

      {/* Grid Layout */}
      <div className="max-w-7xl mx-auto">
        {/*
          Layout:
          [col1: top+bottom] [col2: full-height featured] [col3: top+bottom]
          On mobile: stack all vertically
        */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

          {/* Column 1: Two images stacked */}
          <div className="flex flex-col gap-4">
            {[images[0], images[3]].map((img) => (
              <div
                key={img.id}
                className="relative overflow-hidden rounded flex-1 group cursor-pointer"
                style={{ minHeight: "220px" }}
                onMouseEnter={() => setHoveredId(img.id)}
                onMouseLeave={() => setHoveredId(null)}
              >
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  style={{ minHeight: "220px", maxHeight: "260px" }}
                />
                {/* Hover overlay */}
                <div
                  className={`absolute inset-0 bg-black/60 transition-opacity duration-300 ${
                    hoveredId === img.id ? "opacity-100" : "opacity-0"
                  }`}
                />
                {/* Top-right icon */}
                <div
                  className={`absolute top-3 right-3 w-9 h-9 bg-white rounded-lg flex items-center justify-center shadow-lg transition-all duration-300 ${
                    hoveredId === img.id
                      ? "opacity-100 translate-y-0"
                      : "opacity-0 -translate-y-2"
                  }`}
                >
                  <span className="text-gray-800 text-lg font-bold leading-none">+</span>
                </div>
                {/* Bottom-left title */}
                <div
                  className={`absolute bottom-3 left-3 transition-all duration-300 ${
                    hoveredId === img.id
                      ? "opacity-100 translate-y-0"
                      : "opacity-0 translate-y-2"
                  }`}
                >
                  <span className="text-white text-sm font-semibold drop-shadow-lg">
                    {img.category}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Column 2: Featured image (full height) */}
          <div className="flex flex-col">
            {[images[1]].map((img) => (
              <div
                key={img.id}
                className="relative overflow-hidden rounded flex-1 group cursor-pointer"
                style={{ minHeight: "460px" }}
                onMouseEnter={() => setHoveredId(img.id)}
                onMouseLeave={() => setHoveredId(null)}
              >
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  style={{ minHeight: "460px" }}
                />
                {/* Dark overlay always slightly visible for featured */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 hover:bg-black/60 to-transparent" />

                {/* Always-visible bottom category label */}
                <div className="absolute bottom-4 left-4">
                  <span className="text-white text-base font-bold tracking-wide drop-shadow-lg">
                    {img.category}
                  </span>
                </div>

                {/* Hover: top-right icon */}
                <div
                  className={`absolute top-4 right-4 w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-xl transition-all duration-300 ${
                    hoveredId === img.id
                      ? "opacity-100 scale-100"
                      : "opacity-0 scale-75"
                  }`}
                >
                  <span className="text-gray-800 text-xl font-bold leading-none">+</span>
                </div>

                {/* Hover: red dot decoration (like in screenshot) */}
                <div
                  className={`absolute top-1/2 left-1/2 bg-black/60 -translate-x-1/2 -translate-y-1/2 w-5 h-5 rounded-full border-2 border-red-400 transition-all duration-300 ${
                    hoveredId === img.id ? "opacity-100 scale-100" : "opacity-0 scale-50"
                  }`}
                />
              </div>
            ))}
          </div>

          {/* Column 3: Two images stacked */}
          <div className="flex flex-col gap-4">
            {[images[2], images[4]].map((img) => (
              <div
                key={img.id}
                className="relative overflow-hidden rounded flex-1 group cursor-pointer"
                style={{ minHeight: "220px" }}
                onMouseEnter={() => setHoveredId(img.id)}
                onMouseLeave={() => setHoveredId(null)}
              >
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  style={{ minHeight: "220px", maxHeight: "260px" }}
                />
                {/* Hover overlay */}
                <div
                  className={`absolute inset-0 bg-black/60 transition-opacity duration-300 ${
                    hoveredId === img.id ? "opacity-100" : "opacity-0"
                  }`}
                />
                {/* Top-right icon */}
                <div
                  className={`absolute top-3 right-3 w-9 h-9 bg-white rounded-lg flex items-center justify-center shadow-lg transition-all duration-300 ${
                    hoveredId === img.id
                      ? "opacity-100 translate-y-0"
                      : "opacity-0 -translate-y-2"
                  }`}
                >
                  <span className="text-gray-800 text-lg font-bold leading-none">+</span>
                </div>
                {/* Bottom-left title */}
                <div
                  className={`absolute bottom-3 left-3 transition-all duration-300 ${
                    hoveredId === img.id
                      ? "opacity-100 translate-y-0"
                      : "opacity-0 translate-y-2"
                  }`}
                >
                  <span className="text-white text-sm font-semibold drop-shadow-lg">
                    {img.category}
                  </span>
                </div>
              </div>
            ))}
          </div>

        </div>
      </div>
    </div>
  );
}