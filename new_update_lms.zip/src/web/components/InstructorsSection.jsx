import { useState } from "react";

const teachers = [
  {
    id: 1,
    name: "Dr. Ramya Sharma",
    role: "Principal",
    subject: "Leadership & Administration",
    exp: "28 Years Experience",
    img: "https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=600&h=800&fit=crop&crop=top&auto=format&q=85",
    tag: "bg-yellow-400 text-yellow-900",
    h: 340,
  },
  {
    id: 2,
    name: "Mrs. Anita Mehta",
    role: "Headmaster",
    subject: "School Operations",
    exp: "22 Years Experience",
    img: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=600&h=900&fit=crop&crop=top&auto=format&q=85",
    tag: "bg-blue-400 text-blue-900",
    h: 480,
  },
  {
    id: 3,
    name: "Mrs. Priya Nair",
    role: "Vice Principal",
    subject: "Academic Affairs",
    exp: "18 Years Experience",
    img: "https://images.unsplash.com/photo-1580894732444-8ecded7900cd?w=600&h=800&fit=crop&crop=top&auto=format&q=85",
    tag: "bg-pink-400 text-pink-900",
    h: 260,
  },
  {
    id: 4,
    name: "Mrs. Sanjana Gupta",
    role: "Sr. Teacher – Maths",
    subject: "Mathematics",
    exp: "15 Years Experience",
    img: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=600&h=800&fit=crop&crop=top&auto=format&q=85",
    tag: "bg-orange-400 text-orange-900",
    h: 300,
  },
  {
    id: 5,
    name: "Dr. Kavitha Reddy",
    role: "Sr. Teacher – Science",
    subject: "Science & Biology",
    exp: "12 Years Experience",
    img: "https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=600&h=800&fit=crop&crop=top&auto=format&q=85",
    tag: "bg-emerald-400 text-emerald-900",
    h: 400,
  },
  {
    id: 6,
    name: "Ms. Sneha Joshi",
    role: "Teacher – English",
    subject: "English Literature",
    exp: "9 Years Experience",
    img: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=600&h=800&fit=crop&crop=top&auto=format&q=85",
    tag: "bg-purple-400 text-purple-900",
    h: 280,
  },
  {
    id: 7,
    name: "Ms. Vikrama Singh",
    role: "Teacher – History",
    subject: "History & Social Studies",
    exp: "11 Years Experience",
    img: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=600&h=800&fit=crop&crop=top&auto=format&q=85",
    tag: "bg-sky-400 text-sky-900",
    h: 360,
  },
  {
    id: 8,
    name: "Mrs. Deepa Thomas",
    role: "Teacher – Arts",
    subject: "Arts & Crafts",
    exp: "8 Years Experience",
    img: "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=600&h=800&fit=crop&crop=top&auto=format&q=85",
    tag: "bg-red-400 text-red-900",
    h: 320,
  },
];

function TeacherCard({ teacher }) {
  const [hovered, setHovered] = useState(false);

  return (
    <div id="teachers"
      className="relative overflow-hidden rounded-2xl cursor-pointer w-full"
      style={{ height: teacher.h }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <img
        src={teacher.img}
        alt={teacher.name}
        className="absolute inset-0 w-full h-full object-cover object-top"
        style={{
          transition: "transform 0.7s cubic-bezier(0.25,0.46,0.45,0.94)",
          transform: hovered ? "scale(1.09)" : "scale(1)",
        }}
      />

      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(to top, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0.08) 45%, transparent 70%)",
        }}
      />

      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(to top, rgba(0,0,0,0.93) 0%, rgba(0,0,0,0.55) 40%, rgba(0,0,0,0.12) 75%, transparent 100%)",
          opacity: hovered ? 1 : 0,
          transition: "opacity 0.45s ease",
        }}
      />

      <div className="absolute top-3 right-3 z-20">
        <span
          className={`${teacher.tag} text-[10px] font-black tracking-widest uppercase px-3 py-1.5 rounded-full shadow-lg`}
          style={{ backdropFilter: "blur(6px)" }}
        >
          {teacher.role}
        </span>
      </div>

      <div
        className="absolute bottom-0 left-0 right-0 z-20 px-4 pb-4"
        style={{
          transform: hovered ? "translateY(0px)" : "translateY(4px)",
          transition: "transform 0.45s ease",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 8,
            opacity: hovered ? 1 : 0,
            transform: hovered ? "translateY(0)" : "translateY(14px)",
            transition: "opacity 0.4s ease, transform 0.4s ease",
          }}
        >
          <span
            style={{
              color: "rgba(255,255,255,0.65)",
              fontSize: 11,
              fontWeight: 700,
              textTransform: "uppercase",
              letterSpacing: "0.08em",
            }}
          >
            📚 {teacher.subject}
          </span>
          <span
            style={{
              color: "rgba(255,255,255,0.65)",
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: "0.05em",
            }}
          >
            {teacher.exp}
          </span>
        </div>

        <div
          style={{
            height: 1,
            background: "rgba(255,255,255,0.25)",
            marginBottom: 10,
            transformOrigin: "left",
            transform: hovered ? "scaleX(1)" : "scaleX(0)",
            transition: "transform 0.45s ease 0.05s",
          }}
        />

        <h3
          style={{
            color: "#fff",
            fontWeight: 900,
            lineHeight: 1.15,
            letterSpacing: "-0.02em",
            textShadow: "0 2px 16px rgba(0,0,0,0.5)",
            fontSize: hovered ? "1.2rem" : "0.95rem",
            transition: "font-size 0.4s ease",
            margin: 0,
          }}
        >
          {teacher.name}
        </h3>
      </div>
    </div>
  );
}

export default function TeachersSection() {
  const columns = [
    [teachers[0], teachers[4]],
    [teachers[1], teachers[5]],
    [teachers[2], teachers[6]],
    [teachers[3], teachers[7]],
  ];

  return (
    <section style={{ background: "#0c0c0c", padding: "80px 16px" }}>
      
      <div
        style={{
          maxWidth: 1200,
          margin: "0 auto 56px",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
          <p className="text-gray-400 text-xs sm:text-sm">
            ✦ Our Faculty
          </p>

          <div
            className="flex flex-col sm:flex-row sm:items-end justify-between gap-6"
          >
            <h2
              style={{
                color: "#fff",
                fontWeight: 900,
                fontSize: "clamp(2rem, 6vw, 4rem)",
                lineHeight: 1.0,
                margin: 0,
                letterSpacing: "-0.03em",
              }}
            >
              The People{" "}
              <span
                style={{
                  WebkitTextStroke: "2px white",
                  color: "transparent",
                }}
              >
                Who Inspire.
              </span>
            </h2>
          </div>
        </div>
      </div>

      {/* GRID */}
      <div
        className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3"
      >
        {columns.map((col, ci) => (
          <div
            key={ci}
            className="flex flex-col gap-3"
            style={{
              marginTop: [0, 40, 20, 60][ci],
            }}
          >
            {col.map((teacher) => (
              <TeacherCard key={teacher.id} teacher={teacher} />
            ))}
          </div>
        ))}
      </div>

      <div className="max-w-7xl mx-auto mt-12 text-center">
        <button
          style={{
            background: "#fff",
            color: "#0c0c0c",
            border: "none",
            borderRadius: 16,
            padding: "16px 40px",
            fontWeight: 900,
            fontSize: 15,
            letterSpacing: "-0.01em",
            cursor: "pointer",
            transition: "transform 0.2s ease, box-shadow 0.2s ease",
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = "scale(1.04)";
            e.currentTarget.style.boxShadow = "0 8px 32px rgba(255,255,255,0.15)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = "scale(1)";
            e.currentTarget.style.boxShadow = "none";
          }}
        >
          Meet All Faculty Members →
        </button>
      </div>
    </section>
  );
} 