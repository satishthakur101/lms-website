export default function PaymentSection() {
  const logos = [
    { id: 1, alt: "GooglePay", src: "./GooglePay.webp" },
    { id: 2, alt: "Paytm", src: "./paytm.jpg" },
    { id: 3, alt: "Paypal", src: "./paypal.png" },
    { id: 4, alt: "PayU", src: "./ave.jpg" },
    { id: 5, alt: "Razorpay", src: "./razorpay.avif" },
    { id: 6, alt: "Biild", src: "./billd.png" },
  ];

  return (
    <section style={{
        backgroundImage:
          "url('./main-bg.jpg')",
      }} className=" py-12 px-6 border-y border-gray-200">
      
      <div className=" overflow-hidden max-w-7xl mx-auto">
        
        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3   gap-4 lg:grid-cols-6">
          
          {logos.map((logo, index) => (
            <div
              key={logo.id}
              className={`flex items-center justify-center bg-white border border-gray-200 px-5 py-2 
              `}
            >
              <img
                src={logo.src}
                alt={logo.alt}
                className=" object-contain w-32 "
              />
            </div>
          ))}

        </div>
      </div>
    </section>
  );
}