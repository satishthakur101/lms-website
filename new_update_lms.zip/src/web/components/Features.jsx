// import React from 'react';
// import { motion } from 'framer-motion';
// import { Star, Users, Globe, ExternalLink } from 'lucide-react';

// export default function Features() {
//   const courses = [
//     {
//       image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1471&q=80",
//       price: 30,
//       rating: 5,
//       reviews: "03",
//       title: "Fundamentals of Adobe XD Theory New",
//       lessons: "18x",
//       classType: "Online Class",
//       instructor: "William Smith",
//       instructorImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
//     },
//     {
//       image: "https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
//       price: 30,
//       rating: 5,
//       reviews: "03",
//       title: "Certified Graphic Design with Adobe Project Course",
//       lessons: "18x",
//       classType: "Online Class",
//       instructor: "Lora Smith",
//       instructorImage: "https://images.unsplash.com/photo-1494790108755-2616b612b602?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1387&q=80"
//     },
//     {
//       image: "https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
//       price: 30,
//       rating: 5,
//       reviews: "03",
//       title: "Theory Learn New Student And Fundamentals",
//       lessons: "18x",
//       classType: "Online Class",
//       instructor: "Robot Smith",
//       instructorImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1387&q=80"
//     },
//     {
//       image: "https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
//       price: 30,
//       rating: 5,
//       reviews: "03",
//       title: "Theory Learn New Student And Fundamentals",
//       lessons: "18x",
//       classType: "Online Class",
//       instructor: "Robot Smith",
//       instructorImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1387&q=80"
//     },
//     {
//       image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1471&q=80",
//       price: 30,
//       rating: 5,
//       reviews: "03",
//       title: "Fundamentals of Adobe XD Theory New",
//       lessons: "18x",
//       classType: "Online Class",
//       instructor: "William Smith",
//       instructorImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
//     },
//     {
//       image: "https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
//       price: 30,
//       rating: 5,
//       reviews: "03",
//       title: "Certified Graphic Design with Adobe Project Course",
//       lessons: "18x",
//       classType: "Online Class",
//       instructor: "Lora Smith",
//        instructorImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1387&q=80"
//       },
//     {
//       image: "https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
//       price: 30,
//       rating: 5,
//       reviews: "03",
//       title: "Theory Learn New Student And Fundamentals",
//       lessons: "18x",
//       classType: "Online Class",
//       instructor: "Robot Smith",
//       instructorImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1387&q=80"
//     },
//     {
//       image: "https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
//       price: 30,
//       rating: 5,
//       reviews: "03",
//       title: "Theory Learn New Student And Fundamentals",
//       lessons: "18x",
//       classType: "Online Class",
//       instructor: "Robot Smith",
//       instructorImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1387&q=80"
//     },
//   ];

//   // Framer Motion Variants
//   const container = {
//     hidden: {},
//     show: {
//       transition: {
//         staggerChildren: 0.15
//       }
//     }
//   };

//   const cardVariant = {
//     hidden: { opacity: 0, y: 30 },
//     show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' } }
//   };

//   return (
//     <div className='px-4 py-12 bg-gray-50'>
//       <div className="max-w-7xl mx-auto ">
//         {/* Header */}
//         <motion.div 
//           className="text-center mb-8"
//           initial={{ opacity: 0, y: 20 }}
//           whileInView={{ opacity: 1, y: 0 }}
//           viewport={{ once: false, amount: 0.3 }}
//           transition={{ duration: 0.6 }}
//         >
//           <span className="text-orange-500 bg-orange-50 rounded-full border border-orange-400 px-4 py-1 font-medium tracking-wider uppercase text-sm mb-2">
//             Featured Courses
//           </span>
//           <h1 className="text-3xl mt-1 font-semibold text-gray-900">
//             Pick A Course To Get Started
//           </h1>
//         </motion.div>
        
//         {/* Course Grid */}
//         <motion.div 
//           className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
//           variants={container}
//           initial="hidden"
//           whileInView="show"
//           viewport={{ once: false, amount: 0.2 }}
//         >
//           {courses.map((course, index) => (
//             <motion.div 
//               key={index} 
//               className="bg-white rounded-md shadow-sm overflow-hidden transition-shadow duration-300 hover:shadow-lg"
//               variants={cardVariant}
//               whileHover={{ scale: 1.03 }}
//             >
//               <div className="relative p-4">
//                 <img 
//                   src={course.image} 
//                   alt={course.title}
//                   className="w-full h-48 object-cover rounded-md"
//                 />
//                 <div className="absolute -bottom-0 right-7 bg-orange-500 text-white h-10 w-10 p-1 text-[12px] flex justify-center items-center rounded-full font-semibold">
//                   ${course.price}
//                 </div>
//               </div>
              
//               <div className="px-4 pt-2 pb-4">
//                 {/* Rating and Reviews */}
//                 <div className="flex items-center mb-3">
//                   <span className="bg-green-500 text-white px-2 py-1 rounded text-xs font-medium mr-2">
//                     Adobe XD
//                   </span>
//                   <div className="flex items-center">
//                     {[...Array(5)].map((_, i) => (
//                       <Star key={i} className="w-4 h-4 fill-orange-400 text-orange-400" />
//                     ))}
//                     <span className="text-gray-600 text-sm ml-2">{course.reviews} reviews</span>
//                   </div>
//                 </div>
                
//                 {/* Title */}
//                 <h3 className="text-[15px] font-medium text-gray-900 mb-4 leading-tight">
//                   {course.title}
//                 </h3>
                
//                 {/* Course Details */}
//                 <div className="flex items-center justify-between mb-4 text-sm text-gray-600">
//                   <div className="flex items-center">
//                     <Users className="w-4 h-4 mr-1 text-orange-500" />
//                     <span className='text-[14px]'>{course.lessons} Lesson</span>
//                   </div>
//                   <div className="flex items-center">
//                     <Globe className="w-4 h-4 mr-1 text-orange-500" />
//                     <span>{course.classType}</span>
//                   </div>
//                 </div>
                
//                 {/* Instructor */}
//                 <div className="flex items-center justify-between">
//                   <div className="flex items-center">
//                     <img 
//                       src={course.instructorImage} 
//                       alt={course.instructor}
//                       className="w-8 h-8 rounded-full mr-3"
//                     />
//                     <span className="text-gray-900 text-sm font-medium">{course.instructor}</span>
//                   </div>
//                   <button className="flex items-center text-sm text-orange-500 hover:text-orange-600 font-medium">
//                     Read More
//                     <ExternalLink className="w-4 h-4 ml-1" />
//                   </button>
//                 </div>
//               </div>
//             </motion.div>
//           ))}
//         </motion.div>
//       </div>
//     </div>
//   );
// }

import React from "react";
import { FaUserGraduate, FaEye } from "react-icons/fa";

const courses = [
  {
    id: 1,
    title: "Advanced Architectural Research",
    instructor: "David M. Peterson",
    img: "https://images.unsplash.com/photo-1523240795612-9a054b0db644",
    profile: "https://randomuser.me/api/portraits/women/1.jpg",
    lessons: 0,
    students: 2,
    oldPrice: "£40.00",
    newPrice: "£30.00",
  },
  {
    id: 2,
    title: "Advanced Landscape & Urbanism",
    instructor: "David M. Peterson",
    img: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b",
    profile: "https://randomuser.me/api/portraits/women/2.jpg",
    lessons: 0,
    students: 1,
    oldPrice: "£80.00",
    newPrice: "£65.00",
  },
  {
    id: 3,
    title: "Approaches to the design of...",
    instructor: "Chester J. Graham",
    img: "https://images.unsplash.com/photo-1519389950473-47ba0277781c",
    profile: "https://randomuser.me/api/portraits/men/3.jpg",
    lessons: 0,
    students: 0,
    oldPrice: "£70.00",
    newPrice: "£45.00",
  },
  {
    id: 4,
    title: "Transdisciplinary Design",
    instructor: "Jeremy E. Orem",
    img: "https://images.unsplash.com/photo-1581093458791-9f3c3900df8c",
    profile: "https://randomuser.me/api/portraits/men/4.jpg",
    lessons: 0,
    students: 1,
    oldPrice: "£85.00",
    newPrice: "£69.00",
  },
];

export default function Features() {
  return (
    <div id="courses" className="px-4 sm:px-6 md:px-10 py-8 sm:py-10 bg-gray-100">
       
      <div className="text-center mb-8 sm:mb-12">
        <div className="flex items-center justify-center gap-2 mb-2 sm:mb-3">
          <span className="text-red-500 text-[10px] sm:text-xs">♦</span>
          <span className="text-[10px] sm:text-xs font-semibold tracking-widest uppercase text-gray-500">
             Popular Courses
          </span>
        </div>

        <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-extrabold text-gray-900 leading-tight">
           Start Learning with
          <br />
          Our{" "}
          <span className="text-red-500 italic">Top Picks</span>
        </h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {courses.map((course) => (
          <div
            key={course.id}
            className="bg-white rounded-md shadow-sm overflow-hidden group transition-all duration-300 hover:shadow-lg"
          >
            {/* IMAGE */}
            <div className="relative">
              <img
                src={course.img}
                alt=""
                className="w-full h-40 sm:h-44 md:h-48 object-cover"
              />

              {/* HOVER OVERLAY */}
              <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-300">
                <button className="bg-white text-gray-800 px-3 sm:px-4 py-1.5 sm:py-2 text-[10px] sm:text-sm font-medium">
                  SEE COURSE
                </button>
              </div>
            </div>

            {/* INSTRUCTOR BAR */}
            <div className="bg-[#1e2a44] text-white flex items-center gap-2 sm:gap-3 px-3 sm:px-4 py-2.5 sm:py-3">
              <img
                src={course.profile}
                alt=""
                className="w-7 h-7 sm:w-8 sm:h-8 rounded-full border border-gray-200"
              />
              <p className="text-xs sm:text-sm">{course.instructor}</p>
            </div>

            {/* CONTENT */}
            <div className="p-3 sm:p-4">
              <h3 className="text-gray-800 text-xs sm:text-sm font-semibold mb-2 sm:mb-3 leading-snug">
                {course.title}
              </h3>

             <hr className="mb-2 sm:mb-3 border-gray-400 border-t opacity-70" />

              {/* STATS */}
              <div className="flex items-center justify-between text-gray-500 text-[10px] sm:text-xs mb-2 sm:mb-3">
                <div className="flex items-center gap-1 sm:gap-2">
                  <FaUserGraduate className="text-sm sm:text-lg" />
                  <span className="text-sm sm:text-lg">{course.lessons}</span>
                </div>
                <div className="flex items-center gap-1 sm:gap-2">
                  <FaEye className="text-sm sm:text-lg" />
                  <span className="text-sm sm:text-lg">{course.students}</span>
                </div>
              </div>

              {/* PRICE */}
              <div className="flex justify-end items-center gap-2">
                <span className="text-gray-400 line-through text-xs sm:text-sm">
                  {course.oldPrice}
                </span>
                <span className="text-yellow-600 font-semibold text-sm sm:text-base">
                  {course.newPrice}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}