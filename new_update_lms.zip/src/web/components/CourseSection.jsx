import { useState } from "react";
import { FaStar, FaCalendarAlt } from "react-icons/fa";

const tabs = ["ENGLISH", "GERMAN", "SPANISH", "FRENCH", "CHINESE"];

const courses = {
  ENGLISH: [
    { id: 1, image: "/course1.jpg", title: "ENGLISH FOR CHILDREN", rating: 0, price: null, free: true, tags: "Chinese, English", weeks: "12 Week" },
    { id: 2, image: "/course2.jpg", title: "30-60-90 BUSINESS", rating: 0, price: "$529.00", free: false, tags: "Chinese, German", weeks: "24 Week" },
    { id: 3, image: "/course3.jpg", title: "BASIC SKILLS", rating: 0, price: "$159.00", free: false, tags: "Chinese, French", weeks: "12 Week" },
    { id: 4, image: "/course4.jpg", title: "SECOND LANGUAGE", rating: 0, price: "$425.00", free: false, tags: "Chinese, Spanish", weeks: "12 Week" },
  ],
  GERMAN: [
    { id: 1, image: "/course2.jpg", title: "GERMAN BASICS", rating: 0, price: "$199.00", free: false, tags: "German, English", weeks: "10 Week" },
    { id: 2, image: "/course3.jpg", title: "ADVANCED GERMAN", rating: 0, price: "$349.00", free: false, tags: "German", weeks: "20 Week" },
    { id: 3, image: "/course4.jpg", title: "GERMAN FOR KIDS", rating: 0, price: null, free: true, tags: "German, Kids", weeks: "8 Week" },
    { id: 4, image: "/course1.jpg", title: "BUSINESS GERMAN", rating: 0, price: "$499.00", free: false, tags: "German, Business", weeks: "16 Week" },
  ],
  SPANISH: [
    { id: 1, image: "/course3.jpg", title: "SPANISH BASICS", rating: 0, price: "$149.00", free: false, tags: "Spanish, English", weeks: "10 Week" },
    { id: 2, image: "/course1.jpg", title: "TRAVEL SPANISH", rating: 0, price: null, free: true, tags: "Spanish, Travel", weeks: "6 Week" },
    { id: 3, image: "/course2.jpg", title: "SPANISH CULTURE", rating: 0, price: "$279.00", free: false, tags: "Spanish, Culture", weeks: "14 Week" },
    { id: 4, image: "/course4.jpg", title: "ADVANCED SPANISH", rating: 0, price: "$399.00", free: false, tags: "Spanish", weeks: "18 Week" },
  ],
  FRENCH: [
    { id: 1, image: "/course4.jpg", title: "FRENCH FOR BEGINNERS", rating: 0, price: "$179.00", free: false, tags: "French, English", weeks: "12 Week" },
    { id: 2, image: "/course2.jpg", title: "PARIS FRENCH", rating: 0, price: "$299.00", free: false, tags: "French, Travel", weeks: "10 Week" },
    { id: 3, image: "/course1.jpg", title: "FRENCH LITERATURE", rating: 0, price: null, free: true, tags: "French, Literature", weeks: "8 Week" },
    { id: 4, image: "/course3.jpg", title: "BUSINESS FRENCH", rating: 0, price: "$449.00", free: false, tags: "French, Business", weeks: "20 Week" },
  ],
  CHINESE: [
    { id: 1, image: "/course1.jpg", title: "ENGLISH FOR CHILDREN", rating: 0, price: null, free: true, tags: "Chinese, English", weeks: "12 Week" },
    { id: 2, image: "/course2.jpg", title: "30-60-90 BUSINESS", rating: 0, price: "$529.00", free: false, tags: "Chinese, German", weeks: "24 Week" },
    { id: 3, image: "/course3.jpg", title: "BASIC SKILLS", rating: 0, price: "$159.00", free: false, tags: "Chinese, French", weeks: "12 Week" },
    { id: 4, image: "/course4.jpg", title: "SECOND LANGUAGE", rating: 0, price: "$425.00", free: false, tags: "Chinese, Spanish", weeks: "12 Week" },
  ],
};

const StarRating = () => (
  <div className="flex gap-0.5">
    {[1, 2, 3, 4, 5].map((s) => (
      <FaStar key={s} size={10} className="text-gray-300" />
    ))}
  </div>
);

const CourseCard = ({ course }) => (
  <div className="bg-white border border-gray-200 overflow-hidden hover:shadow-md transition-shadow duration-300">
    <div className="overflow-hidden h-36">
      <img
        src={course.image}
        alt={course.title}
        className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
      />
    </div>
    <div className="p-3">
      <h4 className="font-bold text-gray-900 mb-2 leading-tight text-[10px] sm:text-xs md:text-sm tracking-wide">
        {course.title}
      </h4>
      <div className="flex items-center justify-between mb-3">
        <StarRating />
        {course.free ? (
          <span className="bg-red-500 text-white text-[10px] font-bold px-2 py-1">
            Free
          </span>
        ) : (
          <span className="text-white text-[10px] font-bold px-2 py-1 bg-cyan-500">
            {course.price}
          </span>
        )}
      </div>
      <div className="flex flex-col sm:flex-row sm:justify-between gap-1 border-t pt-2">
        <a href="#" className="text-red-500 hover:underline text-[10px] sm:text-xs">
          {course.tags}
        </a>
        <span className="text-gray-400 text-[10px] sm:text-xs">
          {course.weeks}
        </span>
      </div>
    </div>
  </div>
);

export const CourseSection = () => {
  const [activeTab, setActiveTab] = useState("CHINESE");

  return (
    <div className="bg-white">
      {/* Tabs */}
      <div className="border-b border-gray-200 overflow-x-auto">
        <div className="max-w-6xl mx-auto flex justify-start sm:justify-center whitespace-nowrap">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className="relative px-4 sm:px-6 py-3 text-[10px] sm:text-xs font-semibold tracking-widest"
              style={{
                color: activeTab === tab ? "#e8192c" : "#201f1f",
              }}
            >
              {tab}
              <span
                className="absolute bottom-0 left-0 right-0 h-0.5"
                style={{
                  background: "#e8192c",
                  transform: activeTab === tab ? "scaleX(1)" : "scaleX(0)",
                }}
              />
            </button>
          ))}
        </div>
      </div>

      {/* Cards */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {courses[activeTab].map((course) => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 md:grid-cols-3">
        
        <div className="px-6 md:px-8 py-8 bg-pink-400">
          <h3 className="text-white font-bold text-lg mb-3">School News</h3>
          <p className="text-white text-xs mb-4 opacity-90">
            Cum sociis natoque penatibus et magnis dis parturient montes mus.
          </p>
          <a href="#" className="text-white text-xs font-semibold hover:underline">
            Read more
          </a>
        </div>

        <div className="px-6 md:px-8 py-8 bg-yellow-500">
          <h3 className="text-white font-bold text-lg mb-4">Opening Hours</h3>
          <div className="space-y-2">
            {[
              { day: "Monday - Friday", time: "8.00 - 17.00" },
              { day: "Saturday", time: "9.30 - 17.30" },
              { day: "Sunday", time: "9.30 - 15.00" },
            ].map((row) => (
              <div key={row.day} className="flex justify-between border-b border-white/30 pb-1">
                <span className="text-white text-xs">{row.day}</span>
                <span className="text-white text-xs font-semibold">{row.time}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="px-6 md:px-8 py-8 bg-cyan-500">
          <h3 className="text-white font-bold text-lg mb-4">Find your course</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-2">
            <select className="bg-white text-xs px-2 py-2">
              <option>English</option>
            </select>
            <input type="text" placeholder="Name" className="bg-white text-xs px-2 py-2" />
            <input type="text" placeholder="Phone" className="bg-white text-xs px-2 py-2" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input type="email" placeholder="Email" className="bg-white text-xs px-2 py-2" />
            <input type="text" placeholder="mm/dd/yyyy" className="bg-white text-xs px-2 py-2" />
            <button className="text-white text-xs py-2 bg-cyan-700 hover:opacity-90">
              SEND MESSAGE
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};