// import React from 'react';
// import { BookOpen, Users, Award } from 'lucide-react';

// export default function About() {
//   return (
//     <div className="bg-white pb-12 pt-4 px-4 ">
//       <div className="max-w-7xl mx-auto">
//         <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 relative">

//           {/* Left Side: Image with Shape */}
//           <div className="lg:col-span-7 relative">
//             {/* Green Background Shape */}
//             <div
//               className="absolute inset-0 h-[350px] sm:h-[450px] lg:h-[520px] bg-green-500"
//               style={{
//                 clipPath: 'polygon(0% 0%, 2% 0%, 100% 100%, 0% 100%)',
//               }}
//             ></div>

//             {/* Main Image */}
//             <div className="relative -bottom-[112px] z-10 flex justify-center lg:justify-end mt-10 lg:mt-0">
//               <img
//                 src="https://edukon.aminurislam.com/assets/images/about/01.png"
//                 alt="About Us"
//                 className="w-64 sm:w-80 md:w-[350px] lg:w-[400px] h-auto object-cover"
//               />
//             </div>
//           </div>

//           {/* Right Side: Text and Features */}
//           <div className="lg:col-span-5 flex flex-col justify-center space-y-6 mt-20 lg:mt-0">
//             <div className="space-y-4">
//               <h3 className="text-orange-500 font-semibold text-sm   uppercase tracking-wider">
//                 About Our Edukon
//               </h3>
//               <h2 className="text-3xl font-semibold text-gray-900 leading-tight">
//                 Good Qualification Services And Better Skills
//               </h2>
//               <p className="text-gray-600 text-[15px] text-justify">
//                 Distinctively provide access multifunctional users whereas transparent processes some
//                 incentivize efficient functionalities rather than extensive architect communicate
//                 leveraged services and cross-platform.
//               </p>
//             </div>

//             {/* Features List */}
//             <div className="space-y-6">
//               {/* Feature 1 */}
//               <div className="flex items-start space-x-4">
//                 <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
//                   <Award className="w-6 h-6 text-green-600" />
//                 </div>
//                 <div>
//                   <h4 className="font-semibold text-gray-900 mb-1">Skilled Instructors</h4>
//                   <p className="text-gray-600 text-sm">
//                     Distinctively provide access multifunctional users whereas
//                     communicate leveraged services.
//                   </p>
//                 </div>
//               </div>

//               {/* Feature 2 */}
//               <div className="flex items-start space-x-4">
//                 <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
//                   <BookOpen className="w-6 h-6 text-blue-600" />
//                 </div>
//                 <div>
//                   <h4 className="font-semibold text-gray-900 mb-1">Get Certificate</h4>
//                   <p className="text-gray-600 text-sm">
//                     Distinctively provide access multifunctional users whereas
//                     communicate leveraged services.
//                   </p>
//                 </div>
//               </div>

//               {/* Feature 3 */}
//               <div className="flex items-start space-x-4">
//                 <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
//                   <Users className="w-6 h-6 text-yellow-600" />
//                 </div>
//                 <div>
//                   <h4 className="font-semibold text-gray-900 mb-1">Online Classes</h4>
//                   <p className="text-gray-600 text-sm">
//                     Distinctively provide access multifunctional users whereas
//                     communicate leveraged services.
//                   </p>
//                 </div>
//               </div>
//             </div>
//           </div>

//         </div>
//       </div>
//     </div>
//   );
// }

// import React from 'react';
// import { motion } from 'framer-motion';
// import { BookOpen, Users, Award } from 'lucide-react';

// export default function About() {
//   // Motion variants
//   const container = {
//     hidden: {},
//     show: {
//       transition: {
//         staggerChildren: 0.2
//       }
//     }
//   };

//   const fadeUp = {
//     hidden: { opacity: 0, y: 30 },
//     show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' } }
//   };

//   return (
//     <div className="bg-white pb-12 pt-4 px-4">
//       <div className="max-w-7xl mx-auto">
//         <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 relative">

//           {/* Left Side: Image with Shape */}
//           <motion.div
//             className="lg:col-span-7 relative"
//             variants={fadeUp}
//             initial="hidden"
//             whileInView="show"
//             viewport={{ once: false, amount: 0.3 }}
//           >
//             {/* Green Background Shape */}
//             <div
//               className="absolute inset-0 h-[350px] sm:h-[450px] lg:h-[520px] bg-green-500"
//               style={{ clipPath: 'polygon(0% 0%, 2% 0%, 100% 100%, 0% 100%)' }}
//             ></div>

//             {/* Main Image */}
//             <motion.div
//               className="relative -bottom-[112px] z-10 flex justify-center lg:justify-end mt-10 lg:mt-0"
//               // whileHover={{ scale: 1.05, rotate: 2 }}
//               // transition={{ type: 'spring', stiffness: 300 }}
//             >
//               <img
//                 src="https://edukon.aminurislam.com/assets/images/about/01.png"
//                 alt="About Us"
//                 className="w-64 sm:w-80 md:w-[350px] lg:w-[400px] h-auto object-cover"
//               />
//             </motion.div>
//           </motion.div>

//           {/* Right Side: Text and Features */}
//           <motion.div
//             className="lg:col-span-5 flex flex-col justify-center space-y-6 mt-20 lg:mt-0"
//             variants={container}
//             initial="hidden"
//             whileInView="show"
//             viewport={{ once: false, amount: 0.3 }}
//           >
//             <motion.div variants={fadeUp} className="space-y-4">
//               <h3 className="text-orange-500 font-semibold text-sm uppercase tracking-wider">
//                 About Our Edukon
//               </h3>
//               <h2 className="text-3xl font-semibold text-gray-900 leading-tight">
//                 Good Qualification Services And Better Skills
//               </h2>
//               <p className="text-gray-600 text-[15px] text-justify">
//                 Distinctively provide access multifunctional users whereas transparent processes some
//                 incentivize efficient functionalities rather than extensive architect communicate
//                 leveraged services and cross-platform.
//               </p>
//             </motion.div>

//             {/* Features List */}
//             <div className="space-y-6">
//               {/* Feature 1 */}
//               <motion.div variants={fadeUp} className="flex items-start space-x-4">
//                 <motion.div
//                   className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0"
//                   whileHover={{ scale: 1.2, rotate: 10 }}
//                   transition={{ type: 'spring', stiffness: 300 }}
//                 >
//                   <Award className="w-6 h-6 text-green-600" />
//                 </motion.div>
//                 <div>
//                   <h4 className="font-semibold text-gray-900 mb-1">Skilled Instructors</h4>
//                   <p className="text-gray-600 text-sm">
//                     Distinctively provide access multifunctional users whereas
//                     communicate leveraged services.
//                   </p>
//                 </div>
//               </motion.div>

//               {/* Feature 2 */}
//               <motion.div variants={fadeUp} className="flex items-start space-x-4">
//                 <motion.div
//                   className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0"
//                   whileHover={{ scale: 1.2, rotate: 10 }}
//                   transition={{ type: 'spring', stiffness: 300 }}
//                 >
//                   <BookOpen className="w-6 h-6 text-blue-600" />
//                 </motion.div>
//                 <div>
//                   <h4 className="font-semibold text-gray-900 mb-1">Get Certificate</h4>
//                   <p className="text-gray-600 text-sm">
//                     Distinctively provide access multifunctional users whereas
//                     communicate leveraged services.
//                   </p>
//                 </div>
//               </motion.div>

//               {/* Feature 3 */}
//               <motion.div variants={fadeUp} className="flex items-start space-x-4">
//                 <motion.div
//                   className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0"
//                   whileHover={{ scale: 1.2, rotate: 10 }}
//                   transition={{ type: 'spring', stiffness: 300 }}
//                 >
//                   <Users className="w-6 h-6 text-yellow-600" />
//                 </motion.div>
//                 <div>
//                   <h4 className="font-semibold text-gray-900 mb-1">Online Classes</h4>
//                   <p className="text-gray-600 text-sm">
//                     Distinctively provide access multifunctional users whereas
//                     communicate leveraged services.
//                   </p>
//                 </div>
//               </motion.div>
//             </div>
//           </motion.div>

//         </div>
//       </div>
//     </div>
//   );
// }

import { useState, useEffect } from "react";
const ArrowRightIcon = () => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={2}
    className="w-4 h-4"
  >
    <path
      d="M5 12h14M12 5l7 7-7 7"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);
const DecorativeDots = () => (
  <div className="grid grid-cols-5 gap-1.5">
    {Array.from({ length: 25 }).map((_, i) => (
      <div
        key={i}
        className="w-1.5 h-1.5 rounded-full bg-gray-300 opacity-60"
      />
    ))}
  </div>
);

const WavyDecor = () => (
  <svg
    viewBox="0 0 40 80"
    className="w-8 h-16 text-yellow-400"
    fill="none"
    stroke="currentColor"
    strokeWidth={2.5}
    strokeLinecap="round"
  >
    <path d="M20 5 Q30 15 20 25 Q10 35 20 45 Q30 55 20 65 Q10 75 20 75" />
  </svg>
);

const About = () => {
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setAnimated(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const stats = [
    { value: "10k", label: "Students" },
    { value: "300", label: "Professors" },
    { value: "48k", label: "Programs" },
    { value: "2k", label: "Research" },
  ];

  return (
    <div id="about" className="font-sans bg-[#f5f0e8] min-h-screen">
      {/* ── ABOUT SECTION ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-16 py-12 lg:py-20">
        <div className="flex flex-col lg:flex-row items-center gap-10 lg:gap-16">
          {/* LEFT – image collage */}
          <div className="relative w-full lg:w-[45%] flex-shrink-0 flex justify-center">
            {/* Decorative dots top-left */}
            <div className="absolute -top-4 -left-2 z-0 hidden sm:block">
              <DecorativeDots />
            </div>

            {/* Wavy yellow line */}
            <div className="absolute top-8 -left-4 z-10 hidden sm:block">
              <WavyDecor />
            </div>

            {/* Decorative dots bottom-right */}
            <div className="absolute -bottom-4 -right-2 z-0 hidden sm:block">
              <DecorativeDots />
            </div>

            {/* Image stack */}
            <div className="relative w-[300px] sm:w-[340px] h-[360px] sm:h-[420px]">
              {/* Back-left image (students sitting) */}
              <div
                className={`absolute top-0 left-0 w-[160px] sm:w-[280px] h-[300px] sm:h-[360px] rounded-2xl overflow-hidden shadow-lg border-4 border-white z-10 transition-all duration-700 ${animated ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"}`}
                style={{ transitionDelay: "0.1s" }}
              >
                <img
                  src="./about1.jpg"
                  alt="Students on stairs"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Front-right image (girl with backpack) */}
              <div
                className={`absolute bottom-0 -right-20 w-[180px] sm:w-[250px] h-[300px] sm:h-[350px] rounded-2xl overflow-hidden  z-20 transition-all duration-700 ${animated ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
                style={{ transitionDelay: "0.25s" }}
              >
                <img
                  src="./about2.png"
                  alt="Student with backpack"
                  className="w-full h-full object-cover"
                />
              </div>

              <div
                className={`absolute bottom-20 right-0 bg-white rounded-xl shadow-xl px-4 py-3 z-30 transition-all duration-700 ${animated ? "opacity-100 scale-100" : "opacity-0 scale-90"}`}
                style={{ transitionDelay: "0.4s" }}
              >
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-extrabold text-gray-800">
                    27
                  </span>
                  <div className="text-xs text-gray-500 leading-tight">
                    Years of
                    <br />
                    Experience
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT – text content */}
          <div
            className={`w-full lg:w-[55%] transition-all duration-700 ${animated ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"}`}
            style={{ transitionDelay: "0.15s" }}
          >
            {/* Label */}
            <p className="text-[#c0392b] text-xs font-bold uppercase tracking-[0.18em] mb-3">
              About Our University
            </p>

            {/* Heading */}
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 leading-tight mb-5">
              A few words
              <br />
              about the{" "}
              <span className="text-[#c0392b]" style={{ fontStyle: "italic" }}>
                University
              </span>
            </h2>

            {/* Body */}
            <div className="border-l-6 border-[#c0392b] pl-4 mb-7">
              <p className="text-gray-700 text-sm sm:text-base leading-relaxed">
                Our community is being called to reimagine the future. As the
                only university where a renowned design school comes together
                with premier colleges, we are making learning more relevant and
                transformational.
              </p>
            </div>

            {/* Feature list */}
            <div className="space-y-5 mb-8">
              {/* Building Trust */}
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0  flex items-center justify-center text-[#c0392b]">
                  
                  <img src="./iconabout1.png" />
                </div>
                <div>
                  <h4 className="text-gray-800 font-bold text-sm sm:text-base">
                    Building Trust
                  </h4>
                  <p className="text-gray-600 text-xs sm:text-sm">
                    We are committed to building trust
                  </p>
                </div>
              </div>

              {/* Trusted by Students */}
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0  flex items-center justify-center text-[#c0392b]">
                 <img src="./about-1-icon.png" />
                </div>
                <div>
                  <h4 className="text-gray-800 font-bold text-sm sm:text-base">
                    Trusted by Students
                  </h4>
                  <p className="text-gray-600 text-xs sm:text-sm">
                    Most trusted &amp; recommended by students
                  </p>
                </div>
              </div>
            </div>

            {/* CTA Button */}
            <button className="inline-flex items-center gap-2 border-2 border-[#c0392b] text-[#c0392b] px-6 py-3 rounded text-sm font-semibold hover:bg-[#c0392b] hover:text-white transition-colors duration-200">
              Book an Appointment
              <ArrowRightIcon />
            </button>
          </div>
        </div>
      </section>

      {/* ── STATS BANNER ── */}
      <section className="bg-[#9b1c31] w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-16 py-10">
          <div className="grid grid-cols-2 md:grid-cols-4 divide-y-2 md:divide-y-0 md:divide-x-2 divide-white/20">
            {stats.map((stat, i) => (
              <div
                key={stat.label}
                className={`flex flex-col items-center justify-center py-6 md:py-4 transition-all duration-700 ${animated ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
                style={{ transitionDelay: `${0.5 + i * 0.1}s` }}
              >
                <span
                  className="text-white font-black leading-none mb-1"
                  style={{
                    fontSize: "clamp(2rem, 5vw, 3.5rem)",
                    fontStyle: "italic",
                    fontFamily: "Georgia, serif",
                  }}
                >
                  {stat.value}
                </span>
                <span className="text-white/70 text-xs sm:text-sm uppercase tracking-widest font-medium">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
export default About;
