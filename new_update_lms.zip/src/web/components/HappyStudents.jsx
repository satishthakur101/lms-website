// // src/web/components/HappyStudents.jsx
// import React from "react";
// import { Swiper, SwiperSlide } from "swiper/react";
// import { Autoplay, Pagination } from "swiper/modules";
// import "swiper/css";
// import "swiper/css/pagination";
// import { motion } from "framer-motion";

// // Import images (Vite-compatible)


// const testimonials = [
//   {
//     tag: "AWESOME!",
//     tagColor: "#4fc3c3",
//     text: "Vivamus fermentum ex quis imperdiet sodales. Sed aliquam nibh tellus, a rutrum turpis pellentesque ac. Nulla nibh libero, tincidunt vero eos et accusamus et iusto odio dignissimos ducimus",
//     name: "KIRA SIMS",
//     role: "Student",
//     nameColor: "#4fc3c3",
//     avatar: "./st1.jpg",
//   },
//   {
//     tag: "HIGH QUALITY!",
//     tagColor: "#f0617a",
//     text: "Vivamus fermentum ex quis imperdiet sodales. Sed aliquam nibh tellus, a rutrum turpis pellentesque ac. Nulla nibh libero, tincidunt vero eos et accusamus et iusto odio dignissimos ducimus",
//     name: "PHIL NEAL",
//     role: "Designer",
//     nameColor: "#f0617a",
//     avatar: "./st2.jpg",
//   },
//   {
//     tag: "SO SIMPLE!",
//     tagColor: "#f5a623",
//     text: "Vivamus fermentum ex quis imperdiet sodales. Sed aliquam nibh tellus, a rutrum turpis pellentesque ac. Nulla nibh libero, tincidunt vero eos et accusamus et iusto odio dignissimos ducimus",
//     name: "KIRA SIMS",
//     role: "Student",
//     nameColor: "#f5a623",
//     avatar: "./st3.jpg",
//   },
//   {
//     tag: "AWESOME!",
//     tagColor: "#4fc3c3",
//     text: "Vivamus fermentum ex quis imperdiet sodales. Sed aliquam nibh tellus, a rutrum turpis pellentesque ac. Nulla nibh libero, tincidunt vero eos et accusamus et iusto odio dignissimos ducimus",
//     name: "SARAH JONES",
//     role: "Teacher",
//     nameColor: "#4fc3c3",
//     avatar: "./st1.jpg",
//   },
//   {
//     tag: "HIGH QUALITY!",
//     tagColor: "#f0617a",
//     text: "Vivamus fermentum ex quis imperdiet sodales. Sed aliquam nibh tellus, a rutrum turpis pellentesque ac. Nulla nibh libero, tincidunt vero eos et accusamus et iusto odio dignissimos ducimus",
//     name: "MARK LEE",
//     role: "Developer",
//     nameColor: "#f0617a",
//     avatar: "./st2.jpg",
//   },
// ];

// const TestimonialCard = ({ item }) => {
//   const cardVariants = {
//     hidden: { opacity: 0, y: 20 },
//     visible: { opacity: 1, y: 0 },
//   };

//   return (
//     <motion.div
//       initial="hidden"
//       whileInView="visible"
//       viewport={{ once: false, amount: 0.3 }}
//       transition={{ duration: 0.5, ease: "easeOut" }}
//       variants={cardVariants}
//       style={{ display: "flex", flexDirection: "column", gap: 0 }}
//     >
//       <div
//         style={{
//           border: "1px solid #e2e2e2",
//           padding: "22px 20px",
//           background: "#fff",
//         }}
//       >
//         <p
//           className="text-justify text-base"
//           style={{
//             color: item.tagColor,
//             fontWeight: 600,
//             letterSpacing: "0.09em",
//             margin: "0 0 10px 0",
//           }}
//         >
//           {item.tag}
//         </p>
//         <p
//           className="text-justify text-sm text-gray-600"
//           style={{ lineHeight: "1.8", margin: 0 }}
//         >
//           {item.text}
//         </p>
//       </div>

//       <div style={{ height: "14px", background: "transparent" }} />

//       <div
//         style={{
//           display: "flex",
//           alignItems: "stretch",
//           border: "1px solid #e2e2e2",
//           background: "#fff",
//           overflow: "hidden",
//         }}
//       >
//         <img
//           src={item.avatar}
//           alt={item.name}
//           style={{
//             width: "58px",
//             height: "58px",
//             objectFit: "cover",
//             flexShrink: 0,
//             display: "block",
//           }}
//         />
//         <div
//           style={{
//             flex: 1,
//             backgroundColor: item.nameColor,
//             padding: "10px 14px",
//             display: "flex",
//             flexDirection: "column",
//             justifyContent: "center",
//           }}
//         >
//           <span
//             style={{
//               display: "block",
//               color: "#fff",
//               fontWeight: 700,
//               fontSize: "0.67rem",
//               letterSpacing: "0.07em",
//             }}
//           >
//             {item.name}
//           </span>
//           <span
//             style={{
//               display: "block",
//               color: "rgba(255,255,255,0.88)",
//               fontSize: "0.63rem",
//               marginTop: "2px",
//             }}
//           >
//             {item.role}
//           </span>
//         </div>
//       </div>
//     </motion.div>
//   );
// };

// const HappyStudents = () => (
//   <section id="contact" style={{ background: "#fff", padding: "60px 24px 60px" }}>
//     <div className="text-center mb-12">
//       <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 leading-tight">
//         Our Thriving Students
//         <br />
//         <span className="text-red-500 italic">learning & insights</span>
//       </h2>
//     </div>

//     <div className="max-w-7xl mx-auto">
//       <Swiper
//         modules={[Autoplay, Pagination]}
//         spaceBetween={20}
//         slidesPerView={3}
//         autoplay={{ delay: 3000, disableOnInteraction: false }}
//         pagination={{ clickable: true }}
//         loop={true}
//         style={{ paddingBottom: "46px" }}
//         breakpoints={{
//           0: { slidesPerView: 1 },
//           640: { slidesPerView: 2 },
//           1024: { slidesPerView: 4 },
//         }}
//       >
//         {testimonials.map((item, i) => (
//           <SwiperSlide key={i}>
//             <TestimonialCard item={item} />
//           </SwiperSlide>
//         ))}
//       </Swiper>
//     </div>

//     <style>{`
//       .swiper-pagination-bullet {
//         background: #ccc;
//         opacity: 1;
//         width: 8px;
//         height: 8px;
//       }
//       .swiper-pagination-bullet-active {
//         background: #e8192c !important;
//       }
//     `}</style>
//   </section>
// );

// export default HappyStudents;


// src/web/components/HappyStudents.jsx
import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";
import { motion } from "framer-motion";

const testimonials = [
  {
    tag: "AWESOME!",
    tagColor: "#4fc3c3",
    text: "Vivamus fermentum ex quis imperdiet sodales...",
    name: "KIRA SIMS",
    role: "Student",
    nameColor: "#4fc3c3",
    avatar: "/st1.jpg", // public folder path
  },
  {
    tag: "HIGH QUALITY!",
    tagColor: "#f0617a",
    text: "Vivamus fermentum ex quis imperdiet sodales...",
    name: "PHIL NEAL",
    role: "Designer",
    nameColor: "#f0617a",
    avatar: "/st2.jpg",
  },
  {
    tag: "SO SIMPLE!",
    tagColor: "#f5a623",
    text: "Vivamus fermentum ex quis imperdiet sodales...",
    name: "KIRA SIMS",
    role: "Student",
    nameColor: "#f5a623",
    avatar: "/st3.jpg",
  },
  {
    tag: "AWESOME!",
    tagColor: "#4fc3c3",
    text: "Vivamus fermentum ex quis imperdiet sodales...",
    name: "SARAH JONES",
    role: "Teacher",
    nameColor: "#4fc3c3",
    avatar: "/st1.jpg",
  },
  {
    tag: "HIGH QUALITY!",
    tagColor: "#f0617a",
    text: "Vivamus fermentum ex quis imperdiet sodales...",
    name: "MARK LEE",
    role: "Developer",
    nameColor: "#f0617a",
    avatar: "/st2.jpg",
  },
];

const TestimonialCard = ({ item }) => {
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: false, amount: 0.3 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      variants={cardVariants}
      className="flex flex-col gap-0"
    >
      <div className="border p-5 bg-white">
        <p
          className="text-base font-semibold"
          style={{ color: item.tagColor, letterSpacing: "0.09em", marginBottom: "10px" }}
        >
          {item.tag}
        </p>
        <p className="text-sm text-gray-600" style={{ lineHeight: 1.8 }}>
          {item.text}
        </p>
      </div>

      <div style={{ height: "14px" }} />

      <div className="flex border bg-white overflow-hidden">
        <img
          src={item.avatar}
          alt={item.name}
          className="w-14 h-14 object-cover flex-shrink-0"
        />
        <div
          className="flex-1 flex flex-col justify-center p-2.5"
          style={{ backgroundColor: item.nameColor }}
        >
          <span className="text-white font-bold text-xs tracking-wider">{item.name}</span>
          <span className="text-white/88 text-[10px] mt-0.5">{item.role}</span>
        </div>
      </div>
    </motion.div>
  );
};

const HappyStudents = () => (
  <section id="contact" className="bg-white py-16 px-6">
    <div className="text-center mb-12">
      <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 leading-tight">
        Our Thriving Students
        <br />
        <span className="text-red-500 italic">learning & insights</span>
      </h2>
    </div>

    <div className="max-w-7xl mx-auto">
      <Swiper
        modules={[Autoplay, Pagination]}
        spaceBetween={20}
        slidesPerView={3}
        autoplay={{ delay: 3000, disableOnInteraction: false }}
        pagination={{ clickable: true }}
        loop={true}
        style={{ paddingBottom: "46px" }}
        breakpoints={{
          0: { slidesPerView: 1 },
          640: { slidesPerView: 2 },
          1024: { slidesPerView: 4 },
        }}
      >
        {testimonials.map((item, i) => (
          <SwiperSlide key={i}>
            <TestimonialCard item={item} />
          </SwiperSlide>
        ))}
      </Swiper>
    </div>

    <style>{`
      .swiper-pagination-bullet {
        background: #ccc;
        opacity: 1;
        width: 8px;
        height: 8px;
      }
      .swiper-pagination-bullet-active {
        background: #e8192c !important;
      }
    `}</style>
  </section>
);

export default HappyStudents;