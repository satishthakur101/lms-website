// import { useState, useEffect } from "react";

// /* ---------------- DATA ---------------- */
// const sections = [
//   {
//     id: 1,
//     sectionTag: "Classes 4 - 10",
//     sectionColor: "from-violet-500 to-purple-600",
//     sectionBorder: "#d8b4fe",
//     sectionBg: "#faf5ff",
//     programs: [
//       {
//         title: "BYJU'S The Learning App",
//         desc: "Personalised learning app to learn anytime, anywhere",
//         cta: "Know more",
//         image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=500&q=80",
//         accent: "#7c3aed",
//         tag: "App Learning",
//       },
//       {
//         title: "BYJU'S Classes",
//         desc: "Personalised online tutoring program",
//         cta: "Know more",
//         badge: "NEW",
//         image: "https://images.unsplash.com/photo-1588072432836-e10032774350?w=500&q=80",
//         accent: "#db2777",
//         tag: "Live Classes",
//       },
//     ],
//     hasCta: { label: "Book a FREE Class" },
//   },
//   {
//     id: 2,
//     sectionTag: "JEE / NEET",
//     sectionColor: "from-blue-500 to-cyan-500",
//     sectionBorder: "#93c5fd",
//     sectionBg: "#eff6ff",
//     programs: [
//       {
//         title: "Aakash JEE",
//         desc: "JEE preparation program",
//         cta: "Explore",
//         image: "https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=500&q=80",
//         accent: "#0891b2",
//         tag: "Engineering",
//       },
//       {
//         title: "Aakash NEET",
//         desc: "NEET preparation program",
//         cta: "Explore",
//         image: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=500&q=80",
//         accent: "#0d9488",
//         tag: "Medical",
//       },
//     ],
//   },
//   {
//     id: 3,
//     sectionTag: "Classes LKG - 3",
//     sectionColor: "from-green-400 to-emerald-500",
//     sectionBorder: "#86efac",
//     sectionBg: "#f0fdf4",
//     programs: [
//       {
//         title: "Early Learn",
//         desc: "Learning for kids",
//         cta: "Explore",
//         image: "https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=500&q=80",
//         accent: "#16a34a",
//         tag: "Kids",
//       },
//     ],
//   },
//   {
//     id: 4,
//     sectionTag: "IAS",
//     sectionColor: "from-amber-500 to-orange-500",
//     sectionBorder: "#fcd34d",
//     sectionBg: "#fffbeb",
//     programs: [
//       {
//         title: "IAS Program",
//         desc: "Civil services preparation",
//         cta: "Explore",
//         image: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?w=500&q=80",
//         accent: "#d97706",
//         tag: "Civil Services",
//       },
//     ],
//   },
// ];

// /* ---------------- CARD ---------------- */
// function ProgramRow({ program }) {
//   const [hover, setHover] = useState(false);

//   return (
//     <div
//       onMouseEnter={() => setHover(true)}
//       onMouseLeave={() => setHover(false)}
//       style={{
//         display: "flex",
//         gap: 15,
//         padding: 14,
//         borderRadius: 12,
//         background: hover ? "#fff" : "transparent",
//         boxShadow: hover ? "0 4px 20px rgba(0,0,0,0.06)" : "none",
//         transition: "0.3s",
//       }}
//     >
//       <img
//         src={program.image}
//         style={{
//           width: 120,
//           height: 80,
//           objectFit: "cover",
//           borderRadius: 10,
//         }}
//       />

//       <div>
//         <h3 style={{ fontSize: 15, fontWeight: 700 }}>{program.title}</h3>
//         <p style={{ fontSize: 13, color: "#6b7280" }}>{program.desc}</p>
//         <button style={{ color: program.accent, fontWeight: 600 }}>
//           {program.cta} →
//         </button>
//       </div>
//     </div>
//   );
// }

// /* ---------------- SECTION ---------------- */
// function Section({ section }) {
//   return (
//     <div
//       style={{
//         borderRadius: 16,
//         background: section.sectionBg,
//         border: `1px solid ${section.sectionBorder}`,
//         padding: 15,
//       }}
//     >
//       <h3 style={{ fontWeight: 700, marginBottom: 10 }}>
//         {section.sectionTag}
//       </h3>

//       {section.programs.map((p, i) => (
//         <ProgramRow key={i} program={p} />
//       ))}
//     </div>
//   );
// }

// /* ---------------- MAIN ---------------- */
// export default function ByjusSection() {
//   return (
//     <div style={{ padding: 40, background: "#f8fafc" }}>

//        <div className="text-center mb-12">
//         <div className="flex items-center justify-center gap-2 mb-3">
//           <span className="text-red-500 text-xs">♦</span>
//           <span className="text-xs font-semibold tracking-widest uppercase text-gray-500">
//             India's #1 EdTech Platform
//           </span>
//         </div>
//         <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 leading-tight">
//          Comprehensive Learning

//           <br />
//        {" "}
//           <span className="text-red-500 italic">Programs & Classes</span>
//         </h2>
//       </div>
//       <div

//       className="grid grid-cols-2 gap-4"
//       >
//         {sections.map((sec) => (
//           <Section key={sec.id} section={sec} />
//         ))}
//       </div>

//     </div>
//   );
// }

// import { useState, useRef, useEffect } from "react";

// const programs = [
//   {
//     id: 1,
//     tag: "Classes 4–10",
//     section: "App Learning",
//     title: "BYJU'S Learning App",
//     desc: "Personalised learning anytime, anywhere — adaptive lessons that grow with you.",
//     cta: "Know more",
//     image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=700&q=80",
//     accent: "#7c3aed",
//     wide: true,
//   },
//   {
//     id: 2,
//     tag: "Classes 4–10",
//     section: "Live Classes",
//     title: "BYJU'S Classes",
//     desc: "One-on-one online tutoring with expert teachers.",
//     cta: "Book FREE Class",
//     badge: "NEW",
//     image: "https://images.unsplash.com/photo-1588072432836-e10032774350?w=500&q=80",
//     accent: "#db2777",
//   },
//   {
//     id: 3,
//     tag: "JEE / Engineering",
//     section: "Aakash",
//     title: "JEE Preparation",
//     desc: "India's most trusted JEE coaching — structured, rigorous, result-driven.",
//     cta: "Explore",
//     image: "https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=500&q=80",
//     accent: "#0891b2",
//   },
//   {
//     id: 4,
//     tag: "NEET / Medical",
//     section: "Aakash",
//     title: "NEET Preparation",
//     desc: "Comprehensive NEET coaching for aspiring doctors and healthcare professionals.",
//     cta: "Explore",
//     image: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=500&q=80",
//     accent: "#0d9488",
//   },
//   {
//     id: 5,
//     tag: "LKG – Class 3",
//     section: "Early Learning",
//     title: "Early Learn",
//     desc: "Fun, visual, and interactive learning experiences designed for young kids.",
//     cta: "Explore",
//     image: "https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=500&q=80",
//     accent: "#16a34a",
//   },
//   {
//     id: 6,
//     tag: "Civil Services",
//     section: "IAS",
//     title: "IAS Program",
//     desc: "End-to-end UPSC Civil Services preparation — prelims to interview stage.",
//     cta: "Explore",
//     image: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?w=500&q=80",
//     accent: "#d97706",
//   },
// ];

// function ProgramCard({ program, active }) {
//   const [hovered, setHovered] = useState(false);

//   return (
//     <div
//       onMouseEnter={() => setHovered(true)}
//       onMouseLeave={() => setHovered(false)}
//       style={{
//         flexShrink: 0,
//         width: program.wide ? 360 : 300,
//         borderRadius: 20,
//         overflow: "hidden",
//         border: "0.5px solid #e5e7eb",
//         background: "#fff",
//         cursor: "pointer",
//         scrollSnapAlign: "start",
//         transform: hovered ? "translateY(-4px)" : "translateY(0)",
//         transition: "transform 0.2s ease",
//         boxShadow: hovered ? "0 8px 24px rgba(0,0,0,0.08)" : "none",
//       }}
//     >
//       {/* Image */}
//       <div style={{ position: "relative" }}>
//         <img
//           src={program.image}
//           alt={program.title}
//           style={{
//             width: "100%",
//             height: program.wide ? 200 : 170,
//             objectFit: "cover",
//             display: "block",
//           }}
//         />
//         {/* Tag */}
//         <span
//           style={{
//             position: "absolute",
//             top: 14,
//             left: 14,
//             fontSize: 11,
//             fontWeight: 600,
//             letterSpacing: "0.06em",
//             textTransform: "uppercase",
//             padding: "4px 10px",
//             borderRadius: 20,
//             background: "rgba(255,255,255,0.9)",
//             color: "#1a1a1a",
//             backdropFilter: "blur(8px)",
//           }}
//         >
//           {program.tag}
//         </span>
//         {/* Badge */}
//         {program.badge && (
//           <span
//             style={{
//               position: "absolute",
//               top: 14,
//               right: 14,
//               fontSize: 10,
//               fontWeight: 700,
//               letterSpacing: "0.08em",
//               textTransform: "uppercase",
//               padding: "3px 8px",
//               borderRadius: 20,
//               background: "#e24b4a",
//               color: "#fff",
//             }}
//           >
//             {program.badge}
//           </span>
//         )}
//       </div>

//       {/* Body */}
//       <div style={{ padding: "16px 18px 18px" }}>
//         <div
//           style={{
//             fontSize: 11,
//             fontWeight: 600,
//             letterSpacing: "0.1em",
//             textTransform: "uppercase",
//             color: "#9ca3af",
//             marginBottom: 4,
//           }}
//         >
//           {program.section}
//         </div>

//         <div
//           style={{
//             fontFamily: "'Georgia', serif",
//             fontSize: 20,
//             fontWeight: 700,
//             lineHeight: 1.2,
//             color: "#111827",
//             marginBottom: 6,
//           }}
//         >
//           {program.title}
//         </div>

//         <div
//           style={{
//             fontSize: 13,
//             color: "#6b7280",
//             lineHeight: 1.5,
//             marginBottom: 14,
//           }}
//         >
//           {program.desc}
//         </div>

//         <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
//           <button
//             style={{
//               fontSize: 13,
//               fontWeight: 600,
//               padding: "7px 14px",
//               borderRadius: 30,
//               border: `1.5px solid ${program.accent}`,
//               background: "transparent",
//               color: program.accent,
//               cursor: "pointer",
//               transition: "opacity 0.15s",
//             }}
//           >
//             {program.cta}
//           </button>
//           <div
//             style={{
//               width: 32,
//               height: 32,
//               borderRadius: "50%",
//               display: "flex",
//               alignItems: "center",
//               justifyContent: "center",
//               border: "1.5px solid #e5e7eb",
//               fontSize: 14,
//               color: "#374151",
//               background: hovered ? "#f9fafb" : "transparent",
//               transition: "background 0.15s",
//             }}
//           >
//             →
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default function ByjusSection() {
//   const trackRef = useRef(null);
//   const [activeIndex, setActiveIndex] = useState(0);

//   useEffect(() => {
//     const track = trackRef.current;
//     if (!track) return;
//     const handleScroll = () => {
//       const cards = track.querySelectorAll(".byj-card");
//       let active = 0;
//       let minDist = Infinity;
//       cards.forEach((c, i) => {
//         const d = Math.abs(c.getBoundingClientRect().left - track.getBoundingClientRect().left);
//         if (d < minDist) { minDist = d; active = i; }
//       });
//       setActiveIndex(active);
//     };
//     track.addEventListener("scroll", handleScroll);
//     return () => track.removeEventListener("scroll", handleScroll);
//   }, []);

//   return (
//     <div  style={{ padding: "2rem 0", background: "#f8fafc", overflow: "hidden" }}>

//     <div className="max-w-7xl mx-auto">
//       <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6, padding: "0 1.5rem" }}>
//         <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#e24b4a", flexShrink: 0 }} />
//         <span style={{ fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", fontWeight: 600, color: "#9ca3af" }}>
//           India's #1 EdTech Platform
//         </span>
//       </div>

//       {/* Headline */}
//       <div
//         style={{
//           fontFamily: "'Georgia', serif",
//           fontSize: 38,
//           fontWeight: 900,
//           lineHeight: 1.1,
//           color: "#111827",
//           padding: "0 1.5rem",
//           marginBottom: "1.5rem",
//         }}
//       >
//         Explore our<br />
//         <span style={{ color: "#e24b4a", fontStyle: "italic" }}>Learning Programs</span>
//       </div>

//       {/* Scroll hint */}
//       <div style={{ padding: "0 1.5rem", fontSize: 12, color: "#9ca3af", display: "flex", alignItems: "center", gap: 5, marginBottom: 12 }}>
//         <span>→</span> Scroll to explore
//       </div>

//       {/* Cards Track */}
//       <div
//         ref={trackRef}
//         style={{
//           display: "flex",
//           gap: 16,
//           overflowX: "auto",
//           padding: "0 1.5rem 1.5rem",
//           scrollSnapType: "x mandatory",
//           WebkitOverflowScrolling: "touch",
//           scrollbarWidth: "none",
//           msOverflowStyle: "none",
//         }}
//       >
//         {programs.map((p, i) => (
//           <div key={p.id} className="byj-card">
//             <ProgramCard program={p} active={i === activeIndex} />
//           </div>
//         ))}
//       </div>

//       {/* Dots */}
//       <div style={{ display: "flex", gap: 8, justifyContent: "center", padding: "0 1.5rem", marginTop: 4 }}>
//         {programs.map((_, i) => (
//           <div
//             key={i}
//             style={{
//               width: i === activeIndex ? 20 : 8,
//               height: 3,
//               borderRadius: 2,
//               background: i === activeIndex ? "#e24b4a" : "#d1d5db",
//               transition: "width 0.2s, background 0.2s",
//             }}
//           />
//         ))}
//       </div>
// </div>
//     </div>
//   );
// }

import { useState } from "react";

const programs = [
  {
    id: 1,
    cat: "Class 4–10",
    catColor: "bg-purple-100",
    catText: "text-purple-800",
    title: "BYJU'S Learning App",
    desc: "Mobile app se ghar baithe padho. Har topic video, quiz aur practice ke saath.",
    img: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=600&q=80",
    forWho: "Class 4 se 10 ke students",
    badge: null,
    cta: "App ke baare mein janiye",
  },
  {
    id: 2,
    cat: "Class 4–10",
    catColor: "bg-purple-100",
    catText: "text-purple-800",
    title: "BYJU'S Live Classes",
    desc: "Expert teachers ke saath live 1-on-1 online class. Apne time pe schedule karo.",
    img: "https://images.unsplash.com/photo-1588072432836-e10032774350?w=600&q=80",
    forWho: "Class 4 se 10 ke students",
    badge: "Naya",
    cta: "Free class book karo",
  },
  {
    id: 3,
    cat: "JEE / NEET",
    catColor: "bg-blue-100",
    catText: "text-blue-800",
    title: "Aakash JEE Coaching",
    desc: "IIT-JEE ki taiyaari ke liye India ka sabse trusted program. Structured aur result-oriented.",
    img: "https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=600&q=80",
    forWho: "Class 11–12 / Dropper",
    badge: null,
    cta: "Details dekhiye",
  },
  {
    id: 4,
    cat: "JEE / NEET",
    catColor: "bg-blue-100",
    catText: "text-blue-800",
    title: "Aakash NEET Coaching",
    desc: "Medical college ke liye NEET ki complete taiyaari — Biology se Physics tak.",
    img: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=600&q=80",
    forWho: "Class 11–12 / Dropper",
    badge: null,
    cta: "Details dekhiye",
  },
  {
    id: 5,
    cat: "Chote Bachche",
    catColor: "bg-green-100",
    catText: "text-green-800",
    title: "Early Learn (LKG–Class 3)",
    desc: "Chote bacchon ke liye fun aur colorful learning. Videos, games aur stories se padhai.",
    img: "https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=600&q=80",
    forWho: "LKG se Class 3 ke bacche",
    badge: null,
    cta: "Explore karo",
  },
  {
    id: 6,
    cat: "IAS / UPSC",
    catColor: "bg-yellow-100",
    catText: "text-yellow-800",
    title: "IAS Preparation Program",
    desc: "UPSC Civil Services ki poori taiyaari — Prelims se Interview tak ek hi jagah.",
    img: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?w=600&q=80",
    forWho: "Graduation ke baad",
    badge: null,
    cta: "Program dekhiye",
  },
];

const cats = ["Sab", ...new Set(programs.map((p) => p.cat))];

function ProgramCard({ p }) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className={`bg-white rounded-xl overflow-hidden border ${hovered ? "border-gray-400 -translate-y-1" : "border-gray-200"} transform transition-all duration-200 cursor-pointer`}
    >
      <div className="relative">
        <img src={p.img} alt={p.title} className="w-full h-40 sm:h-44 md:h-48 object-cover" />

        {/* Ke liye overlay */}
        <div className="absolute top-2 right-2 bg-white/90 px-2 py-1 rounded shadow text-[10px] sm:text-xs text-gray-700 font-medium whitespace-nowrap">
          Ke liye:{" "}
          <span className="text-gray-900 font-semibold">{p.forWho}</span>
        </div>
      </div>

      <div className="p-4 sm:p-5">
        {/* Category + Badge */}
        <div className="flex items-center justify-between mb-2">
          <span
            className={`text-[10px] sm:text-xs font-medium uppercase px-2 py-1 rounded ${p.catColor} ${p.catText}`}
          >
            {p.cat}
          </span>
          {p.badge && (
            <span className="text-[9px] sm:text-[10px] font-medium uppercase px-2 py-1 rounded bg-yellow-100 text-yellow-800">
              {p.badge}
            </span>
          )}
        </div>

        {/* Title */}
        <div className="text-sm sm:text-base md:text-lg font-medium text-gray-900 mb-1.5 leading-snug">
          {p.title}
        </div>

        {/* Description */}
        <div className="text-xs sm:text-sm text-gray-500 mb-3.5 leading-relaxed">
          {p.desc}
        </div>

        {/* CTA Button */}
        <button className="text-[10px] sm:text-xs font-medium px-3 sm:px-4 py-1.5 sm:py-2 rounded bg-gradient-to-r from-orange-500 to-pink-600 text-white transition hover:brightness-90">
          {p.cta} →
        </button>
      </div>
    </div>
  );
}

export default function ByjusSection() {
  const [active, setActive] = useState("Sab");

  const filtered =
    active === "Sab" ? programs : programs.filter((p) => p.cat === active);

  return (
    <div className="bg-gray-50 font-sans px-4 sm:px-6 lg:px-8 py-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-2 mb-1.5">
          <div className="w-2 h-2 rounded-full bg-red-600 flex-shrink-0" />
          <span className="text-[10px] sm:text-xs text-gray-500">
            BYJU'S — India's #1 EdTech Platform
          </span>
        </div>

        {/* Heading */}
        <h2 className="text-lg sm:text-2xl md:text-3xl font-medium text-gray-900 leading-tight mb-1.5">
          Humara <span className="text-red-600">Learning Programs</span>
        </h2>
        <p className="text-xs sm:text-sm text-gray-500 mb-6">
          Apne class ya goal ke hisaab se program chuniye.
        </p>

        {/* Filter pills */}
        <div className="flex flex-wrap gap-2 mb-6">
          {cats.map((c) => (
            <button
              key={c}
              onClick={() => setActive(c)}
              className={`text-[10px] sm:text-xs px-3 py-1.5 rounded-full border-none cursor-pointer transition ${
                active === c
                  ? "bg-gradient-to-r from-orange-500 to-pink-600 text-white"
                  : "bg-white text-gray-500"
              } hover:brightness-90`}
            >
              {c}
            </button>
          ))}
        </div>

        {/* Cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.length === 0 ? (
            <div className="col-span-full text-center py-10 text-gray-400 text-sm">
              Koi program nahi mila.
            </div>
          ) : (
            filtered.map((p) => <ProgramCard key={p.id} p={p} />)
          )}
        </div>

        <div className="mt-7 p-4 sm:p-5 bg-white border border-gray-200 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="text-xs sm:text-sm text-gray-500">
            Pehli class{" "}
            <span className="text-gray-900 font-medium">bilkul free</span> hai —
            koi payment nahi, koi commitment nahi.
          </div>
          <button className="text-[10px] sm:text-xs font-medium px-5 py-2 rounded bg-gradient-to-r from-orange-500 to-pink-600 text-white whitespace-nowrap transition hover:brightness-90">
            Free class book karo →
          </button>
        </div>
      </div>
    </div>
  );
}