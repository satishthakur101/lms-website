// import React from "react";

// export default function HeroSection() {
//   return (
//     <div
//       className=" bg-cover bg-center bg-no-repeat relative"
//       style={{
//         backgroundImage: `url('https://edukon.aminurislam.com/static/media/03.1f8aad8dc7b9cb27236c.jpg')`,
//       }}
//     >
//       <div className="absolute inset-0 bg-white bg-opacity-40"></div>

//       <div className="relative z-10 container mx-auto px-6 py-20 lg:py-32">
//         <div className="grid lg:grid-cols-2 gap-12 items-center">
//           {/* Left Content */}
//           <div className="space-y-6 max-w-3xl mx-auto text-center lg:text-left">
//   <div className="space-y-4">
//     <h1 className="text-3xl sm:text-5xl  font-semibold text-gray-900 leading-tight tracking-tight">
//       Build Skills With Experts
//       <br />
//       <span className="text-orange-500"> Any Time Anywhere</span>
//     </h1>
//   </div>
//   <p className="text-base  text-justify text-gray-600 leading-relaxed">
//     Professor is the best and most perfect venue to grow your knowledge and boost your career.
//     Professor is the best and most perfect venue to grow your knowledge and boost your career.
//     Professor is the best and most perfect venue to grow your knowledge and boost your career.

//   </p>
//   <div className="pt-4">
//     <button className="bg-orange-500 hover:bg-orange-600 text-white text-sm px-4 py-3 rounded-md font-semibold  transition-all duration-300 shadow-md hover:shadow-lg focus:outline-none focus:ring-4 focus:ring-orange-300">
//       Get Started Now
//     </button>
//   </div>
// </div>
//           <div className="hidden lg:block">
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// import React from 'react';

// export default function TeacherIntroduction() {
//   return (
//     <div className="relative min-h-screen w-full overflow-hidden">
//       {/* Full Width Background Image */}
//       <div
//         className="absolute inset-0 bg-cover bg-center bg-no-repeat"
//         style={{
//           backgroundImage: `url('https://edukon.aminurislam.com/static/media/08.1e2dab2417a63df4a314.jpg')`,
//         }}
//       >
//         {/* Optional overlay */}
//         <div className="absolute inset-0 bg-black opacity-30"></div>
//       </div>

//       <div className="absolute right-0 top-0 w-1/2 h-full">
//         <div className="h-full relative">
//           <div className="absolute inset-0  bg-gradient-to-br from-amber-200 via-white to-amber-200 opacity-90"></div>
//           {/* Background decorative circles */}
//           <div className="absolute top-10 right-10 w-32 h-32 bg-yellow-300 rounded-full opacity-30"></div>
//           <div className="absolute bottom-20 right-5 w-48 h-48 bg-yellow-300 rounded-full opacity-20"></div>
//           <div className="absolute top-1/2 right-0 w-24 h-24 bg-yellow-600 rounded-full opacity-25 transform translate-x-12"></div>

//           {/* Content */}
//           <div className="relative z-10 h-full flex flex-col justify-center px-12">
//             {/* Greeting */}
//             <div className="space-y-4">
//               <h1 className="text-3xl sm:text-5xl  font-semibold text-gray-900 leading-tight tracking-tight">
//                 Build Skills With Experts
//                 <br />
//                 <span className="text-orange-500"> Any Time Anywhere</span>
//               </h1>
//             </div>
//             <p className="text-base  text-justify text-gray-600 leading-relaxed">
//               Professor is the best and most perfect venue to grow your
//               knowledge and boost your career. Professor is the best and most
//               perfect venue to grow your knowledge and boost your career.
//               Professor is the best and most perfect venue to grow your
//               knowledge and boost your career.
//             </p>
//             <div className="pt-4">
//               <button className="bg-orange-500 hover:bg-orange-600 text-white text-sm px-4 py-3 rounded-md font-semibold  transition-all duration-300 shadow-md hover:shadow-lg focus:outline-none focus:ring-4 focus:ring-orange-300">
//                 Get Started Now
//               </button>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Left Side Decorative Elements (over the background image) */}
//       <div className="absolute top-8 left-8 z-20">
//         <div className="grid grid-cols-8 gap-1">
//           {[...Array(32)].map((_, i) => (
//             <div
//               key={i}
//               className={`w-2 h-2 rounded-sm ${
//                 i % 4 === 0
//                   ? "bg-pink-400"
//                   : i % 4 === 1
//                   ? "bg-blue-400"
//                   : i % 4 === 2
//                   ? "bg-green-400"
//                   : "bg-yellow-300"
//               } opacity-70`}
//             ></div>
//           ))}
//         </div>
//       </div>

//       {/* Some charts/notes decoration on left side */}
//       <div className="absolute bottom-8 left-8 z-20">
//         <div className="flex space-x-4">
//           <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
//           <div className="w-3 h-3 bg-blue-400 rounded-full"></div>
//           <div className="w-3 h-3 bg-green-400 rounded-full"></div>
//         </div>
//       </div>
//     </div>
//   );
// }

import { useState, useEffect, useRef } from "react";

const slides = [
  {
    image: "/h-bg1.jpg",
    title: "Improve skills",
    subtitle: "Ready to learn and have fun? Find a perfect course and join us today.",
  },
  {
    image: "/h-bg2.jpg",
    title: "Learn & Grow",
    subtitle: "Discover thousands of courses taught by expert instructors worldwide.",
  },
  {
    image: "/h-bg3.jpg",
    title: "Start Today",
    subtitle: "Take the first step towards a better future. Join us and start learning.",
  },
];

export default function HeroSection() {
  const [current, setCurrent] = useState(0);
  const [animating, setAnimating] = useState(false);
  const [contentVisible, setContentVisible] = useState(true);
  const [slideDirection, setSlideDirection] = useState("next"); // 'next' or 'prev'
  const [bgSlide, setBgSlide] = useState({ active: 0, incoming: null, phase: "idle" });
  const timeoutRef = useRef(null);

  const goTo = (index, direction = "next") => {
    if (animating) return;
    setAnimating(true);
    setSlideDirection(direction);

    // Step 1: Hide content
    setContentVisible(false);

    // Step 2: Start bg slide in
    setTimeout(() => {
      setBgSlide({ active: current, incoming: index, phase: "sliding" });
    }, 300);

    // Step 3: Switch active, show content
    setTimeout(() => {
      setCurrent(index);
      setBgSlide({ active: index, incoming: null, phase: "idle" });
      setContentVisible(true);
      setAnimating(false);
    }, 1000);
  };

  const next = () => {
    const nextIndex = (current + 1) % slides.length;
    goTo(nextIndex, "next");
  };

  const prev = () => {
    const prevIndex = (current - 1 + slides.length) % slides.length;
    goTo(prevIndex, "prev");
  };

  // Auto-play
  useEffect(() => {
    timeoutRef.current = setTimeout(next, 5000);
    return () => clearTimeout(timeoutRef.current);
  }, [current]);

  const incomingSlide = bgSlide.incoming !== null ? slides[bgSlide.incoming] : null;
  const activeSlide = slides[bgSlide.active];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400,700,900&display=swap');

        .hero-wrapper {
          font-family: 'Montserrat', sans-serif;
          position: relative;
          width: 100%;
          height: 520px;
          overflow: hidden;
          background: #111;
        }

        /* Background layers */
        .bg-layer {
          position: absolute;
          inset: 0;
          background-size: cover;
          background-position: center;
          transition: none;
        }

        .bg-active {
          z-index: 1;
        }

        .bg-incoming {
          z-index: 2;
          transform: translateX(100%);
          transition: transform 0.75s cubic-bezier(0.77, 0, 0.18, 1);
        }

        .bg-incoming.slide-in {
          transform: translateX(0%);
        }

        .bg-incoming.slide-in-left {
          transform: translateX(0%);
        }

        .bg-incoming-left {
          z-index: 2;
          transform: translateX(-100%);
          transition: transform 0.75s cubic-bezier(0.77, 0, 0.18, 1);
        }

        .bg-incoming-left.slide-in-left {
          transform: translateX(0%);
        }

        /* Dark overlay */
        .dark-overlay {
          position: absolute;
          inset: 0;
          background: rgba(0,0,0,0.45);
          z-index: 3;
        }

        /* Content */
        .hero-content {
          position: absolute;
          inset: 0;
          z-index: 4;
          display: flex;
          flex-direction: column;
          justify-content: center;
          padding: 0 100px;
        }

        /* Content animations */
        .content-title {
          font-size: 5rem;
          font-weight: 900;
          color: #fff;
          line-height: 1.0;
          margin: 0 0 16px;
          opacity: 0;
          transform: translateY(40px);
          transition: opacity 0.55s ease 0.1s, transform 0.55s ease 0.1s;
        }

        .content-divider {
          width: 48px;
          height: 3px;
          background: #fff;
          margin-bottom: 20px;
          opacity: 0;
          transform: translateX(-30px);
          transition: opacity 0.5s ease 0.22s, transform 0.5s ease 0.22s;
        }

        .content-subtitle {
          font-size: 1rem;
          color: #fff;
          max-width: 380px;
          line-height: 1.6;
          margin-bottom: 32px;
          opacity: 0;
          transform: translateY(20px);
          transition: opacity 0.5s ease 0.34s, transform 0.5s ease 0.34s;
        }

        .content-buttons {
          display: flex;
          gap: 16px;
          opacity: 0;
          transform: translateY(20px);
          transition: opacity 0.5s ease 0.46s, transform 0.5s ease 0.46s;
        }

        /* Visible state */
        .content-visible .content-title,
        .content-visible .content-divider,
        .content-visible .content-subtitle,
        .content-visible .content-buttons {
          opacity: 1;
          transform: translate(0, 0);
        }

        /* Buttons */
        .btn-outline {
          border: 2px solid #fff;
          color: #fff;
          background: transparent;
          padding: 14px 36px;
          font-weight: 700;
          font-size: 0.85rem;
          letter-spacing: 0.05em;
          cursor: pointer;
          transition: background 0.2s, color 0.2s;
          text-transform: none;
        }
        .btn-outline:hover {
          background: #fff;
          color: #111;
        }

        .btn-red {
          border: 2px solid #e8192c;
          color: #fff;
          background: #e8192c;
          padding: 14px 36px;
          font-weight: 700;
          font-size: 0.85rem;
          letter-spacing: 0.05em;
          cursor: pointer;
          transition: background 0.2s;
        }
        .btn-red:hover {
          background: #c0001f;
          border-color: #c0001f;
        }

        /* Arrow buttons */
        .arrow-btn {
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          z-index: 5;
          background: #1c1c1ceb;
          color: #fff;
          border: none;
          width: 42px;
          height: 42px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          font-size: 2rem;
          transition: background 0.2s;
        }
        .arrow-btn:hover { background: #242222eb; }
        .arrow-left { left: 20px; }
        .arrow-right { right: 20px; }
      `}</style>

      <div className="hero-wrapper">
        {/* Active background */}
        <div
          className="bg-layer bg-active"
          style={{ backgroundImage: `url(${activeSlide.image})` }}
        />

        {/* Incoming background */}
        {incomingSlide && (
          <div
            className={`bg-layer ${
              slideDirection === "next"
                ? `bg-incoming slide-in`
                : `bg-incoming-left slide-in-left`
            }`}
            style={{ backgroundImage: `url(${incomingSlide.image})` }}
          />
        )}

        {/* Dark overlay */}
        <div className="dark-overlay" />

        {/* Content */}
        <div className={`hero-content ${contentVisible ? "content-visible" : ""}`}>
          <h1 className="content-title">{slides[current].title}</h1>
          <div className="content-divider" />
          <p className="content-subtitle">{slides[current].subtitle}</p>
          <div className="content-buttons">
            <button className="btn-outline">Read More</button>
            <button className="btn-red">Apply Now</button>
          </div>
        </div>

        {/* Arrow Buttons */}
        <button className="arrow-btn arrow-left" onClick={prev}>&#8249;</button>
        <button className="arrow-btn arrow-right" onClick={next}>&#8250;</button>
      </div>
    </>
  );
}


